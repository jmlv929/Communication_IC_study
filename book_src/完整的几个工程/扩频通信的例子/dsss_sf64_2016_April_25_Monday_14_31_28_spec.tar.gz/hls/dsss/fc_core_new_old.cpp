#include "fc_core_new.h"

#pragma design
void rotate_unit(AGC_t AGC_I[UNIT_SIZE], AGC_t AGC_Q[UNIT_SIZE], SIN_t rot_sin, SIN_t rot_cos, bool gold_sn[UNIT_SIZE], ACC_SIN_t &acc_Icos_add_Qsin, ACC_SIN_t &acc_Icos_sub_Qsin, ACC_SIN_t &acc_Isin_add_Qcos, ACC_SIN_t &acc_Isin_sub_Qcos)
{

    int j;
    //every phase is 8 chips

    PHASE_SUM_t sum_I_phase, sum_Q_phase;
    PHASE_SUM_t mul_Icos, mul_Qcos, mul_Isin, mul_Qsin;

    sum_I_phase = 0;
    sum_Q_phase = 0;
    for(j = 0; j < UNIT_SIZE; j++)
    {
        sum_I_phase = (gold_sn[j]==true) ? (sum_I_phase - AGC_I[j]): (sum_I_phase + AGC_I[j]);
        sum_Q_phase = (gold_sn[j]==true) ? (sum_Q_phase - AGC_Q[j]): (sum_Q_phase + AGC_Q[j]);
    }

    mul_Icos = sum_I_phase * rot_cos;
    mul_Isin = sum_I_phase * rot_sin;
    mul_Qcos = sum_Q_phase * rot_cos;
    mul_Qsin = sum_Q_phase * rot_sin;

    acc_Icos_sub_Qsin = mul_Icos - mul_Qsin;
    acc_Icos_add_Qsin = mul_Icos + mul_Qsin;
    acc_Isin_sub_Qcos = mul_Qcos - mul_Isin;
    acc_Isin_add_Qcos = mul_Qcos + mul_Isin;
}

#pragma design
void fc_top(bool synch_stage, AGC_t AGC_I[FULL_CHIP_NUM], AGC_t AGC_Q[FULL_CHIP_NUM], bool psdu_gold_sn[256], bool shr_gold_sn[256], SF_t psdu_sf, SF_t shr_sf, bool &decode_bit, ABS_ACC_SUM_SIN_t &max_acc, ANGLE_t &max_ppm, bool &neg_or_pos, PPM_INDEX_t &max_index)
{

    //    AGC_t AGC_I[FULL_CHIP_NUM], AGC_t AGC_Q[FULL_CHIP_NUM];
    int i, j, n;
    int len;

    SF_t use_sf;
    bool use_gold_sn[FULL_CHIP_NUM];
    bool valid_gold_sn[FULL_CHIP_NUM];
    bool neg_bit, pos_bit;
    bool neg_bit8[8], pos_bit8[8];
    ANGLE_t base_ppm, inc_ppm;

    len = 2048;
	max_acc=0;
	
	if(synch_stage)
    {
        use_sf = psdu_sf;
        for(i = 0; i < 256; i++) use_gold_sn[i] = psdu_gold_sn[i];
        inc_ppm = 6;
    }
    else
    {
        use_sf = shr_sf;
        for(i = 0; i < 256; i++) use_gold_sn[i] = shr_gold_sn[i];
        inc_ppm = 301;
    }

	for(i = 0; i < FULL_CHIP_NUM; i++)valid_gold_sn[i] = 0;
    switch (use_sf) // 000: 16 sf;001:32 sf ; 010: 64 sf; 011:128 sf; 100: 256 sf; 101~111: reserved
    {
    case 0: // 16 sf
        if(!synch_stage) len = 16 * 8;
        else len = 16 * 4;
        for(i = 0; i < 16; i++)
        {
            if(!synch_stage)
            {
                valid_gold_sn[0 * 16 + i] = use_gold_sn[i];
                valid_gold_sn[1 * 16 + i] = use_gold_sn[i];
                valid_gold_sn[2 * 16 + i] = use_gold_sn[i];
                valid_gold_sn[3 * 16 + i] = use_gold_sn[i];
                valid_gold_sn[4 * 16 + i] = use_gold_sn[i];
                valid_gold_sn[5 * 16 + i] = use_gold_sn[i];
                valid_gold_sn[6 * 16 + i] = use_gold_sn[i];
                valid_gold_sn[7 * 16 + i] = use_gold_sn[i];
            }
            else
            {
                valid_gold_sn[4 * i + 0] = use_gold_sn[i];
                valid_gold_sn[4 * i + 1] = use_gold_sn[i];
                valid_gold_sn[4 * i + 2] = use_gold_sn[i];
                valid_gold_sn[4 * i + 3] = use_gold_sn[i];
            }
        }
        break;
    case 1: // 32
        if(!synch_stage) len = 32 * 8;
        else len = 32 * 4;
        for(i = 0; i < 32; i++)
        {
            if(!synch_stage)
            {
                valid_gold_sn[0 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[1 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[2 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[3 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[4 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[5 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[6 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[7 * 32 + i] = use_gold_sn[i];
            }
            else
            {
                valid_gold_sn[4 * i + 0] = use_gold_sn[i];
                valid_gold_sn[4 * i + 1] = use_gold_sn[i];
                valid_gold_sn[4 * i + 2] = use_gold_sn[i];
                valid_gold_sn[4 * i + 3] = use_gold_sn[i];
            }
        }
        break;
    case 2: //64
        if(!synch_stage) len = 64 * 8;
        else len = 64 * 4;
        for(i = 0; i < 64; i++)
        {
            if(!synch_stage)
            {
                valid_gold_sn[0 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[1 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[2 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[3 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[4 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[5 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[6 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[7 * 32 + i] = use_gold_sn[i];
            }
            else
            {
                valid_gold_sn[4 * i + 0] = use_gold_sn[i];
                valid_gold_sn[4 * i + 1] = use_gold_sn[i];
                valid_gold_sn[4 * i + 2] = use_gold_sn[i];
                valid_gold_sn[4 * i + 3] = use_gold_sn[i];
            }
        }
        break;
    case 3: //128
        if(!synch_stage) len = 128;
        else len = 128 * 4;
        for(i = 0; i < 128; i++)
        {
            if(!synch_stage)
            {
                valid_gold_sn[0 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[1 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[2 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[3 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[4 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[5 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[6 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[7 * 32 + i] = use_gold_sn[i];
            }
            else
            {
                valid_gold_sn[4 * i + 0] = use_gold_sn[i];
                valid_gold_sn[4 * i + 1] = use_gold_sn[i];
                valid_gold_sn[4 * i + 2] = use_gold_sn[i];
                valid_gold_sn[4 * i + 3] = use_gold_sn[i];
            }
        }
        break;
    case 4: //128
        if(!synch_stage) len = 256 * 8;
        else len = 256 * 4;
        for(i = 0; i < 256; i++)
        {
            if(!synch_stage)
            {
                valid_gold_sn[0 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[1 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[2 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[3 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[4 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[5 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[6 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[7 * 32 + i] = use_gold_sn[i];
            }
            else
            {
                valid_gold_sn[4 * i + 0] = use_gold_sn[i];
                valid_gold_sn[4 * i + 1] = use_gold_sn[i];
                valid_gold_sn[4 * i + 2] = use_gold_sn[i];
                valid_gold_sn[4 * i + 3] = use_gold_sn[i];
            }
        }
        break;
    default: //256
        if(!synch_stage) len = 256 * 8;
        else len = 256 * 4;

        for(i = 0; i < 256; i++)
        {
            if(!synch_stage)
            {
                valid_gold_sn[0 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[1 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[2 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[3 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[4 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[5 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[6 * 32 + i] = use_gold_sn[i];
                valid_gold_sn[7 * 32 + i] = use_gold_sn[i];
            }
            else
            {
                valid_gold_sn[4 * i + 0] = use_gold_sn[i];
                valid_gold_sn[4 * i + 1] = use_gold_sn[i];
                valid_gold_sn[4 * i + 2] = use_gold_sn[i];
                valid_gold_sn[4 * i + 3] = use_gold_sn[i];
            }
        }
        break;
    }

#ifdef _DEBUG
	MyACPut(ep,"valid_gold_sn",valid_gold_sn,FULL_CHIP_NUM);
#endif

    ANGLE_mult_t theta_full;

    int unit_ptr;
    ac_int<8>lut_index;
    ACC_SIN_t acc_Icos_add_Qsin, acc_Icos_sub_Qsin, acc_Isin_add_Qcos, acc_Isin_sub_Qcos;

    PHASE_SUM_SIN_t unit_Icos_add_Qsin;//[UNIT_NUM];
    PHASE_SUM_SIN_t unit_Icos_sub_Qsin;//[UNIT_NUM];
    PHASE_SUM_SIN_t unit_Isin_add_Qcos;//[UNIT_NUM];
    PHASE_SUM_SIN_t unit_Isin_sub_Qcos;//[UNIT_NUM];

    PHASE_SUM_SIN_t unit_Icos_add_Qsin_16;//[UNIT_NUM];
    PHASE_SUM_SIN_t unit_Icos_sub_Qsin_16;//[UNIT_NUM];
    PHASE_SUM_SIN_t unit_Isin_add_Qcos_16;//[UNIT_NUM];
    PHASE_SUM_SIN_t unit_Isin_sub_Qcos_16;//[UNIT_NUM];


    ACC_SUM_SIN_t acc_unit_Icos_add_Qsin;//[UNIT_NUM];
    ACC_SUM_SIN_t acc_unit_Icos_sub_Qsin;//[UNIT_NUM];
    ACC_SUM_SIN_t acc_unit_Isin_add_Qcos;//[UNIT_NUM];
    ACC_SUM_SIN_t acc_unit_Isin_sub_Qcos;//[UNIT_NUM];

    //ACC_SUM_SIN_t sum_I,sum_Q;

    ACC_SUM_SIN_t acc_unit_Icos_add_Qsin_bit1;//[UNIT_NUM];
    ACC_SUM_SIN_t acc_unit_Icos_sub_Qsin_bit1;//[UNIT_NUM];
    ACC_SUM_SIN_t acc_unit_Isin_add_Qcos_bit1;//[UNIT_NUM];
    ACC_SUM_SIN_t acc_unit_Isin_sub_Qcos_bit1;//[UNIT_NUM];
    ACC_SUM_SIN_t acc_unit_Icos_add_Qsin_bit8[8];//[UNIT_NUM];
    ACC_SUM_SIN_t acc_unit_Icos_sub_Qsin_bit8[8];//[UNIT_NUM];
    ACC_SUM_SIN_t acc_unit_Isin_add_Qcos_bit8[8];//[UNIT_NUM];
    ACC_SUM_SIN_t acc_unit_Isin_sub_Qcos_bit8[8];//[UNIT_NUM];

    ABS_ACC_SUM_SIN_t abs_acc_unit_Icos_add_Qsin_bit1;//[UNIT_NUM];
    ABS_ACC_SUM_SIN_t abs_acc_unit_Icos_sub_Qsin_bit1;//[UNIT_NUM];
    ABS_ACC_SUM_SIN_t abs_acc_unit_Isin_add_Qcos_bit1;//[UNIT_NUM];
    ABS_ACC_SUM_SIN_t abs_acc_unit_Isin_sub_Qcos_bit1;//[UNIT_NUM];
    ABS_ACC_SUM_SIN_t abs_acc_unit_Icos_add_Qsin_bit8[8];//[UNIT_NUM];
    ABS_ACC_SUM_SIN_t abs_acc_unit_Icos_sub_Qsin_bit8[8];//[UNIT_NUM];
    ABS_ACC_SUM_SIN_t abs_acc_unit_Isin_add_Qcos_bit8[8];//[UNIT_NUM];
    ABS_ACC_SUM_SIN_t abs_acc_unit_Isin_sub_Qcos_bit8[8];//[UNIT_NUM];

    ABS_ACC_SUM_SIN_t acc_pos, acc_neg;
    bool cos_sig, sin_sig;
    SIN_t rot_cos, rot_sin;
    SIN_t tmp_rot_sin, tmp_rot_cos;

    acc_unit_Icos_add_Qsin_bit1 = 0;
    acc_unit_Icos_sub_Qsin_bit1 = 0;
    acc_unit_Isin_add_Qcos_bit1 = 0;
    acc_unit_Isin_sub_Qcos_bit1 = 0;

    for(j = 0; j < 8; j++)
    {
        acc_unit_Icos_add_Qsin_bit8[j] = 0;
        acc_unit_Icos_sub_Qsin_bit8[j] = 0;
        acc_unit_Isin_add_Qcos_bit8[j] = 0;
        acc_unit_Isin_sub_Qcos_bit8[j] = 0;
    }

    base_ppm = 0;
	int unit_i,ppm_i;
    for(ppm_i = 0; ppm_i < PPM_NUM; ppm_i++)
    {
        if(ppm_i == 0)base_ppm = 0;
        else
        {
            base_ppm = base_ppm + inc_ppm;
        }

        //acc_pos_I = 0;
        //acc_pos_Q = 0;
        //acc_neg_I = 0;
        //acc_neg_Q = 0;

        //acc_unit_Icos_add_Qsin_bit1=0;
        //acc_unit_Icos_sub_Qsin_bit1=0;
        //acc_unit_Isin_add_Qcos_bit1=0;
        //acc_unit_Isin_sub_Qcos_bit1=0;
        //
        //for(j=0;j<8;j++){
        //  acc_unit_Icos_add_Qsin_bit8[j]=0;
        //  acc_unit_Icos_sub_Qsin_bit8[j]=0;
        //  acc_unit_Isin_add_Qcos_bit8[j]=0;
        //  acc_unit_Isin_sub_Qcos_bit8[j]=0;
        //}

        for(unit_i = 0; unit_i < UNIT_NUM; unit_i++)
        {

            for(n = 0; n < PHASE_NUM; n++)
            {
                unit_ptr = PHASE_NUM * UNIT_SIZE * unit_i + n * UNIT_SIZE;
                theta_full = (len - unit_ptr - PHASE_NUM / 2) * base_ppm; // use half N0.4 point as whole 8 points freqency offset

                lut_index = theta_full.slc<8>(6); //lut_index=theta_full[6+8-1:6];
                cos_sig = theta_full[15];
                sin_sig = theta_full[14];
                tmp_rot_sin = sin_tab[lut_index];
                tmp_rot_cos = cos_tab[lut_index];
                if(cos_sig)rot_cos = -tmp_rot_cos;
                else rot_cos = tmp_rot_cos;
                if(sin_sig)rot_sin = -tmp_rot_sin;
                else rot_sin = tmp_rot_sin;
#ifdef _DEBUG
				MyACPut(ep,"AGC_I",&AGC_I[unit_ptr],8,unit_ptr);
				MyACPut(ep,"AGC_Q",&AGC_Q[unit_ptr],8,unit_ptr);
				MyACPut(ep,"valid_gold_sn",&valid_gold_sn[unit_ptr],8,unit_ptr);
				MyACPut(ep,"rot_sin",&rot_sin,1,unit_i*PHASE_NUM+n);
				MyACPut(ep,"rot_cos",&rot_cos,1,unit_i*PHASE_NUM+n);
				MyACPut(ep,"theta_full",&theta_full,1,unit_i*PHASE_NUM+n);
#endif
                rotate_unit(&AGC_I[unit_ptr], &AGC_Q[unit_ptr], rot_sin, rot_cos, &valid_gold_sn[unit_ptr], acc_Icos_add_Qsin, acc_Icos_sub_Qsin, acc_Isin_add_Qcos, acc_Isin_sub_Qcos);
#ifdef _DEBUG
				MyACPut(ep,"acc_Icos_add_Qsin",&acc_Icos_add_Qsin,1,unit_i*PHASE_NUM+n);
				MyACPut(ep,"acc_Icos_sub_Qsin",&acc_Icos_sub_Qsin,1,unit_i*PHASE_NUM+n);
				MyACPut(ep,"acc_Isin_add_Qcos",&acc_Isin_add_Qcos,1,unit_i*PHASE_NUM+n);
				MyACPut(ep,"acc_Isin_sub_Qcos",&acc_Isin_sub_Qcos,1,unit_i*PHASE_NUM+n);
#endif

				if(n==0){
					unit_Icos_add_Qsin = acc_Icos_add_Qsin;
					unit_Icos_sub_Qsin = acc_Icos_sub_Qsin;
					unit_Isin_add_Qcos = acc_Isin_add_Qcos;
					unit_Isin_sub_Qcos = acc_Isin_sub_Qcos;
				}else{
					unit_Icos_add_Qsin = unit_Icos_add_Qsin + acc_Icos_add_Qsin;
					unit_Icos_sub_Qsin = unit_Icos_sub_Qsin + acc_Icos_sub_Qsin;
					unit_Isin_add_Qcos = unit_Isin_add_Qcos + acc_Isin_add_Qcos;
					unit_Isin_sub_Qcos = unit_Isin_sub_Qcos + acc_Isin_sub_Qcos;
				}

                if((unit_i < 4) && (n == 1)) // only save phase 0 + phase 1;phase 3 + phase 4 = unit_Icos_add_Qsin[i]-unit_Isin_add_Qcos_16
                {
                    unit_Icos_add_Qsin_16 = unit_Icos_add_Qsin;
                    unit_Icos_sub_Qsin_16 = unit_Icos_sub_Qsin;
                    unit_Isin_add_Qcos_16 = unit_Isin_add_Qcos;
                    unit_Isin_sub_Qcos_16 = unit_Isin_sub_Qcos;
                }
            }
            switch(use_sf)
            {
            case 0:
                if(synch_stage)  // 16 *4, thus 2 unit need to stastic, all 2 unit direct add ,and get the abs value;
                {
                    if(unit_i < 2)
                    {
                        if(unit_i == 0)
                        {
                            acc_unit_Icos_add_Qsin_bit1 = unit_Icos_add_Qsin;
                            acc_unit_Icos_sub_Qsin_bit1 = unit_Icos_sub_Qsin;
                            acc_unit_Isin_add_Qcos_bit1 = unit_Isin_add_Qcos;
                            acc_unit_Isin_sub_Qcos_bit1 = unit_Isin_sub_Qcos;
                        }
                        else
                        {
                            acc_unit_Icos_add_Qsin_bit1 += unit_Icos_add_Qsin;
                            acc_unit_Icos_sub_Qsin_bit1 += unit_Icos_sub_Qsin;
                            acc_unit_Isin_add_Qcos_bit1 += unit_Isin_add_Qcos;
                            acc_unit_Isin_sub_Qcos_bit1 += unit_Isin_sub_Qcos;
                        }
                    }
                }
                else
                {
                    if(unit_i < 4)
                    {
                        acc_unit_Icos_add_Qsin_bit8[2 * unit_i + 0] = unit_Icos_add_Qsin_16;
                        acc_unit_Icos_sub_Qsin_bit8[2 * unit_i + 0] = unit_Icos_sub_Qsin_16;
                        acc_unit_Isin_add_Qcos_bit8[2 * unit_i + 0] = unit_Isin_add_Qcos_16;
                        acc_unit_Isin_sub_Qcos_bit8[2 * unit_i + 0] = unit_Isin_sub_Qcos_16;

                        acc_unit_Icos_add_Qsin_bit8[2 * unit_i + 1] = unit_Icos_add_Qsin - unit_Icos_add_Qsin_16;
                        acc_unit_Icos_sub_Qsin_bit8[2 * unit_i + 1] = unit_Icos_sub_Qsin - unit_Icos_sub_Qsin_16;
                        acc_unit_Isin_add_Qcos_bit8[2 * unit_i + 1] = unit_Isin_add_Qcos - unit_Isin_add_Qcos_16;
                        acc_unit_Isin_sub_Qcos_bit8[2 * unit_i + 1] = unit_Isin_sub_Qcos - unit_Isin_sub_Qcos_16;
                    }

                }
                break;
            case 1:   //32 sf
                if(synch_stage)  // 32 *4, thus 4 unit need to stastic, all 4 unit direct add ,and get the abs value;
                {
                    if(unit_i < 4)
                    {
                        if(unit_i == 0)
                        {
                            acc_unit_Icos_add_Qsin_bit1 = unit_Icos_add_Qsin;
                            acc_unit_Icos_sub_Qsin_bit1 = unit_Icos_sub_Qsin;
                            acc_unit_Isin_add_Qcos_bit1 = unit_Isin_add_Qcos;
                            acc_unit_Isin_sub_Qcos_bit1 = unit_Isin_sub_Qcos;
                        }
                        else
                        {
                            acc_unit_Icos_add_Qsin_bit1 += unit_Icos_add_Qsin;
                            acc_unit_Icos_sub_Qsin_bit1 += unit_Icos_sub_Qsin;
                            acc_unit_Isin_add_Qcos_bit1 += unit_Isin_add_Qcos;
                            acc_unit_Isin_sub_Qcos_bit1 += unit_Isin_sub_Qcos;
                        }
                    }
                }
                else
                {
                    if(unit_i < 8)
                    {
                        acc_unit_Icos_add_Qsin_bit8[unit_i] = unit_Icos_add_Qsin_16;
                        acc_unit_Icos_sub_Qsin_bit8[unit_i] = unit_Icos_sub_Qsin_16;
                        acc_unit_Isin_add_Qcos_bit8[unit_i] = unit_Isin_add_Qcos_16;
                        acc_unit_Isin_sub_Qcos_bit8[unit_i] = unit_Isin_sub_Qcos_16;
                    }

                }
                break;
            case 2:   //64 sf
                if(synch_stage)  // 32 *8, thus 8 unit need to stastic, all 4 unit direct add ,and get the abs value;
                {
                    if(unit_i < 8)
                    {
                        if(unit_i == 0)
                        {
                            acc_unit_Icos_add_Qsin_bit1 = unit_Icos_add_Qsin;
                            acc_unit_Icos_sub_Qsin_bit1 = unit_Icos_sub_Qsin;
                            acc_unit_Isin_add_Qcos_bit1 = unit_Isin_add_Qcos;
                            acc_unit_Isin_sub_Qcos_bit1 = unit_Isin_sub_Qcos;
                        }
                        else
                        {
                            acc_unit_Icos_add_Qsin_bit1 += unit_Icos_add_Qsin;
                            acc_unit_Icos_sub_Qsin_bit1 += unit_Icos_sub_Qsin;
                            acc_unit_Isin_add_Qcos_bit1 += unit_Isin_add_Qcos;
                            acc_unit_Isin_sub_Qcos_bit1 += unit_Isin_sub_Qcos;
                        }
                    }
                }
                else
                {
                    if(unit_i < 16)
                    {
                        if(unit_i % 2 == 0)
                        {
                            acc_unit_Icos_add_Qsin_bit8[unit_i / 2] = unit_Icos_add_Qsin_16;
                            acc_unit_Icos_sub_Qsin_bit8[unit_i / 2] = unit_Icos_sub_Qsin_16;
                            acc_unit_Isin_add_Qcos_bit8[unit_i / 2] = unit_Isin_add_Qcos_16;
                            acc_unit_Isin_sub_Qcos_bit8[unit_i / 2] = unit_Isin_sub_Qcos_16;
                        }
                        else
                        {
                            acc_unit_Icos_add_Qsin_bit8[unit_i / 2] += unit_Icos_add_Qsin_16;
                            acc_unit_Icos_sub_Qsin_bit8[unit_i / 2] += unit_Icos_sub_Qsin_16;
                            acc_unit_Isin_add_Qcos_bit8[unit_i / 2] += unit_Isin_add_Qcos_16;
                            acc_unit_Isin_sub_Qcos_bit8[unit_i / 2] += unit_Isin_sub_Qcos_16;
                        }
                    }
                }
                break;
            case 3:   //128 sf
                if(synch_stage)  // 32 *16, thus 16 unit need to stastic, all 16 unit direct add ,and get the abs value;
                {
                    if(unit_i < 16)
                    {
                        if(unit_i == 0)
                        {
                            acc_unit_Icos_add_Qsin_bit1 = unit_Icos_add_Qsin;
                            acc_unit_Icos_sub_Qsin_bit1 = unit_Icos_sub_Qsin;
                            acc_unit_Isin_add_Qcos_bit1 = unit_Isin_add_Qcos;
                            acc_unit_Isin_sub_Qcos_bit1 = unit_Isin_sub_Qcos;
                        }
                        else
                        {
                            acc_unit_Icos_add_Qsin_bit1 += unit_Icos_add_Qsin;
                            acc_unit_Icos_sub_Qsin_bit1 += unit_Icos_sub_Qsin;
                            acc_unit_Isin_add_Qcos_bit1 += unit_Isin_add_Qcos;
                            acc_unit_Isin_sub_Qcos_bit1 += unit_Isin_sub_Qcos;
                        }
                    }
                }
                else
                {
                    if(unit_i < 32)
                    {
                        if(unit_i % 4 == 0)
                        {
                            acc_unit_Icos_add_Qsin_bit8[unit_i / 4] = unit_Icos_add_Qsin_16;
                            acc_unit_Icos_sub_Qsin_bit8[unit_i / 4] = unit_Icos_sub_Qsin_16;
                            acc_unit_Isin_add_Qcos_bit8[unit_i / 4] = unit_Isin_add_Qcos_16;
                            acc_unit_Isin_sub_Qcos_bit8[unit_i / 4] = unit_Isin_sub_Qcos_16;
                        }
                        else
                        {
                            acc_unit_Icos_add_Qsin_bit8[unit_i / 4] += unit_Icos_add_Qsin_16;
                            acc_unit_Icos_sub_Qsin_bit8[unit_i / 4] += unit_Icos_sub_Qsin_16;
                            acc_unit_Isin_add_Qcos_bit8[unit_i / 4] += unit_Isin_add_Qcos_16;
                            acc_unit_Isin_sub_Qcos_bit8[unit_i / 4] += unit_Isin_sub_Qcos_16;
                        }
                    }
                }
                break;
            case 4:   //256 sf
                if(synch_stage)  // 32 *32, thus 32 unit need to stastic, all 32 unit direct add ,and get the abs value;
                {
                    if(unit_i < 32)
                    {
                        if(unit_i == 0)
                        {
                            acc_unit_Icos_add_Qsin_bit1 = unit_Icos_add_Qsin;
                            acc_unit_Icos_sub_Qsin_bit1 = unit_Icos_sub_Qsin;
                            acc_unit_Isin_add_Qcos_bit1 = unit_Isin_add_Qcos;
                            acc_unit_Isin_sub_Qcos_bit1 = unit_Isin_sub_Qcos;
                        }
                        else
                        {
                            acc_unit_Icos_add_Qsin_bit1 += unit_Icos_add_Qsin;
                            acc_unit_Icos_sub_Qsin_bit1 += unit_Icos_sub_Qsin;
                            acc_unit_Isin_add_Qcos_bit1 += unit_Isin_add_Qcos;
                            acc_unit_Isin_sub_Qcos_bit1 += unit_Isin_sub_Qcos;
                        }
                    }
                }
                else
                {
                    if(unit_i < 64)
                    {
                        if(unit_i % 8 == 0)
                        {
                            acc_unit_Icos_add_Qsin_bit8[unit_i / 8] = unit_Icos_add_Qsin_16;
                            acc_unit_Icos_sub_Qsin_bit8[unit_i / 8] = unit_Icos_sub_Qsin_16;
                            acc_unit_Isin_add_Qcos_bit8[unit_i / 8] = unit_Isin_add_Qcos_16;
                            acc_unit_Isin_sub_Qcos_bit8[unit_i / 8] = unit_Isin_sub_Qcos_16;
                        }
                        else
                        {
                            acc_unit_Icos_add_Qsin_bit8[unit_i / 8] += unit_Icos_add_Qsin_16;
                            acc_unit_Icos_sub_Qsin_bit8[unit_i / 8] += unit_Icos_sub_Qsin_16;
                            acc_unit_Isin_add_Qcos_bit8[unit_i / 8] += unit_Isin_add_Qcos_16;
                            acc_unit_Isin_sub_Qcos_bit8[unit_i / 8] += unit_Isin_sub_Qcos_16;
                        }
                    }
                }
                break;
            default:
                if(synch_stage)  // 32 *32, thus 32 unit need to stastic, all 32 unit direct add ,and get the abs value;
                {
                    if(unit_i < 32)
                    {
                        if(unit_i == 0)
                        {
                            acc_unit_Icos_add_Qsin_bit1 = unit_Icos_add_Qsin;
                            acc_unit_Icos_sub_Qsin_bit1 = unit_Icos_sub_Qsin;
                            acc_unit_Isin_add_Qcos_bit1 = unit_Isin_add_Qcos;
                            acc_unit_Isin_sub_Qcos_bit1 = unit_Isin_sub_Qcos;
                        }
                        else
                        {
                            acc_unit_Icos_add_Qsin_bit1 += unit_Icos_add_Qsin;
                            acc_unit_Icos_sub_Qsin_bit1 += unit_Icos_sub_Qsin;
                            acc_unit_Isin_add_Qcos_bit1 += unit_Isin_add_Qcos;
                            acc_unit_Isin_sub_Qcos_bit1 += unit_Isin_sub_Qcos;
                        }
                    }
                }
                else
                {
                    if(j < 64)
                    {
                        if(j % 8 == 0)
                        {
                            acc_unit_Icos_add_Qsin_bit8[unit_i / 8] = unit_Icos_add_Qsin_16;
                            acc_unit_Icos_sub_Qsin_bit8[unit_i / 8] = unit_Icos_sub_Qsin_16;
                            acc_unit_Isin_add_Qcos_bit8[unit_i / 8] = unit_Isin_add_Qcos_16;
                            acc_unit_Isin_sub_Qcos_bit8[unit_i / 8] = unit_Isin_sub_Qcos_16;
                        }
                        else
                        {
                            acc_unit_Icos_add_Qsin_bit8[unit_i / 8] += unit_Icos_add_Qsin_16;
                            acc_unit_Icos_sub_Qsin_bit8[unit_i / 8] += unit_Icos_sub_Qsin_16;
                            acc_unit_Isin_add_Qcos_bit8[unit_i / 8] += unit_Isin_add_Qcos_16;
                            acc_unit_Isin_sub_Qcos_bit8[unit_i / 8] += unit_Isin_sub_Qcos_16;
                        }
                    }
                }

                break;
            }
        }

        if(synch_stage)
        {
            neg_bit = acc_unit_Icos_add_Qsin_bit1 > 0 ? 0 : 1;
            pos_bit = acc_unit_Icos_sub_Qsin_bit1 > 0 ? 0 : 1;

            abs_acc_unit_Icos_add_Qsin_bit1 = acc_unit_Icos_add_Qsin_bit1 > 0 ? acc_unit_Icos_add_Qsin_bit1 : -acc_unit_Icos_add_Qsin_bit1;
            abs_acc_unit_Icos_sub_Qsin_bit1 = acc_unit_Icos_sub_Qsin_bit1 > 0 ? acc_unit_Icos_sub_Qsin_bit1 : -acc_unit_Icos_sub_Qsin_bit1;
            abs_acc_unit_Isin_add_Qcos_bit1 = acc_unit_Isin_add_Qcos_bit1 > 0 ? acc_unit_Isin_add_Qcos_bit1 : -acc_unit_Isin_add_Qcos_bit1;
            abs_acc_unit_Isin_sub_Qcos_bit1 = acc_unit_Isin_sub_Qcos_bit1 > 0 ? acc_unit_Isin_sub_Qcos_bit1 : -acc_unit_Isin_sub_Qcos_bit1;

            if(abs_acc_unit_Icos_sub_Qsin_bit1 > abs_acc_unit_Isin_add_Qcos_bit1)
            {
                acc_pos = abs_acc_unit_Icos_sub_Qsin_bit1 + abs_acc_unit_Isin_add_Qcos_bit1 / 2 ;
            }
            else
            {
                acc_pos = abs_acc_unit_Icos_sub_Qsin_bit1 / 2 + abs_acc_unit_Isin_add_Qcos_bit1;
            }
            if(abs_acc_unit_Icos_add_Qsin_bit1 > abs_acc_unit_Isin_sub_Qcos_bit1)
            {
                acc_neg = abs_acc_unit_Icos_add_Qsin_bit1 + abs_acc_unit_Isin_sub_Qcos_bit1 / 2;
            }
            else
            {
                acc_neg = abs_acc_unit_Icos_add_Qsin_bit1 / 2 + abs_acc_unit_Isin_sub_Qcos_bit1;
            }

            if(acc_pos > max_acc)
            {
                max_acc = acc_pos;
                max_index = i;
                max_ppm = base_ppm;
                neg_or_pos = 1;
                decode_bit = pos_bit;
            }

            if(acc_neg > max_acc)
            {
                max_acc = acc_neg;
                max_index = i;
                max_ppm = base_ppm;
                neg_or_pos = 0;
                decode_bit = neg_bit;
            }

        }
        else
        {


            acc_pos = 0;
            acc_neg = 0;

            for(n = 0; n < 8; n++)
            {
                neg_bit8[n] = acc_unit_Icos_add_Qsin_bit8[n] > 0 ? 0 : 1;
                pos_bit8[n] = acc_unit_Icos_sub_Qsin_bit8[n] > 0 ? 0 : 1;

                abs_acc_unit_Icos_add_Qsin_bit8[n] = acc_unit_Icos_add_Qsin_bit8[n] > 0 ? acc_unit_Icos_add_Qsin_bit8[n] : -acc_unit_Icos_add_Qsin_bit8[n];
                abs_acc_unit_Icos_sub_Qsin_bit8[n] = acc_unit_Icos_sub_Qsin_bit8[n] > 0 ? acc_unit_Icos_sub_Qsin_bit8[n] : -acc_unit_Icos_sub_Qsin_bit8[n];
                abs_acc_unit_Isin_add_Qcos_bit8[n] = acc_unit_Isin_add_Qcos_bit8[n] > 0 ? acc_unit_Isin_add_Qcos_bit8[n] : -acc_unit_Isin_add_Qcos_bit8[n];
                abs_acc_unit_Isin_sub_Qcos_bit8[n] = acc_unit_Isin_sub_Qcos_bit8[n] > 0 ? acc_unit_Isin_sub_Qcos_bit8[n] : -acc_unit_Isin_sub_Qcos_bit8[n];

                if(abs_acc_unit_Icos_sub_Qsin_bit8[n] > abs_acc_unit_Isin_add_Qcos_bit8[n])
                {
                    acc_pos = acc_pos + abs_acc_unit_Icos_sub_Qsin_bit8[n] + abs_acc_unit_Isin_add_Qcos_bit8[n] / 2;
                }
                else
                {
                    acc_pos = acc_pos + abs_acc_unit_Icos_sub_Qsin_bit8[n] / 2  + abs_acc_unit_Isin_add_Qcos_bit8[n];
                }
                if(abs_acc_unit_Icos_add_Qsin_bit8[n] > abs_acc_unit_Isin_sub_Qcos_bit8[n])
                {
                    acc_neg = acc_neg + abs_acc_unit_Icos_add_Qsin_bit8[n] + abs_acc_unit_Isin_sub_Qcos_bit8[n] / 2;
                }
                else
                {
                    acc_neg = acc_neg + abs_acc_unit_Icos_add_Qsin_bit8[n] / 2 + abs_acc_unit_Isin_sub_Qcos_bit8[n];
                }

            }

            if(acc_pos > max_acc)
            {
                max_acc = acc_pos;
                max_index = ppm_i;
                max_ppm = base_ppm;
                neg_or_pos = 0;
            }

            if(acc_neg > max_acc)
            {
                max_acc = acc_neg;
                max_index = ppm_i;
                max_ppm = base_ppm;
                neg_or_pos = 1;
            }
#ifdef _DEBUG
			printf("start ppm %d: acc_pos is %f,acc_neg is %f,now max is %f\n",ppm_i,acc_pos.to_double(),acc_neg.to_double(),max_acc.to_double());
#endif
        }

    }
}



