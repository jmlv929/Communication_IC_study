//#include "iostream.h"
#include "agc.h"

#pragma design
#define MAX_CNT 32
void agc(IQ_t I_in[MAX_CNT], IQ_t Q_in[MAX_CNT], AGC_t AGC_I[MAX_CNT], AGC_t AGC_Q[MAX_CNT])
{
    static coef_t old_coef = 0;
    static bool initial_time = true;
    int i;

    ac_fixed<19, 5, false> ave = 0; // I just widen 1bit 
    for(i = 0; i < MAX_CNT; i++)
    {

        if(I_in[i] > 0)
            ave = ave + I_in[i];
        else
            ave = ave - I_in[i];

        if(Q_in[i] > 0)
            ave = ave + Q_in[i];
        else
            ave = ave - Q_in[i];
    }

    coef_t coef, coef_now;
    coef_now = ave * (ac_fixed<9, 2>)(2.828);

    if(initial_time)
        coef = coef_now;
    else
        coef = (coef_now + old_coef) >> 1;

    initial_time = false;
    old_coef = coef;

    ac_fixed<8, 1, true, AC_TRN, AC_SAT_SYM> out;
    //int bit_sign=coef.leading_sign();
    int bit_sign = coef.slc<11>(5);
    if (bit_sign == 0)
    {
        for(i = 0; i < 16; i++)
        {
            out = I_in[i] << 7;
            AGC_I[i] = out;
            out = Q_in[i] << 7;
            AGC_Q[i] = out;
        }
    }
    else
    {
        for(i = 0; i < 16; i++)
        {
            out = I_in[i] * 16 / coef;
            AGC_I[i] = out;
            out = Q_in[i] * 16 / coef;
            AGC_Q[i] = out;
        }
    }
}

#if 0
#include "matlab_engine.h"
#include "matlab_template.h"

int main(int argc, char *argv[])
{
	int i;

	Engine *ep=MyEngineInit();

	IQ_t I_in[MAX_CNT] = {	-0.9355, +0.9169, +0.4103, -0.8936, -0.0579, +0.3529, 0.8132,-0.0099, 0.1389, 0.2028, 0.1987, +0.6038, -0.2722, 0.1988,-0.0153, 0.7468,-0.4451, -0.9318, +0.4660, -0.4186, +0.8462, -0.5252, 0.2026,-0.6721, 0.8381, 0.0196, 0.6813, -0.3795, +0.8318, 0.5028,-0.7095, 0.4289	};
	IQ_t Q_in[MAX_CNT] = {	-0.4451, -0.9318, +0.4660, -0.4186, +0.8462, -0.5252, 0.2026,-0.6721, 0.8381, 0.0196, 0.6813, -0.3795, +0.8318, 0.5028,-0.7095, 0.4289,-0.9355, +0.9169, +0.4103, -0.8936, -0.0579, +0.3529, 0.8132,-0.0099, 0.1389, 0.2028, 0.1987, +0.6038, -0.2722, 0.1988,-0.0153, 0.7468	};


	MyACPut(ep,"I_in",I_in,MAX_CNT);
	MyACPut(ep,"Q_in",Q_in,MAX_CNT);

	AGC_t I_out[MAX_CNT];
	AGC_t Q_out[MAX_CNT];

	agc(I_in, Q_in, I_out, Q_out);

	MyACPut(ep,"I_out",I_out,MAX_CNT);
	MyACPut(ep,"Q_out",Q_out,MAX_CNT);

	return 0;
}

#endif
