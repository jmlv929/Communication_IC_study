#ifndef _GOLD_SN_H
#define _GOLD_SN_H

//#include "iostream.h"
#include <stdio.h>

#include "ac_int.h"
#include "ac_fixed.h"
typedef ac_int<25, false> GOLD_t;

void gold_sn(GOLD_t seed, bool sf[256]);
//#define GOLD_init_seed 0x000001 //1FFF001

#define GOLD_init_seed 0x1000000

#endif
