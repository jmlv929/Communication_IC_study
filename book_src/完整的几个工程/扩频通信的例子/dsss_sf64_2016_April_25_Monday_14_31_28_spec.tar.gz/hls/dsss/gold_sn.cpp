#include "gold_sn.h"

#pragma design
void gold_sn(GOLD_t seed, bool sf[256])
{
    int i;
    GOLD_t pn1;
    GOLD_t pn2;
    bool pn1_bit0;
    bool pn2_bit0;

    pn1 = GOLD_init_seed;
    pn2 = seed;

    // pn1[0]<= #ud pn1[3] ^ pn1[24];
    // pn2[0]<= #ud pn2[3] ^ pn2[2] ^ pn2[1] ^ pn2[24];

    for(i = 0; i < 256; i++)
    {
        sf[i] = pn1[24] ^ pn2[24];
        pn1_bit0 = pn1[2] ^ pn1[24];
        pn2_bit0 = pn2[2] ^ pn2[1] ^ pn2[0] ^ pn2[24];
        pn1 = pn1 << 1;
        pn2 = pn2 << 1;
        pn1[0] = pn1_bit0;
        pn2[0] = pn2_bit0;
    }
}
