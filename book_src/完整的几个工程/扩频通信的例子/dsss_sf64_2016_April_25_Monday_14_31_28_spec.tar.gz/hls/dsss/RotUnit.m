%% RotUnit

agc1=AGC_I.*(1-2*gold_sn);
agc2=AGC_Q.*(1-2*gold_sn);

sum1=dot(AGC_I,(1-2*gold_sn));
sum2=dot(AGC_Q,(1-2*gold_sn));

agc_complex=sum1+1i*sum2;
rot_complex =rot_cos+1i*rot_sin;
rot_complex1=rot_cos-1i*rot_sin;
out=agc_complex*rot_complex;
out1=agc_complex*rot_complex1;
acc1=real(out);
acc2=imag(out);
acc3=real(out1);
acc4=imag(out1);