#ifndef _CHANNEL_H
#define _CHANNEL_H
#include "stdio.h"
#include <math.h>
#include <stdlib.h>

#include "ac_int.h"
#include "ac_fixed.h"

#define COSSIN_WIDTH 11
#define ACC_WIDTH 17
#define PPM_WIDTH 16
#define BIT_WIDTH 8
typedef ac_fixed<14, 1, true> IQ_t;
typedef ac_fixed< 8, 1, true> AGC_t;
typedef ac_fixed<17, 6, false> coef_t;
typedef ac_fixed<8, 1> TX_t;

void channel(TX_t tx_I[], TX_t tx_Q[], IQ_t tx_I_out[], IQ_t tx_Q_out[], float snr, int freq, int init_phase, int max_len, float scale_size);


#endif

