#ifndef _TX_H
#define _TX_H

//#include "iostream.h"
#include <stdio.h>

#include "ac_int.h"
#include "ac_fixed.h"

typedef ac_int<3, false> SF_t;

typedef ac_int<25, false> GOLD_t;
typedef ac_fixed<8, 1> TX_t;

void dsss_core(bool bit_in, bool gold_sn[256], int sf_len, TX_t tx_I[256], TX_t tx_Q[256]);
void tx_core(bool tx_bit[32 * 8 + 32], int shr_len, int psdu_len, bool psdu_gold_sn[256], bool shr_gold_sn[256], SF_t psdu_sf, SF_t shr_sf, TX_t tx_I[32 * 8 * 256 + 32 * 256], TX_t tx_Q[32 * 8 * 256 + 32 * 256], int &dsss_tx_len);
int sf_len(int sf);

#endif
