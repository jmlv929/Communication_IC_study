#include "fc_core_new.h"

#pragma design
void rotate_unit(AGC_t AGC_I[UNIT_SIZE], AGC_t AGC_Q[UNIT_SIZE], SIN_t rot_sin, SIN_t rot_cos, bool gold_sn[UNIT_SIZE], ACC_SIN_t &acc_Icos_add_Qsin, ACC_SIN_t &acc_Icos_sub_Qsin, ACC_SIN_t &acc_Isin_add_Qcos, ACC_SIN_t &acc_Isin_sub_Qcos)
{

	int j;
	//every phase is 8 chips

	PHASE_SUM_t sum_I_phase, sum_Q_phase;
	PHASE_SUM_t mul_Icos, mul_Qcos, mul_Isin, mul_Qsin;

	sum_I_phase = 0;
	sum_Q_phase = 0;
	for(j = 0; j < UNIT_SIZE; j++)
	{
		sum_I_phase = (gold_sn[j]==true) ? (sum_I_phase - AGC_I[j]): (sum_I_phase + AGC_I[j]);
		sum_Q_phase = (gold_sn[j]==true) ? (sum_Q_phase - AGC_Q[j]): (sum_Q_phase + AGC_Q[j]);
	}

	mul_Icos = sum_I_phase * rot_cos;
	mul_Isin = sum_I_phase * rot_sin;
	mul_Qcos = sum_Q_phase * rot_cos;
	mul_Qsin = sum_Q_phase * rot_sin;

	acc_Icos_sub_Qsin = mul_Icos - mul_Qsin;
	acc_Icos_add_Qsin = mul_Icos + mul_Qsin;
	acc_Isin_sub_Qcos = mul_Qcos - mul_Isin; 
	acc_Isin_add_Qcos = mul_Qcos + mul_Isin; 
}

#pragma design
void BitFC(AGC_t AGC_I[256], AGC_t AGC_Q[256], bool gold_sn[256],ANGLE_t init_ppm_cnt,ANGLE_t inc_ppm,SF_t use_sf,BIT_SUM_t &acc_neg,BIT_SUM_t &acc_pos,bool &neg_bit,bool &pos_bit)
{
	ACC_SIN_t acc_Icos_add_Qsin[32], acc_Icos_sub_Qsin[32], acc_Isin_add_Qcos[32], acc_Isin_sub_Qcos[32];
	BIT_ACC_SIN_t bit_acc_Icos_add_Qsin,bit_acc_Icos_sub_Qsin,bit_acc_Isin_add_Qcos,bit_acc_Isin_sub_Qcos;
	BIT_ACC_SIN_t abs_bit_acc_Icos_add_Qsin,abs_bit_acc_Icos_sub_Qsin,abs_bit_acc_Isin_add_Qcos,abs_bit_acc_Isin_sub_Qcos;
	ANGLE_mult_t theta_full;
	//ABS_ACC_SUM_SIN_t acc_pos, acc_neg;
	ac_int<2,false> cos_sin_sig;
	SIN_t rot_cos, rot_sin;
	SIN_t tmp_rot_sin, tmp_rot_cos;

	int unit_ptr;
	PPM_INDEX_t lut_index;
	int n;
	for(n = 0; n < 32; n++)
	{
		unit_ptr=n*8;
		//               theta_full = (248 - n*8 + 4) * inc_ppm + init_ppm; // use half N0.4 point as whole 8 points freqency offset
		theta_full = (n*8+4+ init_ppm_cnt) * inc_ppm ; // use half N0.4 point as whole 8 points freqency offset
		lut_index = theta_full.slc<6>(8); //lut_index=theta_full[6+8-1:6];
#ifdef _DEBUG
		float angle,sin_i,cos_i;
		angle=3.1415926*theta_full.to_double()/pow(2.0,15);
		sin_i=sin(angle);
		cos_i=cos(angle);
#endif
		cos_sin_sig = theta_full.slc<2>(14);
		tmp_rot_sin = sin_tab[lut_index];
		tmp_rot_cos = cos_tab[lut_index];
		switch(cos_sin_sig){
		case 0:rot_cos=tmp_rot_cos;
			rot_sin=tmp_rot_sin;
			break;
		case 1:rot_sin=tmp_rot_cos;
			rot_cos=-tmp_rot_sin;
			break;
		case 2:rot_cos=-tmp_rot_cos;
			rot_sin=-tmp_rot_sin;
			break;
		default:rot_sin=-tmp_rot_cos;
			rot_cos=tmp_rot_sin;
			break;
		}
#ifdef _DEBUG_BitFC
		MyACPut(ep,"AGC_I",&AGC_I[unit_ptr],8,unit_ptr);
		MyACPut(ep,"AGC_Q",&AGC_Q[unit_ptr],8,unit_ptr);
		MyACPut(ep,"gold_sn",&gold_sn[unit_ptr],8,unit_ptr);
		MyACPut(ep,"rot_sin",&rot_sin,1,n);
		MyACPut(ep,"rot_cos",&rot_cos,1,n);
		MyACPut(ep,"theta_full",&theta_full,1,n);
#endif
		rotate_unit(&AGC_I[unit_ptr], &AGC_Q[unit_ptr], rot_sin, rot_cos, &gold_sn[unit_ptr], acc_Icos_add_Qsin[n], acc_Icos_sub_Qsin[n], acc_Isin_add_Qcos[n], acc_Isin_sub_Qcos[n]);
#ifdef _DEBUG_BitFC
		MyACPut(ep,"AGC_I",&AGC_I[unit_ptr],8,unit_ptr);
		MyACPut(ep,"AGC_Q",&AGC_Q[unit_ptr],8,unit_ptr);
		MyACPut(ep,"gold_sn",&gold_sn[unit_ptr],8,unit_ptr);
		MyACPut(ep,"rot_sin",&rot_sin,1,n);
		MyACPut(ep,"rot_cos",&rot_cos,1,n);
		MyACPut(ep,"theta_full",&theta_full,1,n);

		MyACPut(ep,"acc_Icos_add_Qsin",&acc_Icos_add_Qsin[n],1,n);
		MyACPut(ep,"acc_Icos_sub_Qsin",&acc_Icos_sub_Qsin[n],1,n);
		MyACPut(ep,"acc_Isin_add_Qcos",&acc_Isin_add_Qcos[n],1,n);
		MyACPut(ep,"acc_Isin_sub_Qcos",&acc_Isin_sub_Qcos[n],1,n);
#endif
	}

	for(n = 0; n < 32; n++)
	{

		switch(use_sf)
		{
		case 0:
			if(n < 2)
			{
				if(n==0){
					bit_acc_Icos_add_Qsin = acc_Icos_add_Qsin[0];
					bit_acc_Icos_sub_Qsin = acc_Icos_sub_Qsin[0];
					bit_acc_Isin_add_Qcos = acc_Isin_add_Qcos[0];
					bit_acc_Isin_sub_Qcos = acc_Isin_sub_Qcos[0];
				} else {

					bit_acc_Icos_add_Qsin = bit_acc_Icos_add_Qsin+acc_Icos_add_Qsin[n];
					bit_acc_Icos_sub_Qsin = bit_acc_Icos_sub_Qsin+acc_Icos_sub_Qsin[n];
					bit_acc_Isin_add_Qcos = bit_acc_Isin_add_Qcos+acc_Isin_add_Qcos[n];
					bit_acc_Isin_sub_Qcos = bit_acc_Isin_sub_Qcos+acc_Isin_sub_Qcos[n];
				}

			} 
			break;

		case 1:
			if(n < 4)
			{
				if(n==0){
					bit_acc_Icos_add_Qsin = acc_Icos_add_Qsin[0];
					bit_acc_Icos_sub_Qsin = acc_Icos_sub_Qsin[0];
					bit_acc_Isin_add_Qcos = acc_Isin_add_Qcos[0];
					bit_acc_Isin_sub_Qcos = acc_Isin_sub_Qcos[0];
				} else {

					bit_acc_Icos_add_Qsin = bit_acc_Icos_add_Qsin+acc_Icos_add_Qsin[n];
					bit_acc_Icos_sub_Qsin = bit_acc_Icos_sub_Qsin+acc_Icos_sub_Qsin[n];
					bit_acc_Isin_add_Qcos = bit_acc_Isin_add_Qcos+acc_Isin_add_Qcos[n];
					bit_acc_Isin_sub_Qcos = bit_acc_Isin_sub_Qcos+acc_Isin_sub_Qcos[n];
				}

			} 
			break;
		case 2:
			if(n < 8)
			{
				if(n==0){
					bit_acc_Icos_add_Qsin = acc_Icos_add_Qsin[0];
					bit_acc_Icos_sub_Qsin = acc_Icos_sub_Qsin[0];
					bit_acc_Isin_add_Qcos = acc_Isin_add_Qcos[0];
					bit_acc_Isin_sub_Qcos = acc_Isin_sub_Qcos[0];
				} else {

					bit_acc_Icos_add_Qsin = bit_acc_Icos_add_Qsin+acc_Icos_add_Qsin[n];
					bit_acc_Icos_sub_Qsin = bit_acc_Icos_sub_Qsin+acc_Icos_sub_Qsin[n];
					bit_acc_Isin_add_Qcos = bit_acc_Isin_add_Qcos+acc_Isin_add_Qcos[n];
					bit_acc_Isin_sub_Qcos = bit_acc_Isin_sub_Qcos+acc_Isin_sub_Qcos[n];
				}

			} 
			break;
		case 3: // sf =128
			if(n < 16)
			{
				if(n==0){
					bit_acc_Icos_add_Qsin = acc_Icos_add_Qsin[0];
					bit_acc_Icos_sub_Qsin = acc_Icos_sub_Qsin[0];
					bit_acc_Isin_add_Qcos = acc_Isin_add_Qcos[0];
					bit_acc_Isin_sub_Qcos = acc_Isin_sub_Qcos[0];
				} else {

					bit_acc_Icos_add_Qsin = bit_acc_Icos_add_Qsin+acc_Icos_add_Qsin[n];
					bit_acc_Icos_sub_Qsin = bit_acc_Icos_sub_Qsin+acc_Icos_sub_Qsin[n];
					bit_acc_Isin_add_Qcos = bit_acc_Isin_add_Qcos+acc_Isin_add_Qcos[n];
					bit_acc_Isin_sub_Qcos = bit_acc_Isin_sub_Qcos+acc_Isin_sub_Qcos[n];
				}

			} 
			break;
		default:  // sf =256
			if(n==0){
				bit_acc_Icos_add_Qsin = acc_Icos_add_Qsin[0];
				bit_acc_Icos_sub_Qsin = acc_Icos_sub_Qsin[0];
				bit_acc_Isin_add_Qcos = acc_Isin_add_Qcos[0];
				bit_acc_Isin_sub_Qcos = acc_Isin_sub_Qcos[0];
			} else {

				bit_acc_Icos_add_Qsin = bit_acc_Icos_add_Qsin+acc_Icos_add_Qsin[n];
				bit_acc_Icos_sub_Qsin = bit_acc_Icos_sub_Qsin+acc_Icos_sub_Qsin[n];
				bit_acc_Isin_add_Qcos = bit_acc_Isin_add_Qcos+acc_Isin_add_Qcos[n];
				bit_acc_Isin_sub_Qcos = bit_acc_Isin_sub_Qcos+acc_Isin_sub_Qcos[n];
			}



		} 
	}           

	neg_bit = bit_acc_Icos_add_Qsin > 0 ? 0 : 1;
	pos_bit = bit_acc_Icos_sub_Qsin > 0 ? 0 : 1;

	abs_bit_acc_Icos_add_Qsin = bit_acc_Icos_add_Qsin > 0 ? bit_acc_Icos_add_Qsin : -bit_acc_Icos_add_Qsin;
	abs_bit_acc_Icos_sub_Qsin = bit_acc_Icos_sub_Qsin > 0 ? bit_acc_Icos_sub_Qsin : -bit_acc_Icos_sub_Qsin;
	abs_bit_acc_Isin_add_Qcos = bit_acc_Isin_add_Qcos > 0 ? bit_acc_Isin_add_Qcos : -bit_acc_Isin_add_Qcos;
	abs_bit_acc_Isin_sub_Qcos = bit_acc_Isin_sub_Qcos > 0 ? bit_acc_Isin_sub_Qcos : -bit_acc_Isin_sub_Qcos;

	if(abs_bit_acc_Icos_sub_Qsin > abs_bit_acc_Isin_add_Qcos)
	{
		acc_pos = abs_bit_acc_Icos_sub_Qsin + abs_bit_acc_Isin_add_Qcos / 2 ;
	}
	else
	{
		acc_pos = abs_bit_acc_Icos_sub_Qsin / 2 + abs_bit_acc_Isin_add_Qcos;
	}
	if(abs_bit_acc_Icos_add_Qsin > abs_bit_acc_Isin_sub_Qcos)
	{
		acc_neg = abs_bit_acc_Icos_add_Qsin + abs_bit_acc_Isin_sub_Qcos / 2;
	}
	else
	{
		acc_neg = abs_bit_acc_Icos_add_Qsin / 2 + abs_bit_acc_Isin_sub_Qcos;
	}


}

#pragma design
void fc_top(bool psdu_or_shr,bool synch_stage,AGC_t AGC_I[FULL_CHIP_NUM], AGC_t AGC_Q[FULL_CHIP_NUM], bool psdu_gold_sn[256], bool shr_gold_sn[256], SF_t psdu_sf, SF_t shr_sf, bool &decode_bit, ABS_ACC_SUM_SIN_t &max_acc, ANGLE_t &max_ppm, bool &neg_or_pos, PPM_INDEX_t &max_index)
{

	ANGLE_t init_ppm_cnt[8],inc_ppm,delta_ppm;
	SF_t use_sf;
	int i,ppm_i,bit_i;
	BIT_SUM_t bit_acc_neg[8],bit_acc_pos[8];
	BIT8_SUM_t bit8_acc_neg,bit8_acc_pos;
	bool pos_bit[8], neg_bit[8],gold_sn[256] ;
	int len;
	int bit_ptr;
	decode_bit=0;
	max_acc=0;

	if(psdu_or_shr)
	{
		use_sf = psdu_sf;
		for(i = 0; i < 256; i++) gold_sn[i] = psdu_gold_sn[i];
		delta_ppm = 3; // 0.1ppm
	}
	else
	{
		use_sf = shr_sf;
		for(i = 0; i < 256; i++) gold_sn[i] = shr_gold_sn[i];
		delta_ppm = 301; // 1ppm
	}

	switch (use_sf) // 000: 16 sf;001:32 sf ; 010: 64 sf; 011:128 sf; 100: 256 sf; 101~111: reserved
	{
	case  0: len= 16;break;//  16 sf
	case  1: len= 32;break;//  32 sf
	case  2: len= 64;break;//  64 sf
	case  3: len=128;break;// 128 sf
	default: len=256;break;// 256 sf
	}   

	for(ppm_i=0;ppm_i<40;ppm_i++){
		if(ppm_i==0)
			inc_ppm=0;
		else
			inc_ppm=inc_ppm+delta_ppm;
		for(bit_i=0;bit_i<8;bit_i++)
		{
			//init_ppm[bit_i]= len*(7-bit_i)*inc_ppm;// can be init_ppm[i]= len*bit_i*inc_ppm;
			init_ppm_cnt[bit_i]= len*bit_i*inc_ppm;// can be init_ppm[i]= len*bit_i*inc_ppm;
			bit_ptr=len*bit_i;

#ifdef _DEBUG_fc_top
			MyACPut(ep,"AGC_I",&AGC_I[bit_ptr],len,bit_ptr);
			MyACPut(ep,"AGC_Q",&AGC_Q[bit_ptr],len,bit_ptr);
			MyACPut(ep,"gold_sn",gold_sn,len);
			MyACPut(ep,"init_ppm",&init_ppm_cnt[bit_i],1,bit_i);
			MyACPut(ep,"inc_ppm",&inc_ppm,1,bit_i);

			MyACPut(ep,"bit_i",&bit_i,1);
			MyACPut(ep,"ppm_i",&ppm_i,1);
#endif
			BitFC(&AGC_I[bit_ptr],&AGC_Q[bit_ptr],gold_sn,init_ppm_cnt[bit_i],inc_ppm,use_sf,bit_acc_neg[bit_i],bit_acc_pos[bit_i],neg_bit[bit_i],pos_bit[bit_i]);
#ifdef _DEBUG_fc_top
			MyACPut(ep,"AGC_I",&AGC_I[bit_ptr],len,bit_ptr);
			MyACPut(ep,"AGC_Q",&AGC_Q[bit_ptr],len,bit_ptr);
			MyACPut(ep,"gold_sn",gold_sn,len);
			MyACPut(ep,"init_ppm",&init_ppm_cnt[bit_i],1,bit_i);
			MyACPut(ep,"inc_ppm",&inc_ppm,1,bit_i);

			MyACPut(ep,"bit_i",&bit_i,1);
			MyACPut(ep,"ppm_i",&ppm_i,1);

			MyACPut(ep,"bit_acc_neg",&bit_acc_neg[bit_i],1,bit_i);
			MyACPut(ep,"bit_acc_pos",&bit_acc_pos[bit_i],1,bit_i);
			engEvalString(ep,"BitFC");
#endif
		}

		if(synch_stage){

			for(bit_i=0;bit_i<8;bit_i++){
				if(bit_acc_pos[bit_i]>max_acc)
					max_acc=bit_acc_pos[bit_i];
				max_index = ppm_i;
				max_ppm = inc_ppm;
				neg_or_pos = 0;
				decode_bit=bit_acc_pos[bit_i]<0;
			}
			if(bit_acc_neg[bit_i]>max_acc){
				max_acc = bit8_acc_neg;
				max_index = ppm_i;
				max_ppm = inc_ppm;
				neg_or_pos = 1;
				decode_bit=bit_acc_neg[bit_i]<0;
			}
#ifdef _DEBUG
			printf("ppm %d : max_acc=%f ppm_acc_pos=%f ppm_acc_neg=%f\n",ppm_i,max_acc.to_double(),bit_acc_neg[0].to_double(),bit_acc_pos[0].to_double());
#endif
		}
		else {
			bit8_acc_pos=0;
			bit8_acc_neg=0;

			for(bit_i=0;bit_i<8;bit_i++){
				bit8_acc_pos=bit8_acc_pos+bit_acc_pos[bit_i];
				bit8_acc_neg=bit8_acc_neg+bit_acc_neg[bit_i];
			}

			if(bit8_acc_pos>max_acc){
				max_acc = bit8_acc_pos;
				max_index = ppm_i;
				max_ppm = inc_ppm;
				neg_or_pos = 0;
			}
			if(bit8_acc_neg>max_acc){
				max_acc = bit8_acc_neg;
				max_index = ppm_i;
				max_ppm = inc_ppm;
				neg_or_pos = 1;
			}
#ifdef _DEBUG
			printf("ppm %d : max_acc=%f ppm_acc_pos=%f ppm_acc_neg=%f\n",ppm_i,max_acc.to_double(),bit8_acc_neg.to_double(),bit8_acc_pos.to_double());
#endif

		}
	}
}



