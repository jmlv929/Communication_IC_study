#include"dsss_tx.h"

void dsss_core(bool bit_in, bool gold_sn[256], int sf_len, TX_t tx_I[256], TX_t tx_Q[256])
{
    int i;
    for(i = 0; i < sf_len; i++)
    {
        if(bit_in)
            tx_I[i] = gold_sn[i] ? -0.5 : 0.5;
        else
        {
            tx_I[i] = gold_sn[i] ? 0.5 : -0.5;
        }
        tx_Q[i] = 0;
    }

}

void tx_core(bool tx_bit[32 * 8 + 32], int shr_len, int psdu_len, bool psdu_gold_sn[256], bool shr_gold_sn[256], SF_t psdu_sf, SF_t shr_sf, TX_t tx_I[32 * 8 * 256 + 32 * 256], TX_t tx_Q[32 * 8 * 256 + 32 * 256], int &dsss_tx_len)
{
    int i;
    int shr_sf_len, psdu_sf_len;
    shr_sf_len = sf_len(shr_sf);
    dsss_tx_len = 0;
    for(i = 0; i < shr_len; i++)
    {
        dsss_core(tx_bit[i], shr_gold_sn, shr_sf_len, &tx_I[dsss_tx_len], &tx_Q[dsss_tx_len]);
        dsss_tx_len += shr_sf_len;
    }

    psdu_sf_len = sf_len(psdu_sf);
        
    for(i = 0; i < psdu_len; i++)
    {
        dsss_core(tx_bit[i + shr_len], psdu_gold_sn, psdu_sf_len, &tx_I[dsss_tx_len], &tx_Q[dsss_tx_len]);
        dsss_tx_len += psdu_sf_len;
    }
}

int sf_len(int sf)
{
	int shr_sf_len;
	switch(sf)
	{
	case 0:
		shr_sf_len = 16;
		break;
	case 1:
		shr_sf_len = 32;
		break;
	case 2:
		shr_sf_len = 64;
		break;
	case 3:
		shr_sf_len = 128;
		break;
	case 4:
		shr_sf_len = 256;
		break;
	default:
		shr_sf_len = 16;
		break;
	}
	return shr_sf_len;
}
