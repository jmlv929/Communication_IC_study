% BitFC

agcsum1=dot(AGC_I,(1-2*gold_sn));
agcsum2=dot(AGC_Q,(1-2*gold_sn));

agc_complex=agcsum1+1i*agcsum2;
%theta_full = (n*8+4) * inc_ppm + init_ppm;
ppm_1=920*5*1e-6*2*pi;
ppm_1_int=ppm_1/(2*pi)*2^16;
ppm_dot1=ppm_1*0.1;
ppm_use=ppm_i*ppm_dot1*[10,-10];

chip_index=bit_i*bit_len;

for debug_ppm_i=1:length(ppm_use)
  gold1=(1-2*gold_sn);
  agc_c=AGC_I+1i*AGC_Q;
  sn=1:length(agc_c);
  sn1=sn+chip_index;
  rot_sn=exp(1j*ppm_use(debug_ppm_i)*sn1);
  rot_agc=rot_sn.*agc_c;
  fcsum1=dot(rot_agc,gold1);
  bit_r(debug_ppm_i)=abs(fcsum1);
  
  
  n=length(agc_c)/8;
  gold1=(1-2*gold_sn);
  for i=1:n
    si=(i-1)*8+1:i*8;
    agc_c1(si)=agc_c(si);
    gold2=gold1(si);
    theta_index(debug_ppm_i,i)=ppm_use(debug_ppm_i)*(8*i-4+chip_index);
    rot_i(debug_ppm_i,i)=exp(theta_index(debug_ppm_i,i)*1j);
    rot_agc_c1(si)=rot_i(debug_ppm_i,i)*agc_c1(si);
    dif_rot_agc(si)=rot_agc_c1(si)-rot_agc(si);
    fcsum2(debug_ppm_i,i)=dot(rot_agc_c1(si),gold2);
  end
  fcsum3(debug_ppm_i)=sum(fcsum2(debug_ppm_i,:));
  bit_r1(debug_ppm_i)=abs(fcsum3(debug_ppm_i));
end

theta_int=floor(theta_index/(2*pi)*2^16)
theta_int1=mod(theta_int,2^16)
