#include "mex.h"
#include "fc_core_new.h"
//�ӿڹ���
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    double x, *y;
    int n;
    // fc_top(synch_stage,AGC_I,AGC_Q,psdu_gold_sn,shr_gold_sn,psdu_sf,shr_sf,decode_bit,max_acc,max_ppm,neg_or_pos,max_index);

    if (nrhs != 7)
    {
        mexErrMsgTxt("7 inputs required.Argument should be \n :fc_top(synch_stage,AGC_I,AGC_Q,psdu_gold_sn,shr_gold_sn,psdu_sf,shr_sf,decode_bit,max_acc,max_ppm,neg_or_pos,max_index);");
    }
    if (nlhs != 5)
        mexErrMsgTxt("5 outputs required.Argument should be \n :fc_top(synch_stage,AGC_I,AGC_Q,psdu_gold_sn,shr_gold_sn,psdu_sf,shr_sf,decode_bit,max_acc,max_ppm,neg_or_pos,max_index);");
    if (!mxIsDouble(prhs[0]) || mxGetN(prhs[0])*mxGetM(prhs[0]) != 1)
        mexErrMsgTxt("Input must be scalars.");
    x = mxGetScalar(prhs[0]);
    plhs[0] = mxCreateDoubleMatrix(x, x, mxREAL);
    n = mxGetM(plhs[0]);
    y = mxGetPr(plhs[0]);
    
}
