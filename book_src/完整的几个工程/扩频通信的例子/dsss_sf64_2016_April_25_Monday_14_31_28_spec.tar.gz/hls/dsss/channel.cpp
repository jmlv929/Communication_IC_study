#include"channel.h"

void channel(TX_t tx_I[], TX_t tx_Q[], IQ_t tx_I_out[], IQ_t tx_Q_out[], float snr, int freq, int init_phase, int max_len, float scale_size)
{
    int i;

    float Eb_No_dB, Eb_No, CodeRate, use_SNR, std_dev;
    float noise;
    Eb_No_dB = snr; //
    Eb_No = pow(10, (Eb_No_dB / 10));
    CodeRate = 1; //Since it is uncoded
    use_SNR = Eb_No * CodeRate;
    std_dev = sqrt(1 / use_SNR / 2);

    float temp_i, temp_q;

    float base_angle, inc_angle, init_theta;
    inc_angle = 1.0 / (1L << 15) * freq * 3.1415926;
    init_theta = 1.0 / (1L << 15) * init_phase * 3.1415926;

    //	for(i=0;i<max_len;i++)
    //	{
    //		base_angle=(i*inc_angle+init_theta);
    //		noise=std_dev*(rand()/RAND_MAX-1);
    //		temp_i=tx_I[i].to_double()+noise;
    //		noise=std_dev*(rand()/RAND_MAX-1);
    //		temp_q=tx_Q[i].to_double()+noise;
    //
    //		// add freqency offset
    //		tx_I_out[i]=temp_i*cos(base_angle)-temp_q*sin(base_angle);
    //		tx_Q_out[i]=temp_i*sin(base_angle)+temp_q*cos(base_angle);
    //	}

    for(i = 0; i < max_len; i++)
    {
        // add freqency offset
        base_angle = (i * inc_angle + init_theta);
        temp_i = tx_I[i].to_double() * cos(base_angle) - tx_Q[i].to_double() * sin(base_angle);
        temp_q = tx_I[i].to_double() * sin(base_angle) + tx_Q[i].to_double() * cos(base_angle);

        // add noise
        noise = std_dev * (2.0*rand() / RAND_MAX - 1);
        tx_I_out[i] = (temp_i + noise) * scale_size;
        noise = std_dev * (2.0*rand() / RAND_MAX - 1);
        tx_Q_out[i] = (temp_q + noise) * scale_size;
    }
}

// function [I_WaveformRx,Q_WaveformRx] =AWGNChannel(I_WaveformTx,Q_WaveformTx,No)
//
// lenI_Waveform = length(I_WaveformTx);
// lenQ_Waveform = length(Q_WaveformTx);
//
// noiseStdDeviation = sqrt(No/2);
// I_WaveformRx=I_WaveformTx + noiseStdDeviation*randn(1,lenI_Waveform);
// Q_WaveformRx= Q_WaveformTx + noiseStdDeviation*randn(1,lenQ_Waveform);
// I_WaveformRx=awgn(I_WaveformTx,SNR)
// Q_WaveformRx=awgn(Q_WaveformTx,SNR)
