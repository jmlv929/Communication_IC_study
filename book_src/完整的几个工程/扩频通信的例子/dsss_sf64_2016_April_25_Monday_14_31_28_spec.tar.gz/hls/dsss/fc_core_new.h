#ifndef _FC_CORE_NEW_H
#define _FC_CORE_NEW_H

//#include "iostream.h"
#include <stdio.h>

#include "ac_int.h"
#include "ac_fixed.h"

//#define _DEBUG_MATLAB 1 // internal variable will dump in matlab
//#undef  _DEBUG_MATLAB

#ifdef _DEBUG_MATLAB
#include "matlab_engine.h"
#define  _DEBUG_fc_top 1
//#define  _DEBUG_BitFC 1
//#define  _DEBUG_rotate_unit 1

#endif

#define COSSIN_WIDTH 11
#define ACC_WIDTH 17
#define PPM_WIDTH 16

#define BIT_WIDTH 8

#define FULL_CHIP_NUM 256*8
#define UNIT_NUM 64
#define UNIT_SIZE 8
#define PHASE_NUM 4

#define PPM_NUM 40
#define PPM_INDEX_W 6
#define PHASE_BIT 3
#define SUM_BIT 4
#define SIN_BIT 4
#define ACC_SIN_BIT 3
//input [2:0] psdu_sf, // 000: 16 sf;001:32 sf ; 010: 64 sf; 011:128 sf; 100: 256 sf; 101~111: reserved
//input [2:0] shr_sf,  // 000: 16 sf;001:32 sf ; 010: 64 sf; 011:128 sf; 100: 256 sf; 101~111: reserved
typedef ac_int<3, false> SF_t;

typedef ac_fixed<BIT_WIDTH, 1, true> AGC_t;
typedef ac_fixed<BIT_WIDTH, 1, true> SIN_t;
typedef ac_fixed < BIT_WIDTH + ACC_SIN_BIT, ACC_SIN_BIT + 1, true, AC_TRN, AC_SAT_SYM > ACC_SIN_t;
typedef ac_int<16, false> ANGLE_t;
typedef ac_int<18, false> ANGLE_mult_t;
typedef ac_fixed < BIT_WIDTH + SUM_BIT, SUM_BIT + 1, true, AC_TRN, AC_SAT_SYM > SUM_t;

typedef ac_fixed < BIT_WIDTH + 8 + 1, 8 + 1, true > ACC_SUM_SIN_t;
typedef ac_fixed < BIT_WIDTH + 8 + 1, 8 + 1, true > ABS_ACC_SUM_SIN_t;
typedef ac_fixed < BIT_WIDTH + 8 + 1, 8 + 1, true > BIT_ACC_SIN_t;
typedef ac_fixed < BIT_WIDTH + 8 + 1, 8 + 1, true > BIT_SUM_t;
typedef ac_fixed < BIT_WIDTH + 8 + 1, 8 + 1, true > BIT8_SUM_t;

//typedef  ac_int<BIT_WIDTH+8,true> BIT_SUM_t ;
//typedef  ac_int<BIT_WIDTH+8,true> BIT8_SUM_t ;


//typedef ac_fixed < PPM_INDEX_W , 1, false > PPM_INDEX_t;
typedef ac_int < PPM_INDEX_W , false > PPM_INDEX_t;

typedef ac_fixed < BIT_WIDTH + PHASE_BIT, PHASE_BIT, true > PHASE_SUM_t;
typedef ac_fixed < BIT_WIDTH + PHASE_BIT + 1, PHASE_BIT + 1, true > PHASE_SUM_SIN_t;

typedef ac_int<PHASE_BIT, false> PHASE_t;
void rotate_unit(AGC_t AGC_I[UNIT_SIZE], AGC_t AGC_Q[UNIT_SIZE], SIN_t rot_sin, SIN_t rot_cos, bool gold_sn[UNIT_SIZE], ACC_SIN_t &acc_Icos_add_Qsin, ACC_SIN_t &acc_Icos_sub_Qsin, ACC_SIN_t &acc_Isin_add_Qcos, ACC_SIN_t &acc_Isin_sub_Qcos);
void fc_top(bool psdu_or_shr,bool synch_stage, AGC_t *AGC_I, AGC_t *AGC_Q, bool psdu_gold_sn[256], bool shr_gold_sn[256], SF_t psdu_sf, SF_t shr_sf, bool &decode_bit, ABS_ACC_SUM_SIN_t &max_acc, ANGLE_t &max_ppm, bool &neg_or_pos, PPM_INDEX_t &max_index);
void BitFC(AGC_t AGC_I[256], AGC_t AGC_Q[256], bool gold_sn[256],ANGLE_t init_ppm_cnt,ANGLE_t inc_ppm,SF_t use_sf,BIT_SUM_t &bit_acc_neg,BIT_SUM_t &bit_acc_pos,bool &neg_bit,bool &pos_bit);


const SIN_t cos_tab[64] =
{
    0.9999999999999999, // can't use 1 since it will cause overflow
    0.9996988186962042,
    0.9987954562051724,
    0.9972904566786902,
    0.9951847266721969,
    0.9924795345987100,
    0.9891765099647810,
    0.9852776423889412,
    0.9807852804032304,
    0.9757021300385286,
    0.9700312531945440,
    0.9637760657954398,
    0.9569403357322088,
    0.9495281805930367,
    0.9415440651830208,
    0.9329927988347390,
    0.9238795325112867,
    0.9142097557035307,
    0.9039892931234433,
    0.8932243011955153,
    0.8819212643483550,
    0.8700869911087115,
    0.8577286100002721,
    0.8448535652497071,
    0.8314696123025452,
    0.8175848131515837,
    0.8032075314806449,
    0.7883464276266063,
    0.7730104533627370,
    0.7572088465064846,
    0.7409511253549591,
    0.7242470829514670,
    0.7071067811865476,
    0.6895405447370669,
    0.6715589548470183,
    0.6531728429537768,
    0.6343932841636455,
    0.6152315905806268,
    0.5956993044924335,
    0.5758081914178453,
    0.5555702330196023,
    0.5349976198870973,
    0.5141027441932217,
    0.4928981922297841,
    0.4713967368259978,
    0.4496113296546066,
    0.4275550934302822,
    0.4052413140049899,
    0.3826834323650898,
    0.3598950365349883,
    0.3368898533922201,
    0.3136817403988916,
    0.2902846772544623,
    0.2667127574748984,
    0.2429801799032640,
    0.2191012401568698,
    0.1950903220161283,
    0.1709618887603014,
    0.1467304744553617,
    0.1224106751992163,
    0.0980171403295608,
    0.0735645635996675,
    0.0490676743274181,
    0.0245412285229123
};

const SIN_t sin_tab[64] =
{
    0.0000000000000000,
    0.0245412285229123,
    0.0490676743274180,
    0.0735645635996674,
    0.0980171403295606,
    0.1224106751992162,
    0.1467304744553617,
    0.1709618887603012,
    0.1950903220161282,
    0.2191012401568698,
    0.2429801799032639,
    0.2667127574748984,
    0.2902846772544623,
    0.3136817403988915,
    0.3368898533922201,
    0.3598950365349881,
    0.3826834323650898,
    0.4052413140049899,
    0.4275550934302821,
    0.4496113296546065,
    0.4713967368259976,
    0.4928981922297840,
    0.5141027441932217,
    0.5349976198870972,
    0.5555702330196022,
    0.5758081914178453,
    0.5956993044924334,
    0.6152315905806268,
    0.6343932841636455,
    0.6531728429537768,
    0.6715589548470183,
    0.6895405447370668,
    0.7071067811865475,
    0.7242470829514669,
    0.7409511253549591,
    0.7572088465064845,
    0.7730104533627370,
    0.7883464276266062,
    0.8032075314806448,
    0.8175848131515837,
    0.8314696123025452,
    0.8448535652497070,
    0.8577286100002721,
    0.8700869911087113,
    0.8819212643483549,
    0.8932243011955153,
    0.9039892931234433,
    0.9142097557035307,
    0.9238795325112867,
    0.9329927988347388,
    0.9415440651830208,
    0.9495281805930367,
    0.9569403357322089,
    0.9637760657954398,
    0.9700312531945440,
    0.9757021300385286,
    0.9807852804032304,
    0.9852776423889412,
    0.9891765099647810,
    0.9924795345987100,
    0.9951847266721968,
    0.9972904566786902,
    0.9987954562051724,
    0.9996988186962042
};


#endif

