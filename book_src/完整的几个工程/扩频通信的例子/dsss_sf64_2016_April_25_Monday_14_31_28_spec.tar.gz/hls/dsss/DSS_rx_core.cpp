#include "ac_int.h"
#include "sincos.h"

//#define abs(a) ((a>0)?a:-a)
#define COSSIN_WIDTH 11
#define ACC_WIDTH 17
#define PPM_WIDTH 16
#define BIT_WIDTH 8

void dsss_rx_core(
    ac_int<BIT_WIDTH> I[2048],
    ac_int<BIT_WIDTH> Q[2048],
    ac_int<1> gold_sn[256],
    uint16 shr_sf,
    ac_int<PPM_WIDTH> base_fc,
    ac_int<ACC_WIDTH> synch_gate,
    ac_int<1> synch_mode,
    ac_int<ACC_WIDTH> initial_phase_I,
    ac_int<ACC_WIDTH> initial_phase_Q,

    ac_int<1> &synch_ok,
    ac_int<7> &max_index,
    ac_int<ACC_WIDTH, false> &max_value,
    ac_int<PPM_WIDTH> &max_fc,
    ac_int<ACC_WIDTH> &max_phase_I,
    ac_int<ACC_WIDTH> &max_phase_Q,
    ac_int<1> *decode_bit
)
{

    // I/Q latch contain 256 * 8 * 8 bit reg, when in 200KHz, it will save every bit. when in 800KHz, it will save only 1 bit.
    //   Detailed explanation goes here

    ac_int<ACC_WIDTH> acc;
    ac_int<ACC_WIDTH> sigma_I[8], sigma_Q[8];
    ac_int<ACC_WIDTH> max_sigma_I[8], max_sigma_Q[8];

    int i, j, m;

    //bit_number = 8;
    // chip_number = shr_sf * bit_number;
    //upsample_times = 4;

    // 16 bit means -pi is -2^15, pi is (2^15 - 1)
    // -pi/2 is -2^14, pi/2 is (2^14-1), our sin table index is (0~pi/2) and index is 0~63(2^6), which means if input index[15:0],
    // index[15:14] is pos or negative for test & index[13:8] is used by table. the remain bit is for precision control.
    // therefore,delta_f can be expressed as following!

    ac_int<PPM_WIDTH> ppm_1     = 301;// 1ppm, means 2*pi*920*sample_period --> pi*2*920*1/200K=pi*920*e-5 --> = pi*0.0092; --> 301 // a=fi(920*1e-5,1,16,15);storedInteger(a)
    ac_int<PPM_WIDTH> ppm_dot1  = 30 ;// 0.1ppm
    ac_int<PPM_WIDTH> ppm_dot02 = 6  ;// 0.02ppm

    // need change with PPM width
    const int sincos_2pi_mask = (1 << PPM_WIDTH) - 1; //0xffff; // 16 bit index, higher bit will be omit for cycle period.
    const int sincos_table_mask = (1 << (PPM_WIDTH - 2)); //0x3fff; // 14 bit index use, bit15&bit14 will be be used to decide cordination range.
    const int sincos_table_sign_shift = PPM_WIDTH - 8; // high 8 bit is valid for table index.
    const int sin_mask_bit = (1 << (PPM_WIDTH - 2)); //0x4000; // bit14, sin signed =1 which bit 14 is 0
    const int cos_mask_bit = (1 << (PPM_WIDTH - 1)); //0x8000; // bit15, cos signed =1 which bit 15 is 0

    ac_int < PPM_WIDTH + 1 > fc;
    ac_int<PPM_WIDTH> theta[8];

    ac_int < BIT_WIDTH + 1 > bit8_I_sf, bit8_Q_sf;
    ac_int < BIT_WIDTH + 1 > bit_i_cos, bit_q_sin, bit_q_cos, bit_i_sin;

    ac_int<COSSIN_WIDTH> cos_theta, sin_theta;

    max_index = 0;
    max_value = 0;
    max_fc = base_fc; // % if synch_ok==0, it should be 0;
    for(i = 0; i < 8; i++) decode_bit[i] = 0;

    if(synch_mode == 0) // % input data is 800kHz, therefore we calculate 1 times every 4 samples, we work in 200KHz
    {

        fc = base_fc - 32 * ppm_dot1; // % if synch_ok==0, base_fc should be 0,but for debug, we can set it anyway;
        fc = fc & sincos_2pi_mask;

        //for(m = -32; m <= 31; m++)
        for(m = 0; m < 64; m++)
        {
            acc = 0;
            fc = fc + ppm_dot1;
            fc = fc & sincos_2pi_mask;

            for(i = 0; i < 8; i++)
            {
                sigma_I[i] = 0;
                sigma_Q[i] = 0;
            }

            for(j = 0; j < shr_sf; j++)
            {

                for(i = 0; i < 8; i++) // phase dispose for sin cos lookup table.
                {
                    theta[i] = ((i * shr_sf + j) * fc ) & sincos_2pi_mask;
                }

                for(i = 0; i < 8; i++) // % use phase 1, other 3 phase will be discard.
                {
                    uint16 index;
                    index = (i * shr_sf + j);
                    bit8_I_sf[i] =  gold_sn[j] ? (ac_int < BIT_WIDTH + 1 > ) - I[index] : (ac_int < BIT_WIDTH + 1 > )I[index] ; //(upsample_times*shr_sf*(i-1)+upsample_times*(j-1)+1)*gold_sn(j);
                    bit8_Q_sf[i] =  gold_sn[j] ? (ac_int < BIT_WIDTH + 1 > ) - Q[index] : (ac_int < BIT_WIDTH + 1 > )Q[index] ; //(upsample_times*shr_sf*(i-1)+upsample_times*(j-1)+1)*gold_sn(j);

                    int sin_pos, cos_pos;
                    int theta_lookup;
                    theta_lookup = theta[i] & sincos_table_mask;
                    theta_lookup = theta_lookup >> sincos_table_sign_shift;

                    cos_theta = cos_int[theta_lookup];
                    sin_theta = sin_int[theta_lookup];

                    if(theta_lookup & cos_mask_bit)	cos_theta = -cos_theta;
                    if(theta_lookup & sin_mask_bit) sin_theta = -sin_theta;

                    bit_i_cos[i] = (bit8_I_sf[i] * cos_theta) >> COSSIN_WIDTH;
                    bit_i_sin[i] = (bit8_I_sf[i] * sin_theta) >> COSSIN_WIDTH;
                    bit_q_cos[i] = (bit8_Q_sf[i] * cos_theta) >> COSSIN_WIDTH;
                    bit_q_sin[i] = (bit8_Q_sf[i] * sin_theta) >> COSSIN_WIDTH;

                    sigma_I[i] = sigma_I[i] + (bit_i_cos[i] - bit_q_sin[i]);
                    sigma_Q[i] = sigma_Q[i] + (bit_q_cos[i] + bit_i_sin[i]);
                }
            }

            for(i = 0; i < 8; i++) // add i=8;
            {
                ac_int < ACC_WIDTH + 1, false > abs_sigma_I, abs_sigma_Q;
                abs_sigma_I = (sigma_I[i] < 0) ? (ac_int < ACC_WIDTH + 1, false > ) - sigma_I[i] : (ac_int < ACC_WIDTH + 1, false > ) sigma_I[i];
                abs_sigma_Q = (sigma_Q[i] < 0) ? (ac_int < ACC_WIDTH + 1, false > ) - sigma_Q[i] : (ac_int < ACC_WIDTH + 1, false > ) sigma_Q[i];
                acc = acc + abs_sigma_I + abs_sigma_Q;
            }

            if(acc > max_value)
            {
                max_value = acc;
                max_index = m;
                max_fc = fc;

                for(i = 0; i < 8; i++) // add i=8;
                {
                    max_sigma_I[i] = sigma_I[i];
                    max_sigma_Q[i] = sigma_Q[i];
                }
            }

        }
        if(max_value > synch_gate)
        {
            synch_ok = 1;
            max_phase_I = max_sigma_I[7];
            max_phase_Q = max_sigma_Q[7];
        }
        else
            synch_ok = 0;

    }
    else     // % % 800KHz, 0.02ppm , therefore work in 200KHz, we will caculate 4 samples.
    {

        fc = base_fc - 32 * ppm_dot02;
        fc = fc & sincos_2pi_mask;

        for(m = 0; m < 64; m++)
        {
            acc = 0;
            fc = fc + ppm_dot02; // step is 0.02ppm, which means every four bit(800KHz) will have ppm_dot02 frequency offset.
            fc = fc & sincos_2pi_mask;

            for(i = 0; i < 8; i++)
            {
                sigma_I[i] = 0;
                sigma_Q[i] = 0;
            }

            for(j = 0; j < shr_sf; j++)
            {
                uint16 index;
                index = (0 * shr_sf + j) * 4 + 0;

                bit8_I_sf[0] = gold_sn[j] ? (ac_int < ACC_WIDTH + 1, false > ) - I[index] : (ac_int < ACC_WIDTH + 1, false > ) I[index] ; //bit 0,phase 0
                bit8_Q_sf[0] = gold_sn[j] ? (ac_int < ACC_WIDTH + 1, false > ) - Q[index] : (ac_int < ACC_WIDTH + 1, false > ) Q[index] ; //bit 0,phase 0;

                index = (0 * shr_sf + j) * 4 + 1;
                bit8_I_sf[1] = gold_sn[j] ? (ac_int < ACC_WIDTH + 1, false > ) - I[index] : (ac_int < ACC_WIDTH + 1, false > ) I[index] ; //bit 0,phase 1
                bit8_Q_sf[1] = gold_sn[j] ? (ac_int < ACC_WIDTH + 1, false > ) - Q[index] : (ac_int < ACC_WIDTH + 1, false > ) Q[index] ; //bit 0,phase 1;

                index = (0 * shr_sf + j) * 4 + 2;
                bit8_I_sf[2] = gold_sn[j] ? (ac_int < ACC_WIDTH + 1, false > ) - I[index] : (ac_int < ACC_WIDTH + 1, false > ) I[index] ; //bit 0,phase 2
                bit8_Q_sf[2] = gold_sn[j] ? (ac_int < ACC_WIDTH + 1, false > ) - Q[index] : (ac_int < ACC_WIDTH + 1, false > ) Q[index] ; //bit 0,phase 2;

                index = (0 * shr_sf + j) * 4 + 3;
                bit8_I_sf[3] = gold_sn[j] ? (ac_int < ACC_WIDTH + 1, false > ) - I[index] : (ac_int < ACC_WIDTH + 1, false > ) I[index] ; //bit 0,phase 3
                bit8_Q_sf[3] = gold_sn[j] ? (ac_int < ACC_WIDTH + 1, false > ) - Q[index] : (ac_int < ACC_WIDTH + 1, false > ) Q[index] ; //bit 0,phase 3;

                index = (1 * shr_sf + j) * 4 + 0;
                bit8_I_sf[4] = gold_sn[j] ? (ac_int < ACC_WIDTH + 1, false > ) - I[index] : (ac_int < ACC_WIDTH + 1, false > ) I[index] ; //bit 1,phase 0
                bit8_Q_sf[4] = gold_sn[j] ? (ac_int < ACC_WIDTH + 1, false > ) - Q[index] : (ac_int < ACC_WIDTH + 1, false > ) Q[index] ; //bit 1,phase 0;

                index = (1 * shr_sf + j) * 4 + 1;
                bit8_I_sf[5] = gold_sn[j] ? (ac_int < ACC_WIDTH + 1, false > ) - I[index] : (ac_int < ACC_WIDTH + 1, false > ) I[index] ; //bit 1,phase 1
                bit8_Q_sf[5] = gold_sn[j] ? (ac_int < ACC_WIDTH + 1, false > ) - Q[index] : (ac_int < ACC_WIDTH + 1, false > ) Q[index] ; //bit 1,phase 1;

                index = (1 * shr_sf + j) * 4 + 2;
                bit8_I_sf[6] = gold_sn[j] ? (ac_int < ACC_WIDTH + 1, false > ) - I[index] : (ac_int < ACC_WIDTH + 1, false > ) I[index] ; //bit 1,phase 2
                bit8_Q_sf[6] = gold_sn[j] ? (ac_int < ACC_WIDTH + 1, false > ) - Q[index] : (ac_int < ACC_WIDTH + 1, false > ) Q[index] ; //bit 1,phase 2;

                index = (1 * shr_sf + j) * 4 + 3;
                bit8_I_sf[7] = gold_sn[j] ? (ac_int < ACC_WIDTH + 1, false > ) - I[index] : (ac_int < ACC_WIDTH + 1, false > ) I[index] ; //bit 1,phase 3
                bit8_Q_sf[7] = gold_sn[j] ? (ac_int < ACC_WIDTH + 1, false > ) - Q[index] : (ac_int < ACC_WIDTH + 1, false > ) Q[index] ; //bit 1,phase 3;


                for(i = 0; i < 8; i++) // phase dispose for sin cos lookup table.
                {
                    // bit 0 is j*fc+ (0~3)/4*fc
                    // bit 1 is (j+shr_sf)*fc +  (0~3)/4*fc
                    theta[i] = ( (i >> 2 * shr_sf + j) * fc + (i & 0x3) * fc / 4 ) & sincos_2pi_mask;

                    int sin_pos, cos_pos;
                    int theta_lookup;
                    theta_lookup = theta[i] & sincos_table_mask;
                    theta_lookup = theta_lookup >> sincos_table_sign_shift;

                    cos_theta = cos_int[theta_lookup];
                    sin_theta = sin_int[theta_lookup];

                    if(theta_lookup & cos_mask_bit)	cos_theta = -cos_theta;
                    if(theta_lookup & sin_mask_bit) sin_theta = -sin_theta;

                    bit_i_cos[i] = (bit8_I_sf[i] * cos_theta) >> COSSIN_WIDTH;
                    bit_i_sin[i] = (bit8_I_sf[i] * sin_theta) >> COSSIN_WIDTH;
                    bit_q_cos[i] = (bit8_Q_sf[i] * cos_theta) >> COSSIN_WIDTH;
                    bit_q_sin[i] = (bit8_Q_sf[i] * sin_theta) >> COSSIN_WIDTH;

                    sigma_I[i] = sigma_I[i] + (bit_i_cos[i] - bit_q_sin[i]);
                    sigma_Q[i] = sigma_Q[i] + (bit_q_cos[i] + bit_i_sin[i]);

                }

            }

            for(i = 0; i < 4; i++) // four phase compare with 2 negbour bit.;
            {

                ac_int < ACC_WIDTH + 1, false > abs_sigma_I0, abs_sigma_Q0;
                ac_int < ACC_WIDTH + 1, false > abs_sigma_I1, abs_sigma_Q1;
                abs_sigma_I0 = (sigma_I[i] < 0) ? (ac_int < ACC_WIDTH + 1, false > ) - sigma_I[i] : (ac_int < ACC_WIDTH + 1, false > ) sigma_I[i];
                abs_sigma_Q0 = (sigma_Q[i] < 0) ? (ac_int < ACC_WIDTH + 1, false > ) - sigma_Q[i] : (ac_int < ACC_WIDTH + 1, false > ) sigma_Q[i];
                abs_sigma_I1 = (sigma_I[i + 4] < 0) ? (ac_int < ACC_WIDTH + 1, false > ) - sigma_I[i + 4] : (ac_int < ACC_WIDTH + 1, false > ) sigma_I[i + 4];
                abs_sigma_Q1 = (sigma_Q[i + 4] < 0) ? (ac_int < ACC_WIDTH + 1, false > ) - sigma_Q[i + 4] : (ac_int < ACC_WIDTH + 1, false > ) sigma_Q[i + 4];
                acc = acc + abs_sigma_I0 + abs_sigma_Q0;

                acc =  abs_sigma_I0 + abs_sigma_Q0 + abs_sigma_I1 + abs_sigma_Q1;

                if(acc > max_value)
                {
                    max_value = acc;
                    max_index = m;
                    max_fc = fc;

                    max_sigma_I[0] = sigma_I[i];
                    max_sigma_I[1] = sigma_I[i + 4];
                    max_sigma_Q[0] = sigma_Q[i];
                    max_sigma_Q[1] = sigma_Q[i + 4];
                }
            }

        }
        if(max_value > synch_gate)
            synch_ok = 1;
        else
            synch_ok = 0;

        // decode bit
        int a;
        a = max_sigma_I[0] * initial_phase_I + max_sigma_Q[0] * initial_phase_Q;
        if(a > 0) decode_bit[0] = 0;
        else   	decode_bit[0] = 1;

        a = max_sigma_I[1] * initial_phase_I + max_sigma_Q[1] * initial_phase_Q;
        if(a > 0) decode_bit[1] = 0;
        else   	decode_bit[1] = 1;

    }
}

