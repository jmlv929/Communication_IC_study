#ifndef _AGC_H
#define _AGC_H
#include "stdio.h"

#include "ac_int.h"
#include "ac_fixed.h"

#define COSSIN_WIDTH 11
#define ACC_WIDTH 17
#define PPM_WIDTH 16
#define BIT_WIDTH 8
typedef ac_fixed<14, 1, true> IQ_t;
typedef ac_fixed< 8, 1, true> AGC_t;
typedef ac_fixed<17, 6, false> coef_t;

void agc(IQ_t I_in[16], IQ_t Q_in[16], AGC_t AGC_I[16], AGC_t AGC_Q[16]);


#endif
