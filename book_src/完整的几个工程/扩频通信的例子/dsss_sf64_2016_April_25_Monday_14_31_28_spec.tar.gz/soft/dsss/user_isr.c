#include "user_isr.h"

uint8_t * g_tx_buffer = 0;
volatile size_t g_tx_size = 0;

  /**************************************************************************
   * Configure Interrupts
   *   1.  Initialize CoreInterrupt Controller with its base address.
   *   2.  Initialize Cortex-M1 NVIC.
   *   3.  Configure CoreInterrupt Controller with the address of the UART
   *       receiver interrupt service routine.
   *************************************************************************/

void Cortex_install_INT(void)
{
    CIC_init( COREINTERRUPT_BASE_ADDR );
    NVIC_init();
 
	/**************************************************************************
   * install UART RXRDY interrupt at the CoreInterrupt level.
   *************************************************************************/
  // use CIC_set_irq_handler, just for CIC_irq_handler, it can not ignore
	//	CIC_set_irq_handler( UART0_RXRDY_IRQ_NB, uart_rx_isr );
  //  CIC_set_irq_handler( UART0_TXRDY_IRQ_NB, uart_tx_isr );

  /**************************************************************************
   * Enable interrupts at the processor level
   *************************************************************************/
    NVIC_enable_interrupt( NVIC_IRQ_0 );
//  NVIC_enable_interrupt( NVIC_IRQ_1 );
    NVIC_enable_interrupt( NVIC_IRQ_2 );
//    NVIC_enable_interrupt( NVIC_IRQ_3 );
    
    //smbus int
    NVIC_enable_interrupt( NVIC_IRQ_11 );
    NVIC_enable_interrupt( NVIC_IRQ_12 );

//    CIC_enable_irq( NVIC_IRQ_0 );
//  CIC_enable_irq( NVIC_IRQ_1 );
//    CIC_enable_irq( NVIC_IRQ_2 );
//    CIC_enable_irq( NVIC_IRQ_3 );
//
//    CIC_enable_irq( NVIC_IRQ_11 );
//    CIC_enable_irq( NVIC_IRQ_12 );

#ifdef RX_INT
    NVIC_enable_interrupt( NVIC_IRQ_22 );
//    CIC_enable_irq( NVIC_IRQ_22 );
#endif

#ifdef TX_INT
    NVIC_enable_interrupt( NVIC_IRQ_21 );
//    CIC_enable_irq( NVIC_IRQ_21 );
#endif
}

/******************************************************************************
 * Cortex-M1 interrupt handler for external interrupt 0.
 * This function is called when the Cortex-M1 IRQ0 signal is asserted.
 *****************************************************************************/ 
void WDT_IRQHandler( void )
__irq
{
	/**********************************************************************
	 * Call the CoreInterrupt driver to determine the source of the
	 * interrupt and call the relevant interrupt service routine.
	 *********************************************************************/		
    //CIC_irq_handler();
	debug_gpio_printf("W");
	
	/**********************************************************************
	 * Clear the interrupt in the Cortex-M1 NVIC.
	 *********************************************************************/		
    NVIC_clear_interrupt( NVIC_IRQ_0 );
}

void TIM0_IRQHandler( void )
__irq
{
	/**********************************************************************
	 * Call the CoreInterrupt driver to determine the source of the
	 * interrupt and call the relevant interrupt service routine.
	 *********************************************************************/		
    //CIC_irq_handler();
	
	TMR_clear_int( &g_timer0 );

  sendchar('0');
	
	
  /**********************************************************************
   * Clear the interrupt in the Cortex-M1 NVIC.
   *********************************************************************/ 
  NVIC_clear_interrupt( NVIC_IRQ_2 );
}

void TIM2_IRQHandler( void )
__irq
{
	/**********************************************************************
	 * Call the CoreInterrupt driver to determine the source of the
	 * interrupt and call the relevant interrupt service routine.
	 *********************************************************************/		
//    CIC_irq_handler();
		//debug_gpio_printf("2");
	TMR_clear_int( &g_timer2 );

	/**********************************************************************
	 * Clear the interrupt in the Cortex-M1 NVIC.
	 *********************************************************************/		
    NVIC_clear_interrupt( NVIC_IRQ_3 );
}

void IRQ4_IRQHandler( void )
__irq
{
	/**********************************************************************
	 * Call the CoreInterrupt driver to determine the source of the
	 * interrupt and call the relevant interrupt service routine.
	 *********************************************************************/		
    //CIC_irq_handler();
		debug_gpio_printf("IRQ4!");

	/**********************************************************************
	 * Clear the interrupt in the Cortex-M1 NVIC.
	 *********************************************************************/		
    NVIC_clear_interrupt( NVIC_IRQ_4 );
}

void IRQ21_IRQHandler( void )
__irq
{
	/**********************************************************************
	 * Call the CoreInterrupt driver to determine the source of the
	 * interrupt and call the relevant interrupt service routine.
	 *********************************************************************/		
   // CIC_irq_handler();
	  uart_tx_isr();
		debug_gpio_printf("TX");
	/**********************************************************************
	 * Clear the interrupt in the Cortex-M1 NVIC.
	 *********************************************************************/		
    NVIC_clear_interrupt( NVIC_IRQ_21 );
}


void IRQ22_IRQHandler ( void )
__irq
{
	/**********************************************************************
	 * Call the CoreInterrupt driver to determine the source of the
	 * interrupt and call the relevant interrupt service routine.
	 *********************************************************************/		
    //CIC_irq_handler();
	uart_rx_isr();
	debug_gpio_printf("RX");	
	/**********************************************************************
	 * Clear the interrupt in the Cortex-M1 NVIC.
	 *********************************************************************/		
    NVIC_clear_interrupt( NVIC_IRQ_22 );
}



/******************************************************************************
 * UART receiver interrupt service routine.
 * This function is called by the CoreInterrupt driver when the CoreInterrupt
 * irqSource2 signal is asserted.
 *****************************************************************************/ 
void uart_rx_isr( void )
{
    uint8_t rx_data[MAX_RX_DATA_SIZE];
    size_t rx_size;

	/**********************************************************************
	 * Read data received by the UART.
	 *********************************************************************/		
    rx_size = UART_get_rx( &g_uart,	rx_data, sizeof(rx_data) );
    
	/**********************************************************************
	 * Echo back data received, if any.
	 *********************************************************************/		
    if ( rx_size > 0 )
    {
#ifndef TX_INT
//		UART_send( &g_uart,	rx_data, rx_size );   
#endif
		// add receive dispose code here!
			
    }
}

/******************************************************************************
 * UART transmitter interrupt service routine.
 * This function is called by the CoreInterrupt driver when the CoreInterrupt
 * irqSource1 signal is asserted.
 *****************************************************************************/ 
void uart_tx_isr( void )
{
    size_t size_in_fifo;
    
    if ( g_tx_size > 0 )
    {
        size_in_fifo = UART_fill_tx_fifo( &g_uart, g_tx_buffer, g_tx_size );
        if ( size_in_fifo < g_tx_size )
        {
            g_tx_buffer = &g_tx_buffer[size_in_fifo];
            g_tx_size = g_tx_size - size_in_fifo;
        }
        else
        {
            g_tx_buffer = 0;
            g_tx_size = 0;
            NVIC_disable_interrupt( NVIC_IRQ_21 );
        }
    }
    else
    {
        NVIC_disable_interrupt( NVIC_IRQ_21 );
    }
}

/******************************************************************************
 * is_tx_complete() is used to check if interrupt driven transmition is complete.
 *****************************************************************************/ 
int is_tx_complete( void )
{
    int complete = TX_COMPLETE;
    
    if ( g_tx_size > 0 )
    {
        complete = TX_IN_PROGRESS;
    }
    
    return complete;
}

/******************************************************************************
 * send_using_interrupt() is used to initiate interrupt-driven transmition.
 * It fills the UART FIFO and enable the TXRDY interrupt if there is data
 * remaining to be sent.
 *****************************************************************************/ 
void send_using_interrupt
(
    uint8_t * pbuff,
    size_t tx_size
)
{
    size_t size_in_fifo;
    
    size_in_fifo = UART_fill_tx_fifo( &g_uart, pbuff, tx_size );
    if ( size_in_fifo < tx_size )
    {
        g_tx_buffer = &pbuff[size_in_fifo];
        g_tx_size = tx_size - size_in_fifo;
        NVIC_disable_interrupt( NVIC_IRQ_21 );
    }
    else
    {
        g_tx_buffer = 0;
        g_tx_size = 0;
        NVIC_disable_interrupt( NVIC_IRQ_21 );
    }
}


void SM_MASTER_IRQHandler( void )
{
  /**********************************************************************
   * Call the CoreInterrupt driver to determine the source of the
   * interrupt and call the relevant interrupt service routine.
   *********************************************************************/    
  //CIC_irq_handler();
	
	uint32_t int_clr, int_flag;
	
	int_flag = HW_R32( g_smbus_mas.base_address, smbus_state_offset );
	int_flag = HW_R32( g_smbus_mas.base_address, smbus_state_offset );
	
  sendchar('M');
	//int_clr =  HW_R32( g_smbus_mas.base_address, int_clr_offset );
  
	if( (int_flag & int_sync_flag) )
	{
	  HW_W32( AHB_LED_BASE_ADDR, LED_CFG_ADDR, 0x01 );
		
		HW_W32( g_smbus_mas.base_address, int_clr_offset, int_sync_clr_mask  );
	  
	}
	if( (int_flag & int_frame_flag) )
	{
		HW_W32( AHB_LED_BASE_ADDR, LED_CFG_ADDR, 0x01 );
		
		HW_W32( g_smbus_mas.base_address, int_clr_offset, int_frame_clr_mask );
	}
	if( (int_flag & int_byte_flag)  )
	{
		HW_W32( AHB_LED_BASE_ADDR, LED_CFG_ADDR, 0x01 );
		
		HW_W32( g_smbus_mas.base_address, int_clr_offset, int_byte_clr_mask );
	}
	if( (int_flag & int_halfbyte_flag) )
	{
		HW_W32( AHB_LED_BASE_ADDR, LED_CFG_ADDR, 0 );
		
		HW_W32( g_smbus_mas.base_address, int_clr_offset, int_halfbyte_clr_mask );
	}
  if( (int_flag & int_phy_match_mask) )
	{
		HW_W32( AHB_LED_BASE_ADDR, LED_CFG_ADDR, 0 );
		
		HW_W32( g_smbus_mas.base_address, int_clr_offset, int_phy_match_clr_mask );
	}
	if( (int_flag & int_mac_match_mask) )
	{
		HW_W32( AHB_LED_BASE_ADDR, LED_CFG_ADDR, 0 );
		
		HW_W32( g_smbus_mas.base_address, int_clr_offset, int_mac_match_clr_mask );
	}
	
  /**********************************************************************
   * Clear the interrupt in the Cortex-M1 NVIC.
   *********************************************************************/    
  NVIC_clear_interrupt( NVIC_IRQ_11 );
}

// SMBus_slave_isr
void SM_SLAVE_IRQHandler( void )
{
  /**********************************************************************
   * Call the CoreInterrupt driver to determine the source of the
   * interrupt and call the relevant interrupt service routine.
   *********************************************************************/    
  //CIC_irq_handler();
	
	uint32_t smbus_config, int_flag;
	sendchar('S');
	//int_flag = HW_R32( g_smbus_sla.base_address, int_mask_offset );
	
	//int_flag = HW_R32( g_smbus_sla.base_address, int_flag_offset );
	if( (int_flag & int_sync_flag) == int_sync_flag )
	{
		HW_W32( AHB_LED_BASE_ADDR, LED_CFG_ADDR, 3 );
	}/**/
	else if( (int_flag & int_frame_flag) == int_frame_flag )
	{
		HW_W32( AHB_LED_BASE_ADDR, LED_CFG_ADDR, 2 );
	}
	else if( (int_flag & int_byte_flag) == int_byte_flag )
	{
		HW_W32( AHB_LED_BASE_ADDR, LED_CFG_ADDR, 1 );
	}
	else if( (int_flag & int_halfbyte_flag) == int_halfbyte_flag )
	{
		HW_W32( AHB_LED_BASE_ADDR, LED_CFG_ADDR, 0 );
	}
	else 
	{
		HW_W32( AHB_LED_BASE_ADDR, LED_CFG_ADDR, 0 );
	}
	
  /**********************************************************************
   * Clear the interrupt in the Cortex-M1 NVIC.
   *********************************************************************/    
  NVIC_clear_interrupt( NVIC_IRQ_12 );
}
