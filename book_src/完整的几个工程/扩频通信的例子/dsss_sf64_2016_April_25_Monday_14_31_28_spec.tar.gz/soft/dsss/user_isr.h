#ifndef __USER_ISR__
#define __USER_ISR__ 1
#include "hal.h"
#include "platform.h"

#include "core_irq_ctrl.h"
#include "cortex_nvic.h"

#include "smbus_driver.h"
#include "core_uart_apb.h"
#include "core_gpio.h"
#include "core_spi.h"
#include "io_driver.h"
#include "uart_print.h"
#include "core_timer.h"

extern UART_instance_t g_uart;
extern gpio_instance_t g_gpio;
extern gpio_instance_t d_gpio;
extern SPI_instance_t   g_spi;
extern timer_instance_t g_timer0;
extern timer_instance_t g_timer2;

extern SMBUS_instance_t g_smbus_mas;
extern SMBUS_instance_t g_smbus_sla;

extern unsigned char g_smbus_tx_buf[SMBUS_MEM_LEN];
extern unsigned char g_smbus_rx_buf[SMBUS_MEM_LEN];

extern uint8_t * g_tx_buffer;
extern uint8_t g_message[];

#define RX_INT 1
#undef  TX_INT

#define MAX_RX_DATA_SIZE    256

#define TX_IN_PROGRESS	0
#define TX_COMPLETE		1

void Cortex_install_INT(void);


void uart_rx_isr( void );
void uart_tx_isr( void );
int is_tx_complete( void );

void send_using_interrupt
(
    uint8_t * pbuff,
    size_t tx_size
);

void WDT_IRQHandler( void ) __irq;
void IRQ21_IRQHandler( void ) __irq;
void IRQ22_IRQHandler( void ) __irq;
void TIM0_IRQHandler( void ) __irq;
void TIM2_IRQHandler( void ) __irq;
void IRQ4_IRQHandler( void ) __irq;

#endif
