/*******************************************************************************
 * (c) Copyright 2008 Mr liqinghua.  All rights reserved.
 *
 * CoreUARTapb interrupt driven receive example.
 *
 * This simple example demonstrates how to use interrupt driven UART receive.
 * It is meant to be used with the Cortex-M1 baseline design running on a board
 * connected via a serail cable to a host PC running HyperTerminal.
 * HyperTerminal must be configure for 57600 baud, 8 bits, 1 stop bit,no parity,
 * no flow control.
 * This program displays a message on HyperTerminal then echoed back characters
 * typed in HyperTerminal.
 *
 * SVN $Revision: 1091 $
 * SVN $Date: 2009-06-25 22:23:03 +0100 (Thu, 25 Jun 2009) $
 */
#include "hal.h"
#include "platform.h"
#include "smbus_driver.h"
#include "cortex_nvic.h"
#include "core_uart_apb.h"
#include "core_irq_ctrl.h"
#include "core_spi.h"
#include "core_watchdog.h"
#include "uart_print.h"
#include "user_isr.h"

#define SM_CFG_VALUE 0x1a //0b11010

/******************************************************************************
 * smbus instance data.
 *****************************************************************************/
SMBUS_instance_t g_smbus_mas;
SMBUS_instance_t g_smbus_sla;
UART_instance_t  g_uart;
gpio_instance_t  g_gpio;
gpio_instance_t  d_gpio;
SPI_instance_t   g_spi;
timer_instance_t g_timer0;
timer_instance_t g_timer2;
wd_instance_t    g_wdg;

uint8_t g_message[] = "\n\rsmbus config finish!\n\r";
unsigned char g_smbus_tx_buf[SMBUS_MEM_LEN];
unsigned char g_smbus_rx_buf[SMBUS_MEM_LEN];

/******************************************************************************
 * main function.
 *****************************************************************************/
void system_init(void)
{
	 /**************************************************************************
   *  LED Light here for signal indication, also set SMBUS status!
   *************************************************************************/

    HWR(AHB_LED_BASE_ADDR)=0x55;
    HWR(AHB_LED_BASE_ADDR)=0x5f;
    HWR(AHB_LED_BASE_ADDR)=0x00;


  /**************************************************************************
   * Initialize CoreUARTapb SPI GPIO SMBUS with its base address, baud value, and line
     * configuration.
   *************************************************************************/
    UART_init( &g_uart, COREUARTAPB0_BASE_ADDR, BAUD_VALUE_57600, (DATA_8_BITS | NO_PARITY) );
		SPI_init ( &g_spi , CORESPI_BASE_ADDR,SPI_MODE_MASTER,SPI_MODE0,PCLK_DIV_16);

		GPIO_init( &g_gpio, COREGPIO_BASE_ADDR,  GPIO_APB_32_BITS_BUS );
	  GPIO_init( &d_gpio,	DEBUGGPIO_BASE_ADDR, GPIO_APB_32_BITS_BUS );
	
		GPIO_config( &g_gpio, GPIO_0, GPIO_INOUT_MODE | GPIO_IRQ_EDGE_POSITIVE );
		GPIO_config( &g_gpio, GPIO_1, GPIO_INOUT_MODE | GPIO_IRQ_EDGE_POSITIVE );
		GPIO_config( &g_gpio, GPIO_2, GPIO_INOUT_MODE | GPIO_IRQ_EDGE_POSITIVE );
		GPIO_config( &g_gpio, GPIO_3, GPIO_INOUT_MODE | GPIO_IRQ_EDGE_POSITIVE );
    GPIO_config( &g_gpio, GPIO_4, GPIO_INOUT_MODE | GPIO_IRQ_EDGE_POSITIVE );
    GPIO_set_outputs( &g_gpio, SM_CFG_VALUE );
 
		GPIO_config( &d_gpio, GPIO_0, GPIO_INOUT_MODE | GPIO_IRQ_EDGE_POSITIVE );
		GPIO_config( &d_gpio, GPIO_1, GPIO_INOUT_MODE | GPIO_IRQ_EDGE_POSITIVE );
		GPIO_config( &d_gpio, GPIO_2, GPIO_INOUT_MODE | GPIO_IRQ_EDGE_POSITIVE );
		GPIO_config( &d_gpio, GPIO_3, GPIO_INOUT_MODE | GPIO_IRQ_EDGE_POSITIVE );
    GPIO_config( &d_gpio, GPIO_4, GPIO_INOUT_MODE | GPIO_IRQ_EDGE_POSITIVE );
		GPIO_config( &d_gpio, GPIO_5, GPIO_INOUT_MODE | GPIO_IRQ_EDGE_POSITIVE );
		GPIO_config( &d_gpio, GPIO_6, GPIO_INOUT_MODE | GPIO_IRQ_EDGE_POSITIVE );
		GPIO_config( &d_gpio, GPIO_7, GPIO_INOUT_MODE | GPIO_IRQ_EDGE_POSITIVE );
		GPIO_config( &d_gpio, GPIO_8, GPIO_INOUT_MODE | GPIO_IRQ_EDGE_POSITIVE );
    GPIO_config( &d_gpio, GPIO_9, GPIO_INOUT_MODE | GPIO_IRQ_EDGE_POSITIVE );

    SMBUS_init( &g_smbus_mas, AHB_SM_MASTER_BASE_ADDR, SMBUS_CONFIG_MAC_MEM ); //
    SMBUS_init( &g_smbus_sla, AHB_SM_SLAVE_BASE_ADDR,  SMBUS_CONFIG_MAC_MEM ); //
	  //HW_W32( AHB_LED_BASE_ADDR, LED_DATA_ADDR, 0x05 ); // 4'b0101 'h05 master-io-slave 
		  
	  TMR_init( &g_timer0, CORETIMER0_BASE_ADDR, TMR_CONTINUOUS_MODE, PRESCALER_DIV_64, 78 ); // 0xFFFF -  100us = 64 / 50 * 78
	  TMR_enable_int( &g_timer0 );
		TMR_start( &g_timer0 );
		debug_gpio_printf("set timer0!\n");

	  TMR_init( &g_timer2, CORETIMER2_BASE_ADDR, TMR_CONTINUOUS_MODE, PRESCALER_DIV_64, 78 ); // 0xFFFF -  100us = 64 / 50 * 78
	  TMR_enable_int( &g_timer2 );
		TMR_start( &g_timer2 );
		debug_gpio_printf("set timer2!\n");

	  WD_init( &g_wdg, COREWDG_BASE_ADDR, 0xfffff, PRESCALER_DIV_64 ); // 0xFFFF * 64
	  WD_enable( &g_wdg );

/**************************************************************************
   * Install INT vector
   *************************************************************************/
		Cortex_install_INT();
}

int main( void )
{
 	  int i;
	  system_init();
  /**************************************************************************
   * Send the instructions message.
   *************************************************************************/
		debug_gpio_printf("hello gpio!");
    UART_send( &g_uart, g_message, sizeof(g_message) );
  /**************************************************************************
   * Infinite Loop.
     * This loop will be interrupted by calls to uart_rx_isr() when the UART's
     * RXRDY signal is asserted upon characters being received.
   *************************************************************************/

		for( i = 0; i < SMBUS_MEM_LEN; i ++ )
  	{
  	  g_smbus_tx_buf[i] = i;
			sendchar('1');
		debug_gpio_printf("xx");
    UART_send( &g_uart, g_message, sizeof(g_message) );
  	}
  	
  	SMBUS_fill_tx_fifo( &g_smbus_mas, SMBUS_DAT_SUBID1_WR, g_smbus_tx_buf, SMBUS_MEM_LEN );
  //SMBUS_get_rx      ( &g_smbus_sla, SMBUS_DAT_SUBID1_RD, g_smbus_rx_buf, SMBUS_MEM_LEN );
  
    while(1)
    {
#ifdef TX_INT
    /**********************************************************************
       * Initiate message transmit.
       *********************************************************************/
        send_using_interrupt( g_message, sizeof(g_message) );

        /**********************************************************************
       * Wait for full message to be sent by the interrupt service routine.
       *********************************************************************/
        while( is_tx_complete() == TX_IN_PROGRESS )
        {
            ;
        }
#endif
				/**** Main process here **********/
				
        ;
    }
}
