%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%generate the parameter for CORDIC
%by lanphon,2010/04/05
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear;
close all;
N=15;
n=0:N-1;
k=10;%the number of bits standing for angle
%atan_x=atan(2.^(-n))*2^k/pi;
atan_x=atan(2.^(-n))*2^(k-1)/pi;
file_handle=fopen('parameter_for_cordic.txt','wt');
for i=1:N
	fprintf(file_handle,'parameter atan_%d=%d''h%x;\n',(i-1),k,round(atan_x(i)));
end
fclose(file_handle);
