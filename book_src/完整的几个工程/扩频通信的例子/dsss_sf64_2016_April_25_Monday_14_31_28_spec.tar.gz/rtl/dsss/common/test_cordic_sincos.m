load sinout1     
load cosout1     
load sinout     
load cosout
load inp     

figure;plot(sinout1 );grid;title('sinout1  figure');    
figure;plot(cosout1 );grid;title('cosout1  figure');    
figure;plot(sinout  );grid;title('sinout   figure');   
figure;plot(cosout  );grid;title('cosout   figure');
figure;plot(inp     );grid;title('inp      figure');
