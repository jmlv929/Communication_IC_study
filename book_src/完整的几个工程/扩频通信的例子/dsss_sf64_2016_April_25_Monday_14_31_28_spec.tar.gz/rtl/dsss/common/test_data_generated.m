%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Generated data to demodute PM signals,
%designed by CORDIC algorithm
%by lanphon.
%Created Date:2010/04/06
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear;
close all;

N=2^12;
n=0:N-1;

fc=1e6;%middle frequency is 1MHz
fm=2e4;%20kHz
fs=2.5e6;%sample rate is 2.5MHz
kp=1.5;
x=cos(2*n*pi*fc/fs+kp*cos(2*n*pi*fm/fs));
signal=cos(2*n*pi*fm/fs);

i_carrier=cos(2*n*pi*fc/fs);
q_carrier=sin(2*n*pi*fc/fs);

i_signal=i_carrier.*x;
q_signal=q_carrier.*x;


%IIR Chebyshev II Filter processed
wp=0.1;
ws=0.2;
Rp=1;
Rs=40;
[XN,wc]=cheb2ord(wp,ws,Rp,Rs);
[B,A]=cheby2(XN,Rs,wc);
chebyshev_2=impz(B,A);%sequence of Chebyshev II filter
%end of Filter

%low pass filter
It=conv(chebyshev_2,i_signal);
Qt=conv(chebyshev_2,q_signal);

i_file_handle=fopen('i_cos.dat','wt');
q_file_handle=fopen('q_sin.dat','wt');
fprintf(i_file_handle,'%d\n',round(It*1000));
fprintf(q_file_handle,'%d\n',round(Qt*1000));
fclose(i_file_handle);
fclose(q_file_handle);

temp_result=Qt./It;
result=atan(temp_result);
subplot(2,1,1),plot(result);
subplot(2,1,2),plot(signal);

figure;
for i=1:N-2
	fm_signal(i)=result(i+1)-result(i);
end

another=(It.^2)./(It.^2+Qt.^2);
subplot(2,1,1),plot(another);
subplot(2,1,2),plot(fm_signal);

figure;
subplot(3,1,1),plot(It(1:300)),title('I Signal (by MATLAB)');
subplot(3,1,2),plot(Qt(1:300)),title('Q Signal (by MATLAB)');
subplot(3,1,3),plot(result(1:300)),title('Phase Result (by MATLAB)');
