%% [bit_i_fc(m),bit_q_fc(m)]=chip_rotate(bit_i(m),bit_q(m),ppm_angle);
function [bit_i_fc,bit_q_fc]=chip_rotate(bit_i,bit_q,ppm_angle)
%% every chip should rotate a angle
ppm_angle=int32(ppm_angle);
[rot_cos,rot_sin]=cos_sin_fix(ppm_angle);
%% rotate complex multiplier.
i_fc=bit_i*rot_cos-bit_q*rot_sin;
q_fc=bit_i*rot_sin+bit_q*rot_cos;

bit_i_fc=fix(i_fc/4);
bit_q_fc=fix(q_fc/4);

end