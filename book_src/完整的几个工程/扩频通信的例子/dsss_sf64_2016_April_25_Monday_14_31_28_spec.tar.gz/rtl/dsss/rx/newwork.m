load_data;
test_gold;
sf_channel;

gate=120;
%% agc area
sf_i=sf64_i;
sf_q=sf64_q;
sf=64;

agc_size=32;

len=length(sf_i);
figure;plot((1:len),[sf_i,sf_q]');
agc_i=zeros(len,1);
agc_q=zeros(len,1);

for i=0:fix(len/agc_size)-1
    area=(i*agc_size+1:(i+1)*agc_size);
    [agc_i(area),agc_q(area)]=sf_agc_bit3(sf_i(area),sf_q(area));
end
figure;plot((1:length(agc_i)),[agc_i,agc_q]');

%% inital area
index=zeros(1,len);
de_sf_i=zeros(len,sf);
de_sf_q=zeros(len,sf);
summit=zeros(1,len);
max_i=zeros(1,len);
max_q=zeros(1,len);
peak=zeros(1,len);
peak_i=zeros(1,len);
peak_q=zeros(1,len);
peak_value=zeros(1,len);

%% normal method
for i=1:len-sf
    match_i=agc_i(i:i+sf-1)';
    match_q=agc_q(i:i+sf-1)';
    [de_sf_i(i,:),de_sf_q(i,:)]=de_sf(match_i,match_q,sf,sf_gold(1:sf));
    %get sf=16 chip;
    peak_i(i)=dot(1-2*sf_gold(1:sf),match_i);
    peak_q(i)=dot(1-2*sf_gold(1:sf),match_q);
    peak_value(i)=abs(peak_i(i)+1i*peak_q(i));

    max_i(i)=sum(de_sf_i(i,:));
    max_q(i)=sum(de_sf_q(i,:));
    summit(i)=abs(max_i(i)+1i*max_q(i));
end
diff=peak_value-summit;

%% FFT method
for i=1:len-sf
    [peak(i),index(i)]=de_sf_fft(de_sf_i(i,:),de_sf_q(i,:));
    %     if peak(i)>gate
    %         i
    %         break;
    %     end
end
%% check peak

y=zeros(1,len);
y(best_pos:sf:end)=max(peak);

figure;
plot(peak);grid;title('FFT peak value');
hold;
plot(summit,'b');grid;title('FFT peak pos');
%plot(peak_value,'r');grid;title('FFT peak pos');
stem(y);
%figure;
%plot(index);grid;title('FFT max index pos');

% index_abs=abs(fft(index));
% plot(index_abs);
%% more bit sum
num=8;
peak8=bit_overlap(peak,sf,num)/num;
peak81=bit_overlap_index(peak,index,sf,num)/num;

figure;
plot(peak8);grid;title('FFT 8bit peak value');
hold;
plot(peak81);grid;title('FFT 8bit index peak value');
stem(y);
%% get best pos 
dim_len=floor(len/sf);
index8_fold=reshape(index(1:dim_len*sf),sf,dim_len);

peak8_fold=reshape(peak8(1:dim_len*sf),sf,dim_len);
[val,best_pos]=max(peak8_fold);

%% get filter best pos
peak81_fold=reshape(peak81(1:dim_len*sf),sf,dim_len);
[val1,best_pos1]=max(peak81_fold);

%% find max
figure;
plot(best_pos);grid;title('FFT posithon peak value');
hold 
plot(best_pos1);grid;title('FFT posithon peak value');
