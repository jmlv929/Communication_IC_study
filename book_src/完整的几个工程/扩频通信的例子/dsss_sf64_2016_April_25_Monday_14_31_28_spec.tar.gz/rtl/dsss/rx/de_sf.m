%% generate de_sf index;
function [de_sf_i,de_sf_q]=de_sf(sf_i,sf_q,sf_len,gold)
for i=1:sf_len;
    if(gold(i)==1)
        de_sf_i(i)=sf_i(i);
        de_sf_q(i)=sf_q(i);
    else
        de_sf_i(i)=-sf_i(i);
        de_sf_q(i)=-sf_q(i);
    end
end
end