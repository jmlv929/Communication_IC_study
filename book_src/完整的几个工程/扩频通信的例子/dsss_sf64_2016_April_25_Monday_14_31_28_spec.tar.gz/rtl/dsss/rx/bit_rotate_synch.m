%% search one bit/ max 64 chip
function [bit_pos,bit_neg,bit_IQ_pos,bit_IQ_neg]=bit_rotate_synch(de_sf_i,de_sf_q,ppm_index,sf_type)
%% init index
sin_index=[
0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0  ;
0	0	0	0	0	0	0	0	0	0	0	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1  ;
0	0	0	0	0	0	1	1	1	1	1	1	1	1	1	1	1	2	2	2	2	2	2	2	2	2	2	2	2	3	3	3  ;
0	0	0	0	1	1	1	1	1	1	1	2	2	2	2	2	2	2	2	2	3	3	3	3	3	3	3	3	3	3	3	4  ;
0	0	0	1	1	1	1	1	1	2	2	2	2	2	2	3	3	3	3	3	3	3	3	4	4	4	4	4	4	4	4	4  ;
0	0	1	1	1	1	1	2	2	2	2	2	3	3	3	3	3	3	3	4	4	4	4	4	4	4	4	4	4	4	4	4  ;
0	0	1	1	1	1	2	2	2	2	3	3	3	3	3	3	4	4	4	4	4	4	4	4	4	4	4	4	4	4	3	3  ;
0	0	1	1	1	2	2	2	2	3	3	3	3	4	4	4	4	4	4	4	4	4	4	4	4	4	3	3	3	3	3	2  ;
0	0	1	1	2	2	2	2	3	3	3	3	4	4	4	4	4	4	4	4	4	4	4	3	3	3	3	2	2	2	1	1  ;
0	1	1	1	2	2	2	3	3	3	4	4	4	4	4	4	4	4	4	4	3	3	3	3	2	2	2	1	1	0	0	0  ;
0	1	1	1	2	2	3	3	3	4	4	4	4	4	4	4	4	4	3	3	3	3	2	2	1	1	0	0	0	-1	-1	-2  ;
0	1	1	2	2	2	3	3	3	4	4	4	4	4	4	4	4	3	3	3	2	2	1	1	0	0	-1	-1	-2	-2	-3	-3  ;
0	1	1	2	2	3	3	3	4	4	4	4	4	4	4	3	3	3	2	2	1	1	0	0	-1	-1	-2	-2	-3	-3	-3	-4  ;
0	1	1	2	2	3	3	4	4	4	4	4	4	4	3	3	3	2	2	1	0	0	-1	-1	-2	-2	-3	-3	-4	-4	-4	-4  ;
0	1	1	2	3	3	3	4	4	4	4	4	4	3	3	2	2	1	1	0	-1	-1	-2	-2	-3	-3	-4	-4	-4	-4	-4	-4  ;
0	1	2	2	3	3	4	4	4	4	4	4	3	3	2	2	1	1	0	-1	-1	-2	-3	-3	-3	-4	-4	-4	-4	-4	-3	-3  ;
0	1	2	2	3	3	4	4	4	4	4	3	3	3	2	1	1	0	-1	-2	-2	-3	-3	-4	-4	-4	-4	-4	-3	-3	-3	-2  ;
0	1	2	2	3	3	4	4	4	4	4	3	3	2	1	1	0	-1	-2	-2	-3	-3	-4	-4	-4	-4	-4	-3	-3	-2	-1	-1  ;
0	1	2	3	3	4	4	4	4	4	3	3	2	1	1	0	-1	-2	-2	-3	-4	-4	-4	-4	-4	-3	-3	-2	-2	-1	0	1  ;
0	1	2	3	3	4	4	4	4	4	3	2	2	1	0	-1	-2	-2	-3	-4	-4	-4	-4	-4	-3	-3	-2	-1	0	1	1	2  ;
0	1	2	3	3	4	4	4	4	3	3	2	1	0	-1	-2	-2	-3	-4	-4	-4	-4	-4	-3	-3	-2	-1	0	1	2	3	3  ;
];

cos_index=[
4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4  ;
4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4  ;
4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	3	3	3	3	3	3	3	3	3	3  ;
4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	3	3	3	3	3	3	3	3	3	3	3	2	2	2	2	2	2  ;
4	4	4	4	4	4	4	4	4	4	4	3	3	3	3	3	3	3	3	3	2	2	2	2	2	2	1	1	1	1	1	1  ;
4	4	4	4	4	4	4	4	4	3	3	3	3	3	3	3	2	2	2	2	2	1	1	1	1	0	0	0	0	0	-1	-1  ;
4	4	4	4	4	4	4	4	3	3	3	3	3	2	2	2	2	1	1	1	1	0	0	0	0	-1	-1	-1	-2	-2	-2	-2  ;
4	4	4	4	4	4	3	3	3	3	3	2	2	2	2	1	1	1	0	0	0	-1	-1	-1	-2	-2	-2	-2	-3	-3	-3	-3  ;
4	4	4	4	4	4	3	3	3	3	2	2	2	1	1	1	0	0	0	-1	-1	-2	-2	-2	-2	-3	-3	-3	-3	-4	-4	-4  ;
4	4	4	4	4	3	3	3	3	2	2	2	1	1	0	0	0	-1	-1	-2	-2	-2	-3	-3	-3	-3	-4	-4	-4	-4	-4	-4  ;
4	4	4	4	4	3	3	3	2	2	2	1	1	0	0	-1	-1	-2	-2	-2	-3	-3	-3	-4	-4	-4	-4	-4	-4	-4	-4	-4  ;
4	4	4	4	3	3	3	2	2	2	1	1	0	0	-1	-1	-2	-2	-3	-3	-3	-4	-4	-4	-4	-4	-4	-4	-4	-3	-3	-3  ;
4	4	4	4	3	3	3	2	2	1	1	0	-1	-1	-2	-2	-3	-3	-3	-4	-4	-4	-4	-4	-4	-4	-4	-3	-3	-2	-2	-1  ;
4	4	4	4	3	3	2	2	1	1	0	0	-1	-2	-2	-3	-3	-3	-4	-4	-4	-4	-4	-4	-4	-3	-3	-2	-2	-1	-1	0  ;
4	4	4	3	3	3	2	2	1	0	0	-1	-2	-2	-3	-3	-3	-4	-4	-4	-4	-4	-4	-3	-3	-2	-2	-1	-1	0	1	1  ;
4	4	4	3	3	2	2	1	1	0	-1	-1	-2	-3	-3	-4	-4	-4	-4	-4	-4	-3	-3	-3	-2	-1	-1	0	1	1	2	3  ;
4	4	4	3	3	2	2	1	0	-1	-1	-2	-3	-3	-3	-4	-4	-4	-4	-4	-3	-3	-2	-2	-1	0	1	1	2	3	3	4  ;
4	4	4	3	3	2	1	1	0	-1	-2	-2	-3	-3	-4	-4	-4	-4	-4	-3	-3	-2	-1	-1	0	1	2	2	3	3	4	4  ;
4	4	4	3	3	2	1	0	-1	-1	-2	-3	-3	-4	-4	-4	-4	-4	-3	-3	-2	-1	0	1	1	2	3	3	4	4	4	4  ;
4	4	4	3	2	2	1	0	-1	-2	-3	-3	-4	-4	-4	-4	-4	-3	-3	-2	-1	0	1	2	2	3	3	4	4	4	4	3  ;
4	4	3	3	2	1	1	0	-1	-2	-3	-3	-4	-4	-4	-4	-3	-3	-2	-1	0	1	2	2	3	4	4	4	4	4	3	2  ;
];

%% set result;
chip2_i=zeros(1,32);
chip2_q=zeros(1,32);
chip2_cos_i=zeros(1,32);
chip2_cos_q=zeros(1,32);
chip2_sin_i=zeros(1,32);
chip2_sin_q=zeros(1,32);

for chip_index=1:32
    chip2_i(chip_index)=de_sf_i(chip_index*2-1)+de_sf_i(chip_index*2);
    chip2_q(chip_index)=de_sf_q(chip_index*2-1)+de_sf_q(chip_index*2);
    chip2_cos_i(chip_index)=chip2_i(chip_index)*cos_index(ppm_index,chip_index);
    chip2_cos_q(chip_index)=chip2_q(chip_index)*cos_index(ppm_index,chip_index);
    chip2_sin_i(chip_index)=chip2_i(chip_index)*sin_index(ppm_index,chip_index);
    chip2_sin_q(chip_index)=chip2_q(chip_index)*sin_index(ppm_index,chip_index);
end

chip16_cos_i=zeros(1,4);
chip16_cos_q=zeros(1,4);
chip16_sin_i=zeros(1,4);
chip16_sin_q=zeros(1,4);

%% add to 16 chips
for bit_index=1:4
    chip16_cos_i(bit_index)=0;
    chip16_cos_q(bit_index)=0;
    chip16_sin_i(bit_index)=0;
    chip16_sin_q(bit_index)=0;
    
    for chip_index=1:8
        chip16_cos_i(bit_index)=chip16_cos_i(bit_index)+chip2_cos_i((bit_index-1)*8+chip_index);
        chip16_cos_q(bit_index)=chip16_cos_q(bit_index)+chip2_cos_q((bit_index-1)*8+chip_index);
        chip16_sin_i(bit_index)=chip16_sin_i(bit_index)+chip2_sin_i((bit_index-1)*8+chip_index);
        chip16_sin_q(bit_index)=chip16_sin_q(bit_index)+chip2_sin_q((bit_index-1)*8+chip_index);
    end
end

chip16_cos_i_sub_sin_q = chip16_cos_i - chip16_sin_q;
chip16_cos_i_add_sin_q = chip16_cos_i + chip16_sin_q;
chip16_cos_q_sub_sin_i = chip16_cos_q - chip16_sin_i;
chip16_cos_q_add_sin_i = chip16_cos_q + chip16_sin_i;

chip32_cos_i_sub_sin_q = chip16_cos_i_sub_sin_q(:,1) + chip16_cos_i_sub_sin_q(:,2);
chip32_cos_i_add_sin_q = chip16_cos_i_add_sin_q(:,1) + chip16_cos_i_add_sin_q(:,2);
chip32_cos_q_sub_sin_i = chip16_cos_q_sub_sin_i(:,1) + chip16_cos_q_sub_sin_i(:,2);
chip32_cos_q_add_sin_i = chip16_cos_q_add_sin_i(:,1) + chip16_cos_q_add_sin_i(:,2);

chip64_cos_i_sub_sin_q = chip16_cos_i_sub_sin_q(:,1) + chip16_cos_i_sub_sin_q(:,2) + chip16_cos_i_sub_sin_q(:,3) + chip16_cos_i_sub_sin_q(:,4);
chip64_cos_i_add_sin_q = chip16_cos_i_add_sin_q(:,1) + chip16_cos_i_add_sin_q(:,2) + chip16_cos_i_add_sin_q(:,3) + chip16_cos_i_add_sin_q(:,4);
chip64_cos_q_sub_sin_i = chip16_cos_q_sub_sin_i(:,1) + chip16_cos_q_sub_sin_i(:,2) + chip16_cos_q_sub_sin_i(:,3) + chip16_cos_q_sub_sin_i(:,4);
chip64_cos_q_add_sin_i = chip16_cos_q_add_sin_i(:,1) + chip16_cos_q_add_sin_i(:,2) + chip16_cos_q_add_sin_i(:,3) + chip16_cos_q_add_sin_i(:,4);

%% set final result
if(sf_type==0)
    bit_cos_i_sub_sin_q = chip16_cos_i_sub_sin_q ;
    bit_cos_i_add_sin_q = chip16_cos_i_add_sin_q ;
    bit_cos_q_sub_sin_i = chip16_cos_q_sub_sin_i ;
    bit_cos_q_add_sin_i = chip16_cos_q_add_sin_i ;
else
    if(sf_type==1)
        bit_cos_i_sub_sin_q = chip32_cos_i_sub_sin_q ;
        bit_cos_i_add_sin_q = chip32_cos_i_add_sin_q ;
        bit_cos_q_sub_sin_i = chip32_cos_q_sub_sin_i ;
        bit_cos_q_add_sin_i = chip32_cos_q_add_sin_i ;
    else
        bit_cos_i_sub_sin_q = chip64_cos_i_sub_sin_q ;
        bit_cos_i_add_sin_q = chip64_cos_i_add_sin_q ;
        bit_cos_q_sub_sin_i = chip64_cos_q_sub_sin_i ;
        bit_cos_q_add_sin_i = chip64_cos_q_add_sin_i ;
    end
end

bit_IQ_pos=bit_cos_i_sub_sin_q+1j*bit_cos_q_add_sin_i;
bit_IQ_neg=bit_cos_i_add_sin_q+1j*bit_cos_q_sub_sin_i;

bit_cos_i_sub_sin_q_abs=abs(bit_cos_i_sub_sin_q);
bit_cos_i_add_sin_q_abs=abs(bit_cos_i_add_sin_q);
bit_cos_q_sub_sin_i_abs=abs(bit_cos_q_sub_sin_i);
bit_cos_q_add_sin_i_abs=abs(bit_cos_q_add_sin_i);

if(bit_cos_i_sub_sin_q_abs>bit_cos_q_add_sin_i_abs)
    bit_pos=bit_cos_i_sub_sin_q_abs+bit_cos_q_add_sin_i_abs/4;
else
    bit_pos=bit_cos_i_sub_sin_q_abs/4+bit_cos_q_add_sin_i_abs;
end

if(bit_cos_i_add_sin_q_abs>bit_cos_q_sub_sin_i_abs)
    bit_neg=bit_cos_i_add_sin_q_abs+bit_cos_q_sub_sin_i_abs/4;
else
    bit_neg=bit_cos_i_add_sin_q_abs/4+bit_cos_q_sub_sin_i_abs;
end

end