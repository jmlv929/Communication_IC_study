%% check peak search
figure;plot(max_value(1:sf*search_bit));title('peak value search');

dim_len=floor(len/sf);
max_value_fold=reshape(max_value(1:dim_len*sf),sf,dim_len);
max_ppm_fold=reshape(max_ppm(1:dim_len*sf),sf,dim_len);
[max_value8,best_pos_max_value]=max(max_value_fold);
ppm=mean(max_ppm_fold(best_pos_max_value(1:search_bit)));
neg_or_pos_peak=neg_or_pos(best_pos_max_value(1));
%% decoder init
start_pos=best_pos_max_value(1);
ppm_angle=ppm2angle(ppm,0);
if(neg_or_pos_peak)
    delta_angle=-ppm_angle;
else
    delta_angle=+ppm_angle;
end
%% decoder
bit_i_fc=zeros(1,sf);
bit_q_fc=zeros(1,sf);
neg_or_pos_sync=zeros(1,bit_num);
max_value_sync=zeros(1,bit_num);
max_ppm_sync=zeros(1,bit_num);
decode_bit=zeros(1,bit_num);
decode_bit1=zeros(1,bit_num);
max_IQ_sync=zeros(1,bit_num);
bit_rot=zeros(1,bit_num);

ppm_angle=ones(1,bit_num)*delta_angle;
ppm_angle_sync=zeros(1,bit_num);
sum_angle=0;

NCO_Phase = zeros(bit_num,1);
PLL_Freq_Part=zeros(bit_num,1);
Discriminator_Out = zeros(bit_num,1);
sigma_phase_err=zeros(bit_num,1);
freq_fc = zeros(bit_num,1);
I_PLL=zeros(bit_num,1);
Q_PLL=zeros(bit_num,1);
Signal_PLL=zeros(bit_num,1);
rot_angle=zeros(bit_num*sf,1);
%% decoder loop
% c1=0.02;
% c2=0.02;
% c1=1/16;
% c2=1/32;
c1=1/16;
c2=1/32;
for i=search_bit+1:bit_num
    bit_i=agc_i(start_pos+(i-1)*sf:start_pos+i*sf-1)';
    bit_q=agc_q(start_pos+(i-1)*sf:start_pos+i*sf-1)';
    for m=1:sf
        rot_angle((i-1)*sf+m)=rot_angle((i-1)*sf+m-1)+ppm_angle(i-1); %since we use negative rotate,so we need change the direction.
        [bit_i_fc(m),bit_q_fc(m)]=chip_rotate(bit_i(m),bit_q(m),rot_angle((i-1)*sf+m));
    end
    [de_sf_i,de_sf_q]=de_sf(bit_i_fc,bit_q_fc,64,sf_gold);
    max_IQ_sync(i)=sum(de_sf_i+1i*de_sf_q);
    
    [Signal_PLL(i),freq_fc(i),sigma_phase_err(i)]=pll_sub(max_IQ_sync(i));
       
    I_PLL(i)=real(Signal_PLL(i));
    Q_PLL(i)=imag(Signal_PLL(i));

    ppm_angle(i)=ppm_angle(i-1);
end
%% plot I_PLL/Q_PLL
figure;
Show_D=100; %��ʼλ��
Show_U=bit_num; %��ֹλ��
Show_Length=Show_U-Show_D;
subplot(2,2,1)
plot(real(max_IQ_sync(Show_D:Show_U)));
grid on;
title('I·��Ϣ����');
%axis([1 Show_Length -2*plot_scale 2*plot_scale]);
subplot(2,2,2)
plot(imag(max_IQ_sync(Show_D:Show_U)));
grid on;
title('Q·��Ϣ����');
%axis([1 Show_Length -2*plot_scale 2*plot_scale]);
subplot(2,2,3)
plot(I_PLL(Show_D:Show_U));
grid on;
title('PLL���I·��Ϣ����');
%axis([1 Show_Length -2*plot_scale 2*plot_scale]);
subplot(2,2,4)
plot(Q_PLL(Show_D:Show_U));
grid on;
title('PLL���Q·��Ϣ����');
figure;
%  subplot(2,1,1);plot(PLL_Freq_Part(Show_D:Show_U));grid;title('PLL_Freq_Part����');
%  subplot(2,1,2);plot(NCO_Phase(Show_D:Show_U));grid;title('NCO_Phase����');
subplot(3,1,1);plot(Discriminator_Out(Show_D:Show_U));grid;title('Discriminator_Out ����');
subplot(3,1,2);plot(sigma_phase_err(Show_D:Show_U));grid;title('sigma_phase_err ����');
subplot(3,1,3);plot(freq_fc(Show_D:Show_U));grid;title('freq_fc ����');
%% plot eye diagram
figure;plot(I_PLL(Show_D:Show_U),Q_PLL(Show_D:Show_U),'r*');title('PLL eye');grid;
%% bit decode
for i=search_bit+2:bit_num
    bit_rot(i)=max_IQ_sync(i)*conj(max_IQ_sync(search_bit+1));
    decode_bit(i)=real(bit_rot(i))>0;
    decode_bit1(i)=real(I_PLL(i))>0;
end
%% bit eyediag
ang=angle(bit_rot);
%eye diagram
figure;plot(bit_rot,'r*');title('orignal data');grid;
figure;plot(max_IQ_sync,'b*');title('IQ eyediag');grid;
%% angle plot
plot(ppm_angle);title('ppm angle');grid;
figure;
plot(ppm_angle_sync);grid; title('ppm sync') 
