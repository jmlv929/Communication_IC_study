%% gen gold 256
function bitout=gold256(g_seed)
bitout=zeros(1,256);
	for i=1:256
		bitout(i)=gold_generator(0,g_seed);
	end
end
