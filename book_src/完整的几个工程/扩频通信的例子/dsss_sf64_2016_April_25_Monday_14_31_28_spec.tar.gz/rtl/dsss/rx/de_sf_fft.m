%% use fft to correct it
function [peak_value,index]=de_sf_fft(de_sf_i,de_sf_q,num)
  if nargin<3
      num=length(de_sf_i);
  end
    %peak_value=zeros(1,64);
    de_sf_cpx=de_sf_i+1i*de_sf_q;
    result=fft(de_sf_cpx);
    abs_value=abs(result);
    [peak_value,index]=max(abs_value(1:num));
end
