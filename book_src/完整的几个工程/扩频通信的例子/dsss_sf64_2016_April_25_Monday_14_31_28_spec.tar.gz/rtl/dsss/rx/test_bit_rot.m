load bit_sf_AGC_I;
load bit_sf_AGC_Q;

load chip2_Icos_add_Qsin;
load chip2_Icos_sub_Qsin;
load chip2_Isin_add_Qcos;
load chip2_Isin_sub_Qcos;
load chip16_Icos_add_Qsin;
load chip16_Icos_sub_Qsin;
load chip16_Isin_add_Qcos;
load chip16_Isin_sub_Qcos;
load sin_full;
load cos_full;

load acc_pos;
load acc_neg;

%% parameter
ppm_index=2;
sf_type=2;
sf_gold=[0,1,1,1,1,0,1,0,1,0,1,1,0,0,1,1,0,1,1,1,0,1,1,0,1,0,1,0,0,1,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,1,0,1,1,1,0,1,1,1,1,1,0,0,0,1,0,1,1,1];

%%
check_sf=64;
dim_len=fix(length(bit_sf_AGC_I)/check_sf);
agc_i=reshape(bit_sf_AGC_I(1:dim_len*check_sf),check_sf,dim_len);
agc_q=reshape(bit_sf_AGC_Q(1:dim_len*check_sf),check_sf,dim_len);

rot_sin=reshape(sin_full(1:dim_len*check_sf/2),check_sf/2,dim_len);
rot_cos=reshape(cos_full(1:dim_len*check_sf/2),check_sf/2,dim_len);

Icos_add_Qsin=zeros(check_sf/2,dim_len);
Icos_sub_Qsin=zeros(check_sf/2,dim_len);
Isin_add_Qcos=zeros(check_sf/2,dim_len);
Isin_sub_Qcos=zeros(check_sf/2,dim_len);

chip2_Icos_add_Qsin_test=reshape(chip2_Icos_add_Qsin(1:dim_len*check_sf/2),check_sf/2,dim_len);
chip2_Icos_sub_Qsin_test=reshape(chip2_Icos_sub_Qsin(1:dim_len*check_sf/2),check_sf/2,dim_len);
chip2_Isin_add_Qcos_test=reshape(chip2_Isin_add_Qcos(1:dim_len*check_sf/2),check_sf/2,dim_len);
chip2_Isin_sub_Qcos_test=reshape(chip2_Isin_sub_Qcos(1:dim_len*check_sf/2),check_sf/2,dim_len);

chip16_Icos_add_Qsin_test=reshape(chip16_Icos_add_Qsin(1:dim_len*4),4,dim_len);
chip16_Icos_sub_Qsin_test=reshape(chip16_Icos_sub_Qsin(1:dim_len*4),4,dim_len);
chip16_Isin_add_Qcos_test=reshape(chip16_Isin_add_Qcos(1:dim_len*4),4,dim_len);
chip16_Isin_sub_Qcos_test=reshape(chip16_Isin_sub_Qcos(1:dim_len*4),4,dim_len);

for m=1:dim_len
    for n=1:check_sf/2
        [Icos_add_Qsin(n,m),Icos_sub_Qsin(n,m),Isin_add_Qcos(n,m),Isin_sub_Qcos(n,m)]=chip2_rot(agc_i(2*n-1:2*n,m),agc_q(2*n-1:2*n,m),rot_cos(n,m),rot_sin(n,m),sf_gold(2*n-1:2*n));
    end
end

diff_chip2_Icos_add_Qsin_test= chip2_Icos_add_Qsin_test - Icos_add_Qsin ;
diff_chip2_Icos_sub_Qsin_test= chip2_Icos_sub_Qsin_test - Icos_sub_Qsin ;
diff_chip2_Isin_add_Qcos_test= chip2_Isin_add_Qcos_test - Isin_add_Qcos ;
diff_chip2_Isin_sub_Qcos_test= chip2_Isin_sub_Qcos_test - Isin_sub_Qcos ;

err_Icos_add_Qsin_test=sum(sum(abs(diff_chip2_Icos_add_Qsin_test)));
err_Icos_sub_Qsin_test=sum(sum(abs(diff_chip2_Icos_sub_Qsin_test)));
err_Isin_add_Qcos_test=sum(sum(abs(diff_chip2_Isin_add_Qcos_test)));
err_Isin_sub_Qcos_test=sum(sum(abs(diff_chip2_Isin_sub_Qcos_test)));

%% set chip16 data
Icos_add_Qsin16(1,:)=sum(Icos_add_Qsin(1:8,:));
Icos_sub_Qsin16(1,:)=sum(Icos_sub_Qsin(1:8,:));
Isin_add_Qcos16(1,:)=sum(Isin_add_Qcos(1:8,:));
Isin_sub_Qcos16(1,:)=sum(Isin_sub_Qcos(1:8,:));
Icos_add_Qsin16(2,:)=sum(Icos_add_Qsin(9:16,:));
Icos_sub_Qsin16(2,:)=sum(Icos_sub_Qsin(9:16,:));
Isin_add_Qcos16(2,:)=sum(Isin_add_Qcos(9:16,:));
Isin_sub_Qcos16(2,:)=sum(Isin_sub_Qcos(9:16,:));
Icos_add_Qsin16(3,:)=sum(Icos_add_Qsin(17:24,:));
Icos_sub_Qsin16(3,:)=sum(Icos_sub_Qsin(17:24,:));
Isin_add_Qcos16(3,:)=sum(Isin_add_Qcos(17:24,:));
Isin_sub_Qcos16(3,:)=sum(Isin_sub_Qcos(17:24,:));
Icos_add_Qsin16(4,:)=sum(Icos_add_Qsin(25:32,:));
Icos_sub_Qsin16(4,:)=sum(Icos_sub_Qsin(25:32,:));
Isin_add_Qcos16(4,:)=sum(Isin_add_Qcos(25:32,:));
Isin_sub_Qcos16(4,:)=sum(Isin_sub_Qcos(25:32,:));

diff_chip16_Icos_add_Qsin_test= chip16_Icos_add_Qsin_test - Icos_add_Qsin16 ;
diff_chip16_Icos_sub_Qsin_test= chip16_Icos_sub_Qsin_test - Icos_sub_Qsin16 ;
diff_chip16_Isin_add_Qcos_test= chip16_Isin_add_Qcos_test - Isin_add_Qcos16 ;
diff_chip16_Isin_sub_Qcos_test= chip16_Isin_sub_Qcos_test - Isin_sub_Qcos16 ;

err_Icos_add_Qsin_test16=sum(sum(abs(diff_chip16_Icos_add_Qsin_test)));
err_Icos_sub_Qsin_test16=sum(sum(abs(diff_chip16_Icos_sub_Qsin_test)));
err_Isin_add_Qcos_test16=sum(sum(abs(diff_chip16_Isin_add_Qcos_test)));
err_Isin_sub_Qcos_test16=sum(sum(abs(diff_chip16_Isin_sub_Qcos_test)));

%% sum chip16 to sf=64 data
bit_acc_Icos_add_Qsin_sf=sum(Icos_add_Qsin16(1:4,:));
bit_acc_Icos_sub_Qsin_sf=sum(Icos_sub_Qsin16(1:4,:));
bit_acc_Isin_add_Qcos_sf=sum(Isin_add_Qcos16(1:4,:));
bit_acc_Isin_sub_Qcos_sf=sum(Isin_sub_Qcos16(1:4,:));
view_bit_acc=[bit_acc_Icos_add_Qsin_sf;bit_acc_Icos_sub_Qsin_sf;bit_acc_Isin_sub_Qcos_sf;bit_acc_Isin_add_Qcos_sf];

abs_bit_acc_Icos_add_Qsin_sf=abs(bit_acc_Icos_add_Qsin_sf);
abs_bit_acc_Icos_sub_Qsin_sf=abs(bit_acc_Icos_sub_Qsin_sf);
abs_bit_acc_Isin_add_Qcos_sf=abs(bit_acc_Isin_add_Qcos_sf);
abs_bit_acc_Isin_sub_Qcos_sf=abs(bit_acc_Isin_sub_Qcos_sf);

acc_pos2=zeros(dim_len,1);
acc_neg2=zeros(dim_len,1);

for m=1:dim_len
	if(abs_bit_acc_Icos_add_Qsin_sf(m)>abs_bit_acc_Isin_sub_Qcos_sf(m))
		acc_pos2(m)=abs_bit_acc_Icos_add_Qsin_sf(m)+abs_bit_acc_Isin_sub_Qcos_sf(m)/4;
	else
		acc_pos2(m)=abs_bit_acc_Icos_add_Qsin_sf(m)/4+abs_bit_acc_Isin_sub_Qcos_sf(m);
	end

	if(abs_bit_acc_Icos_sub_Qsin_sf(m)>abs_bit_acc_Isin_add_Qcos_sf(m))
		acc_neg2(m)=abs_bit_acc_Icos_sub_Qsin_sf(m)+abs_bit_acc_Isin_add_Qcos_sf(m)/4;
	else
		acc_neg2(m)=abs_bit_acc_Icos_sub_Qsin_sf(m)/4+abs_bit_acc_Isin_add_Qcos_sf(m);
	end

end
%% test area.
acc_pos1=zeros(dim_len,1);
acc_neg1=zeros(dim_len,1);

for m=1:dim_len
    [de_sf_i,de_sf_q]=de_sf(agc_i(:,m),agc_q(:,m),check_sf,sf_gold);
    [acc_pos1(m),acc_neg1(m)]=bit_rotate(de_sf_i,de_sf_q,ppm_index,sf_type);
end
diff=acc_pos1-acc_pos;
pos=[acc_pos1,acc_pos,diff];

diff2=acc_pos2-acc_pos;
pos2=[acc_pos2,acc_pos,diff2];

diff3=acc_neg2-acc_neg2;
pos3=[acc_neg2,acc_neg2,diff3];

