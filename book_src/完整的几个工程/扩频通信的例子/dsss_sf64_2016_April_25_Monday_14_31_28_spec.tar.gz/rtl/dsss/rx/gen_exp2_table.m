clear;
clc;

len=32;
n=1:len;
sin_n=zeros(1,len);
cos_n=zeros(1,len);

for n=1:len
    sin_n(n)=sin((n-1)/len*pi/2);
    cos_n(n)=sin((n-1)/len*pi/2);
end

%% gen area
fid=fopen('exp2_tab.m','w');
fprintf(fid,'cos_tab=[\n');
fprintf(fid,'%3f\n',cos_n);
fprintf(fid,'];\n');
fprintf(fid,'sin_tab=[\n');
fprintf(fid,'%3f\n',sin_n);
fprintf(fid,'];\n');
fclose(fid);
%% gen verilog
wid=9;
fid=fopen('exp2_tab.v','w');
fprintf(fid,'always @( * ) \n\tcase(index)\n');
for n=1:len
fprintf(fid,'\t\t%d:\tcos_tab=%d\"d%d;\n',n-1,wid,fix(cos_n(n)*2^wid));
end
fprintf(fid,'\t\tdefault:\tcos_tab=%d\"d0;\n',wid);
fprintf(fid,'\tendcase\n');

fprintf(fid,'always @( * ) \n\tcase(index)\n');
for n=1:len
fprintf(fid,'\t\t%d:\tsin_tab=%d\"d%d;\n',n-1,wid,fix(sin_n(n)*2^wid));
end
fprintf(fid,'\t\tdefault:\tsin_tab=%d\"d0;\n',wid);
fprintf(fid,'\tendcase\n');

fclose(fid);
