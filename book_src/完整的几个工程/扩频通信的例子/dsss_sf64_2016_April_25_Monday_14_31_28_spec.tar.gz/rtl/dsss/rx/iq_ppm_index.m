function [i_out,q_out]=iq_ppm_index(i,q,index)
% set rotate angle
    sn=0:63;
    ppm=sn*index*0.25;
    fc=ppm*920*1e6*1e-6;
    fs=(200*1e3);
    Ts=1/fs;
    cpx=(i+q*1j)*exp(1j*Ts*fc*2*pi);
    i_out=real(cpx);
    q_out=imag(cpx);
end
