%% overlap more bit for precision
function bitout=bit_overlap_index(bitin,index,sf,num)
len=length(bitin);
bitout=zeros(1,length(bitin));
bit_tmp=zeros(length(bitin),sf);
bit_tmp1=zeros(length(bitin),sf);

for i=1:len-sf
    bit_tmp(i,index(i))=bitin(i);
end

for i=1:len-sf*num
    for j=1:sf
      bit_tmp1(i,j)=sum(bit_tmp(i+(0:sf:(sf*num-1)),j));
    end
    bitout(i)=max(bit_tmp1(i,:));
end
end
