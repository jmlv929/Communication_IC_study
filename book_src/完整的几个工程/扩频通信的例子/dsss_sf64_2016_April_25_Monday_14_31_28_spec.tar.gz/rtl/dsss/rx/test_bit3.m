load_data;
test_gold;
sf_channel;

gate=120;
%% agc area
% sf_i=sf64_i;
% sf_q=sf64_q;
% sf_gold=sf64;
sf_i=sf64_1_i;
sf_q=sf64_1_q;
sf_gold=sf64_1;

sf=64;
sf_type=2;
agc_size=32;

len=length(sf_i);
bit_num=fix(len/sf);
%figure;plot((1:len),[sf_i,sf_q]');
agc_i=zeros(len,1);
agc_q=zeros(len,1);

for i=0:fix(len/agc_size)-1
    area=(i*agc_size+1:(i+1)*agc_size);
    [agc_i(area),agc_q(area)]=sf_agc_bit3(sf_i(area),sf_q(area));
end
%figure;plot((1:length(agc_i)),[agc_i,agc_q]');

%% inital area
index=zeros(1,len);
de_sf_i=zeros(len,sf);
de_sf_q=zeros(len,sf);
summit=zeros(1,len);
max_i=zeros(1,len);
max_q=zeros(1,len);
peak=zeros(1,len);
peak_i=zeros(1,len);
peak_q=zeros(1,len);
peak_value=zeros(1,len);

%% normal method
for i=1:len-sf
%    match_i=agc_i(i:i+sf-1)';
%    match_q=agc_q(i:i+sf-1)';
    match_i=sf_i(i:i+sf-1)';
    match_q=sf_q(i:i+sf-1)';
    [de_sf_i(i,:),de_sf_q(i,:)]=de_sf(match_i,match_q,sf,sf_gold(1:sf));
    %get sf=16 chip;
    peak_i(i)=dot(1-2*sf_gold(1:sf),match_i);
    peak_q(i)=dot(1-2*sf_gold(1:sf),match_q);
    peak_value(i)=abs(peak_i(i)+1i*peak_q(i));
    
    max_i(i)=sum(de_sf_i(i,:));
    max_q(i)=sum(de_sf_q(i,:));
    summit(i)=abs(max_i(i)+1i*max_q(i));
end
diff=peak_value-summit;
figure;plot(peak_value);title('peak_value');grid;
%% rotate method
match_i=zeros(8,64);
match_q=zeros(8,64);
max_value=zeros(1,len);
max_ppm=zeros(1,len);
neg_or_pos=zeros(1,len);

search_bit=8;
search_len=search_bit*sf;
for i=1:search_len
    for m=1:8;
        match_i(m,1:sf)=agc_i((m-1)*sf+i:m*sf+i-1)';
        match_q(m,1:sf)=agc_q((m-1)*sf+i:m*sf+i-1)';
    end
    
    [max_value(i),max_ppm(i),neg_or_pos(i)]=peak_search(match_i,match_q,sf_type,sf_gold);
end
%% check peak search
plot(max_value(1:sf*search_bit))

dim_len=floor(len/sf);
max_value_fold=reshape(max_value(1:dim_len*sf),sf,dim_len);
max_ppm_fold=reshape(max_ppm(1:dim_len*sf),sf,dim_len);
[max_value8,best_pos_max_value]=max(max_value_fold);
%ppm=mean(max_ppm_fold(best_pos_max_value(1:search_bit)));
ppm_stastic=tabulate(max_ppm_fold(best_pos_max_value(1:search_bit)));
[per,ppm_stastic_index]=max(ppm_stastic(:,3));
ppm=ppm_stastic(ppm_stastic_index,1);
neg_or_pos_peak=neg_or_pos(best_pos_max_value(1));
%% decoder init
start_pos=best_pos_max_value(1);
ppm_angle=ppm2angle(ppm,0);
if(neg_or_pos_peak)
    delta_angle=-ppm_angle;
else
    delta_angle=+ppm_angle;
end
%% decoder
bit_i_fc=zeros(1,sf);
bit_q_fc=zeros(1,sf);
neg_or_pos_sync=zeros(1,bit_num);
max_value_sync=zeros(1,bit_num);
max_ppm_sync=zeros(1,bit_num);
decode_bit=zeros(1,bit_num);
max_IQ_sync=zeros(1,bit_num);
bit_rot=zeros(1,bit_num);

ppm_angle=ones(1,bit_num)*delta_angle;
ppm_angle_sync=zeros(1,bit_num);
rot_angle=0;
sum_angle=0;
c1=0;
c2=0.25;
%% decoder loop
for i=search_bit+1:bit_num
    bit_i=agc_i(start_pos+(i-1)*sf:start_pos+i*sf-1)';
    bit_q=agc_q(start_pos+(i-1)*sf:start_pos+i*sf-1)';
    for m=1:sf
        rot_angle=rot_angle+ppm_angle(i-1); %since we use negative rotate,so we need change the direction.
        [bit_i_fc(m),bit_q_fc(m)]=chip_rotate(bit_i(m),bit_q(m),rot_angle);
    end
    [max_value_sync(i),max_ppm_sync(i),neg_or_pos_sync(i),max_IQ_sync(i)]=peak_search_synch(bit_i_fc,bit_q_fc,sf_type,sf_gold);
    ppm_angle_sync(i)=ppm2angle(max_ppm_sync(i),1);
    if(neg_or_pos_sync(i))
        ppm_angle_delta=-ppm_angle_sync(i);
    else
        ppm_angle_delta=ppm_angle_sync(i);
    end
    sum_angle=sum_angle+ppm_angle_delta;
    ppm_angle(i)=ppm_angle(i-1)+c1*sum_angle+c2*ppm_angle_delta;
end

for i=search_bit+2:bit_num
    bit_rot(i)=max_IQ_sync(i)*conj(max_IQ_sync(search_bit+1));
    decode_bit(i)=real(bit_rot(i))>0;
end

plot(ppm_angle);title('ppm angle');grid;
figure;
plot(ppm_angle_sync);grid;  
%% FFT method
for i=1:len-sf
    [peak(i),index(i)]=de_sf_fft(de_sf_i(i,:),de_sf_q(i,:));
    %     if peak(i)>gate
    %         i
    %         break;
    %     end
end
%% check peak

y=zeros(1,len);
y(best_pos:sf:end)=max(peak);

figure;
plot(peak);grid;title('FFT peak value');
hold;
plot(summit,'b');grid;title('FFT peak pos');
%plot(peak_value,'r');grid;title('FFT peak pos');
stem(y);
%figure;
%plot(index);grid;title('FFT max index pos');

% index_abs=abs(fft(index));
% plot(index_abs);
%% more bit sum
num=8;
peak8=bit_overlap(peak,sf,num)/num;
peak81=bit_overlap_index(peak,index,sf,num)/num;

figure;
plot(peak8);grid;title('FFT 8bit peak value');
hold;
plot(peak81);grid;title('FFT 8bit index peak value');
stem(y);
%% get best pos
dim_len=floor(len/sf);
index8_fold=reshape(index(1:dim_len*sf),sf,dim_len);

peak8_fold=reshape(peak8(1:dim_len*sf),sf,dim_len);
[val,best_pos]=max(peak8_fold);

%% get filter best pos
peak81_fold=reshape(peak81(1:dim_len*sf),sf,dim_len);
[val1,best_pos1]=max(peak81_fold);

%% find max
figure;
plot(best_pos);grid;title('FFT posithon peak value');
hold
plot(best_pos1);grid;title('FFT posithon peak value');
