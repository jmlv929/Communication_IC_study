%% load data & resample
clear;
load ml7404_sf16_m80dBm_i.txt
load ml7404_sf32_m80dBm_i.txt
load ml7404_sf64_m80dBm_i.txt
load ml7404_sf16_m80dBm_q.txt
load ml7404_sf32_m80dBm_q.txt
load ml7404_sf64_m80dBm_q.txt

load bpsk_200kbps_chfout_m60dbm_psf64_ssf64_hgain_pkt_i.txt
load bpsk_200kbps_chfout_m60dbm_psf64_ssf64_hgain_pkt_q.txt

%% resample
sf16_i4=resample(ml7404_sf16_m80dBm_i,2,9);
sf32_i4=resample(ml7404_sf32_m80dBm_i,2,9);
sf64_i4=resample(ml7404_sf64_m80dBm_i,2,9);
sf16_q4=resample(ml7404_sf16_m80dBm_q,2,9);
sf32_q4=resample(ml7404_sf32_m80dBm_q,2,9);
sf64_q4=resample(ml7404_sf64_m80dBm_q,2,9);

sf16_i=resample(ml7404_sf16_m80dBm_i,1,18);
sf32_i=resample(ml7404_sf32_m80dBm_i,1,18);
sf64_i=resample(ml7404_sf64_m80dBm_i,1,18);
sf16_q=resample(ml7404_sf16_m80dBm_q,1,18);
sf32_q=resample(ml7404_sf32_m80dBm_q,1,18);
sf64_q=resample(ml7404_sf64_m80dBm_q,1,18);

%%
sf64_1_i4=resample(bpsk_200kbps_chfout_m60dbm_psf64_ssf64_hgain_pkt_i,2,9);
sf64_1_q4=resample(bpsk_200kbps_chfout_m60dbm_psf64_ssf64_hgain_pkt_q,2,9);

sf64_1_i=resample(bpsk_200kbps_chfout_m60dbm_psf64_ssf64_hgain_pkt_i,1,18);
sf64_1_q=resample(bpsk_200kbps_chfout_m60dbm_psf64_ssf64_hgain_pkt_q,1,18);


%% set complex signal
sf16_cpx=sf16_i+1i*sf16_q;
sf32_cpx=sf32_i+1i*sf32_q;
sf64_cpx=sf64_i+1i*sf64_q;
sf64_1_cpx=sf64_1_i+1i*sf64_1_q;

%% set best sample position
best_pos16=6;

best_pos=best_pos16;

