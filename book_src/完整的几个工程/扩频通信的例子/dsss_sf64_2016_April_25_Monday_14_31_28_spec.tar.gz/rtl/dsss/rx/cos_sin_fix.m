%% cos sin with ppm angle is 13 bit
function [rot_cos,rot_sin]=cos_sin_fix(ppm_angle)
angle_bit=13;
angle_int=fix(ppm_angle);
%sig_bit = bitget(angle_int,13:-1:12,'int32');
sig=0;
sig=bitset(sig,1,bitget(angle_int,angle_bit-1,'int32'));
sig=bitset(sig,2,bitget(angle_int,angle_bit,'int32'));

%table_index_bit=bitget(angle_int,11:-1:9);
table_index=0;
table_index=bitset(table_index,3,bitget(angle_int,angle_bit-2,'int32'));
table_index=bitset(table_index,2,bitget(angle_int,angle_bit-3,'int32'));
table_index=bitset(table_index,1,bitget(angle_int,angle_bit-4,'int32'));

sin_t=[0,1,2,2,3,3,4,4];
cos_t=[4,4,4,3,3,2,2,1];
tmp_rot_sin=sin_t(table_index+1);
tmp_rot_cos=cos_t(table_index+1);

switch sig
    case 0   
        rot_cos= tmp_rot_cos; rot_sin= tmp_rot_sin;
    case 1   
        rot_cos=-tmp_rot_sin; rot_sin= tmp_rot_cos;
    case 2   
        rot_cos=-tmp_rot_cos; rot_sin=-tmp_rot_sin;
    case 3   
        rot_cos= tmp_rot_sin; rot_sin=-tmp_rot_cos;
    otherwise
        disp('other value')
end

a=ppm_angle/(2^angle_bit);
% rot_cos1=round(cos(a*2*pi)*2^2);
% rot_sin1=round(sin(a*2*pi)*2^2);

end
