function [Icos_add_Qsin,Icos_sub_Qsin,Isin_add_Qcos,Isin_sub_Qcos]=chip2_rot(bit_sf_AGC_I,bit_sf_AGC_Q,cos_full,sin_full,gold_sn)
%% use for chip2_rot : [Icos_add_Qsin,Icos_sub_Qsin,Isin_add_Qcos,Isin_sub_Qcos]=chip2_rot(bit_sf_AGC_I,bit_sf_AGC_Q,cos_full,sin_full,gold_sn)
agc_I0=bit_sf_AGC_I(1);
agc_I1=bit_sf_AGC_I(2);
agc_Q0=bit_sf_AGC_Q(1);
agc_Q1=bit_sf_AGC_Q(2);
rot_sin=sin_full;
rot_cos=cos_full;
%% parameter
AGC_I0_gold=(1-2*gold_sn(1))*agc_I0;
AGC_I1_gold=(1-2*gold_sn(2))*agc_I1;
AGC_Q0_gold=(1-2*gold_sn(1))*agc_Q0;
AGC_Q1_gold=(1-2*gold_sn(2))*agc_Q1;

AGC_I=AGC_I0_gold+AGC_I1_gold;
AGC_Q=AGC_Q0_gold+AGC_Q1_gold;

%% caculate
Icos=rot_cos.*AGC_I;
Isin=rot_sin.*AGC_I;
Qcos=rot_cos.*AGC_Q;
Qsin=rot_sin.*AGC_Q;

Icos_add_Qsin=Icos + Qsin;
Icos_sub_Qsin=Icos - Qsin;
Isin_add_Qcos=Isin + Qcos;
Isin_sub_Qcos=Isin - Qcos;
end
