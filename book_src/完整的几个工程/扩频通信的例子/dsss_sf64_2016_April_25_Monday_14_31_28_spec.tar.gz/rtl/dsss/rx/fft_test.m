len=128;
a_r=1:len;
a_i=len:-1:1;
a=a_r+a_i*1i;
b=fft(a);
a1=ifft(b);
c=fft(conj(b));
e=conj(c)/100;

d=fft(b);
f=c./a;
g=e./a;

