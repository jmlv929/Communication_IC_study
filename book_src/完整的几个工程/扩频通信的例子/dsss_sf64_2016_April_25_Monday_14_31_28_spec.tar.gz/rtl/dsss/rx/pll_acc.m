%% use to get a pid control system for PLL
function [freq_fc_out,sigma_phase_err_out]=pll_acc(Discriminator_Out)

persistent freq_fc;
if isempty(freq_fc)
    freq_fc=0;
end
persistent sigma_phase_err;
if isempty(sigma_phase_err)
    sigma_phase_err=0;
end

c1=1/16*8;
c2=1/64*8;

sigma_phase_err=sigma_phase_err  + Discriminator_Out;
freq_fc= freq_fc + c2*sigma_phase_err +c1*Discriminator_Out;

freq_fc_out=freq_fc;
sigma_phase_err_out=sigma_phase_err;

end