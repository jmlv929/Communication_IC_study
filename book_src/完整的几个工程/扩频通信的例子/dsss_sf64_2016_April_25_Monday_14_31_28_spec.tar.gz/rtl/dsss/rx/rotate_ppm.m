%% ppm sn module
function [cos_i,sin_i]=rotate_ppm(i,q,index,cnt)

end
