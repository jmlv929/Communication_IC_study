%% PLL decoder!
function [Signal_PLL,freq_fc_out,sigma_phase_err_out]=pll_sub(max_IQ_sync)
%bit_n=8;
 persistent freq_fc;
 if isempty(freq_fc)
     freq_fc=0;
 end
% persistent sigma_phase_err;
% if isempty(sigma_phase_err)
%     sigma_phase_err=0;
% end

% c1=1/16;
% c2=1/32;

% orginal
%     Signal_PLL(i)=max_IQ_sync(i)*exp(-1i*2*pi*mod(freq_fc(i-1),1));
%     I_PLL(i)=real(Signal_PLL(i));
%     Q_PLL(i)=imag(Signal_PLL(i));
%     Discriminator_Out(i)=atan(Q_PLL(i)/I_PLL(i));
%     sigma_phase_err(i)=sigma_phase_err(i-1) + Discriminator_Out(i);
%     freq_fc(i)= freq_fc(i-1)+ c2*sigma_phase_err(i) +c1*Discriminator_Out(i);
%Signal_PLL=max_IQ_sync*exp(-1i*2*pi*mod(freq_fc,1));
%Signal_PLL=max_IQ_sync*exp(-1i*mod(freq_fc,2*pi));
Signal_PLL=max_IQ_sync*exp(-1i*freq_fc);
I_PLL=real(Signal_PLL);
Q_PLL=imag(Signal_PLL);

Discriminator_Out=atan(Q_PLL/I_PLL);
%Discriminator_Out_fixed=Discriminator_Out*2^(bit_n-1)/(pi);

% c1=1/16;
% c2=1/16;
% 
% sigma_phase_err=sigma_phase_err  + Discriminator_Out;
% freq_fc= freq_fc + c2*sigma_phase_err +c1*Discriminator_Out;
% 
% freq_fc_out=freq_fc;
% sigma_phase_err_out=sigma_phase_err;

[freq_fc_out,sigma_phase_err_out]=pll_acc(Discriminator_Out);
freq_fc=freq_fc_out;

end