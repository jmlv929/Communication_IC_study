% AGC_check
