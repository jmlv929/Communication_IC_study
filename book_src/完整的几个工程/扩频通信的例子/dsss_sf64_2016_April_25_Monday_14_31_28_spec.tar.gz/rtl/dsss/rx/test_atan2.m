r1=1;
i1=2;

w=10;
full=2^(w-2);
z=atan2(i1,r1);
z_f=fix(z*full);
z_f_hex=dec2hex(z_f);

level=10;
n=0:level;
cordic_atan_coef=atan((1/2).^n)/(pi/2);
cordic_atan_coef_f=fix(cordic_atan_coef*full);
cordic_atan_coef_f_hex=dec2hex(cordic_atan_coef_f)
