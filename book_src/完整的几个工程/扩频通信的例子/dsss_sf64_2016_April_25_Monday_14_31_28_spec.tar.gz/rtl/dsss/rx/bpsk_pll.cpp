typedef ac_fixed<15,1> IQ_type_t;
typedef ac_fixed<16,1> ANGLE_type_t;

void bpsk_PLL(IQ_type_t Signal_Channel_I,IQ_type_t Signal_Channel_Q,)
{
  IQ_type_t C1=0.022013;
  IQ_type_t C2=0.00024722;
  
//for(i=2:Simulation_Length
  static ANGLE_type_t NCO_Phase=0; 
  IQ_type_t I_PLL,Q_PLL;

	cos_sin_sig = NCO_Phase.slc<14>(2);
	lut_index   = NCO_Phase.slc<6>(8); //lut_index=theta_full[6+8-1:6];
#ifdef _DEBUG
		float angle,sin_i,cos_i;
		angle=3.1415926*theta_full.to_double()/pow(2.0,15);
		sin_i=sin(angle);
		cos_i=cos(angle);
#endif
		tmp_rot_sin = sin_tab[lut_index];
		tmp_rot_cos = cos_tab[lut_index];
		switch(cos_sin_sig){
		case 0:rot_cos=tmp_rot_cos;
			rot_sin=tmp_rot_sin;
			break;
		case 1:rot_sin=tmp_rot_cos;
			rot_cos=-tmp_rot_sin;
			break;
		case 2:rot_cos=-tmp_rot_cos;
			rot_sin=-tmp_rot_sin;
			break;
		default:rot_sin=-tmp_rot_cos;
			rot_cos=tmp_rot_sin;
			break;
		}
  
  
    Signal_PLL(i)=Signal_Channel(i)*exp(-1i*mod(NCO_Phase(i-1),2*pi));
    I_PLL(i)=real(Signal_PLL(i));
    Q_PLL(i)=imag(Signal_PLL(i));
    Discriminator_Out(i)=sign(I_PLL(i))*Q_PLL(i)/abs(Signal_PLL(i));
    PLL_Phase_Part(i)=Discriminator_Out(i)*C1;
    Freq_Control(i)=PLL_Phase_Part(i)+PLL_Freq_Part(i-1);
    PLL_Freq_Part(i)=Discriminator_Out(i)*C2+PLL_Freq_Part(i-1);
    NCO_Phase(i)=NCO_Phase(i-1)+Freq_Control(i);
}

