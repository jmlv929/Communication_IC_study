%% use to collect data overlap with intervel and overlap number.
function [data_out]=data_overlap(data_in,intervel,num)
data_out=zeros(size(data_in));
for i=1:length(data_in)-intervel*num
    data_out(i)=sum(data_in(i+(0:intervel:(num*intervel-1))));
end
end
