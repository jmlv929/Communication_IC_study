function [NCO_Phase,PLL_Freq_Part]=pll_ok1(I_PLL,Q_PLL,PLL_Freq_Part,NCO_Phase)
% use bpsk_pll to get correct data
% Signal_PLL(i)=Signal_Channel(i)*exp(-1i*mod(NCO_Phase(i-1),2*pi));
C1=0.1;%/(2*pi);
C2=0.02;%/(2*pi);
%Signal_PLL=Signal_Channel*exp(-1i*2*pi*mod(NCO_Phase,1));

if(abs(I_PLL)>abs(Q_PLL))
    RMS=abs(I_PLL)+abs(Q_PLL)/4;
else
    RMS=abs(I_PLL)/4+abs(Q_PLL);
end
%Discriminator_Out(i)=sign(I_PLL(i))*Q_PLL(i);
Discriminator_Out=sign(I_PLL)*Q_PLL/RMS;

%Discriminator_Out(i)=sign(I_PLL(i))*Q_PLL(i)/abs(Signal_PLL(i));
%Discriminator_Out(i)=sign(I_PLL(i))*Q_PLL(i);
PLL_Phase_Part=Discriminator_Out*C1;
Freq_Control=PLL_Phase_Part+PLL_Freq_Part;
PLL_Freq_Part=Discriminator_Out*C2+PLL_Freq_Part;
NCO_Phase=NCO_Phase+Freq_Control;
%NCO_Phase=mod(NCO_Phase,1);
end
