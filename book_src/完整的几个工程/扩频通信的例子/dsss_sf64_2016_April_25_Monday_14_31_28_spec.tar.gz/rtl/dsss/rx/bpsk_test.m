%% clear all
clc
clear
close all
%% Create binary data symbols
    data = randi([0 1], 96, 1);
% Create a BPSK modulator System object
    hModulator = comm.BPSKModulator;
% Change the phase offset to pi/16
    hModulator.PhaseOffset = pi/16;
% Modulate and plot the data
    modData = step(hModulator, data);
    scatterplot(modData)
    
    plot(modData)
%% bpsk generation demo
len=33;
src=randi([0,1],1,len);
tx=1-2*src;
T=5*1e-6;
phase=0.3;
omega=920*3;
delta_omega=omega*T;
ref_delta_omega=delta_omega*2*pi;
n=0:len-1;
rot_index=(delta_omega*n+phase);
tx_iq=tx.*exp(1j*2*pi*rot_index);
tx_iq=awgn(tx_iq,10);
plot(tx_iq);
scatterplot(tx_iq);

%% method i:
square_iq=tx_iq.^2;

diff_square_iq=conj(square_iq(1:end-1)).*square_iq(2:end);
angle_diff=angle(diff_square_iq);
div_square_iq=square_iq(2:end)./square_iq(1:end-1);
angle_div=angle(div_square_iq);
fc=sum(angle_diff)/2/(len-1);

sum_square_iq(1)=sum(square_iq(1:len/2));
sum_square_iq(2)=sum(square_iq(len/2+1:len));
sum_square_iq(3)=sum(square_iq);
%% decode bit

bpsk_angle_diff=conj(tx_iq(1:end-1)).*tx_iq(2:end);
bpsk_angle_diff_dc_off=angle(bpsk_angle_diff)-fc;
decode_bit=abs(bpsk_angle_diff_dc_off)<pi/2;

%% compare bit
check=decode_bit-src(2:end);
err=sum(abs(check));

%% another check
init_angle=angle(tx_iq);
init_angle=angle(sum_square_iq(3))-(len-1)/2*fc;

%% method theta
sigma_angle=cumsum(angle_diff);
angle_int=angle(square_iq(1))+[0,sigma_angle];

p=fittype('poly1');
f=fit(n',angle_int',p);
plot(f,n,angle_int,'*');
