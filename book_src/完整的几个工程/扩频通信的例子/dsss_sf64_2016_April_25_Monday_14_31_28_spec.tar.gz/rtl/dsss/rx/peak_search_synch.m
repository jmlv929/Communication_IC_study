%% search one bit/ max 64 chip
function [max_value,max_ppm,neg_or_pos,max_IQ]=peak_search_synch(match_i,match_q,sf_type,sf_gold)
%% sum normal
range=5;
bit_pos=zeros(1,range);
bit_neg=zeros(1,range);
bit_IQ_neg=zeros(1,range);
bit_IQ_pos=zeros(1,range);

[de_sf_i,de_sf_q]=de_sf(match_i,match_q,64,sf_gold);
for ppm_index=1:range
   [bit_pos(ppm_index),bit_neg(ppm_index),bit_IQ_pos(ppm_index),bit_IQ_neg(ppm_index)]=bit_rotate_synch(de_sf_i,de_sf_q,ppm_index,sf_type);
end
%% search max
[bit_pos_max,index1]=max(bit_pos);
[bit_neg_max,index2]=max(bit_neg);

if(bit_pos_max<bit_neg_max)
    max_ppm=index2;
    max_value=bit_neg_max;
    max_IQ=bit_IQ_neg(index2);
    neg_or_pos=1;
else
    max_ppm=index1;
    max_value=bit_pos_max;
    max_IQ=bit_IQ_pos(index1);
    neg_or_pos=0;
end
 
% figure;plot(bit_pos,'b*');grid;title('abs peak view');
% hold;plot(bit_neg,'r*');grid;title('abs peak view');
% 
% figure;plot(bit_IQ_pos,'b*');grid;title('eye diagram view');
% hold;plot(bit_IQ_pos,'r*');grid;title('eye diagram view');

end
