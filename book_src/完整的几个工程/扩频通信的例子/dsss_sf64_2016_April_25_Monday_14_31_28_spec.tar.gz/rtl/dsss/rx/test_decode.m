%% check peak search
plot(max_value(1:sf*search_bit))

dim_len=floor(len/sf);
max_value_fold=reshape(max_value(1:dim_len*sf),sf,dim_len);
max_ppm_fold=reshape(max_ppm(1:dim_len*sf),sf,dim_len);
[max_value8,best_pos_max_value]=max(max_value_fold);
ppm=mean(max_ppm_fold(best_pos_max_value(1:search_bit)));
neg_or_pos_peak=neg_or_pos(best_pos_max_value(1));
%% decoder init
start_pos=best_pos_max_value(1);
ppm_angle=ppm2angle(ppm,0);
if(neg_or_pos_peak)
    delta_angle=-ppm_angle;
else
    delta_angle=+ppm_angle;
end
%% decoder
bit_i_fc=zeros(1,sf);
bit_q_fc=zeros(1,sf);
neg_or_pos_sync=zeros(1,bit_num);
max_value_sync=zeros(1,bit_num);
max_ppm_sync=zeros(1,bit_num);
decode_bit=zeros(1,bit_num);
max_IQ_sync=zeros(1,bit_num);
bit_rot=zeros(1,bit_num);

ppm_angle=ones(1,bit_num)*delta_angle;
ppm_angle_sync=zeros(1,bit_num);
rot_angle=0;
sum_angle=0;
c1=0;
c2=0.25;
%% decoder loop
for i=search_bit+1:bit_num
    bit_i=agc_i(start_pos+(i-1)*sf:start_pos+i*sf-1)';
    bit_q=agc_q(start_pos+(i-1)*sf:start_pos+i*sf-1)';
    for m=1:sf
        rot_angle=rot_angle+ppm_angle(i-1); %since we use negative rotate,so we need change the direction.
        [bit_i_fc(m),bit_q_fc(m)]=chip_rotate(bit_i(m),bit_q(m),rot_angle);
    end
    [max_value_sync(i),max_ppm_sync(i),neg_or_pos_sync(i),max_IQ_sync(i)]=peak_search_synch(bit_i_fc,bit_q_fc,sf_type,sf_gold);
    ppm_angle_sync(i)=ppm2angle(max_ppm_sync(i),1);
    if(neg_or_pos_sync(i))
        ppm_angle_delta=-ppm_angle_sync(i);
    else
        ppm_angle_delta=ppm_angle_sync(i);
    end
    sum_angle=sum_angle+ppm_angle_delta;
    ppm_angle(i)=ppm_angle(i-1)+c1*sum_angle+c2*ppm_angle_delta;
end
%%
plot(ppm_angle);title('ppm angle');grid;
figure;
plot(ppm_angle_sync);grid;  
%% bit decode
for i=search_bit+2:bit_num
    bit_rot(i)=max_IQ_sync(i)*conj(max_IQ_sync(search_bit+1));
    decode_bit(i)=real(bit_rot(i))>0;
end
%% bit eyediag
ang=angle(bit_rot);
%eye diagram
plot(bit_rot,'r*');

