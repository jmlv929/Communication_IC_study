%% function [angle]=ppm2angle(ppm_index)
function [angle]=ppm2angle(ppm_index,synch)
% use lookup table to translate ppm index to angle
synch_tab =[0,8,15,23,30,38,45,53,60,68,75,83,90,98,106,113,121,128,136,143,151];
search_tab=[0,38,75,113,151,188,226,264,301,339,377,415,452,490,528,565,603,641,678,716,754];
if(synch)
    angle=synch_tab(ppm_index);
else
    angle=search_tab(ppm_index);
end
end