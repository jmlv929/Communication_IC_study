%% check gold sn
function [corx]=bit8_gold(sf_64,bit8_sn)
sf_len=64;
im=zeros(1,sf_len);
bit_sn=zeros(8,sf_len);
bit_sn_abs=zeros(1,8);
for i=1:8
    sn=(i-1)*sf_len+1:i*sf_len;
    bit_sn(i,:)=1-2*bit8_sn(sn);
    [de_sf_i,~]=de_sf(bit_sn(i,:),im,sf_len,sf_64);
%     peak_i(i)=dot(1-2*sf_gold(1:sf),match_i);
%     peak_q(i)=dot(1-2*sf_gold(1:sf),match_q);
%     peak_value(i)=abs(peak_i(i)+1i*peak_q(i));
    bit_sn_abs(i)=abs(sum(de_sf_i));
end
corx=sum(bit_sn_abs);
end
