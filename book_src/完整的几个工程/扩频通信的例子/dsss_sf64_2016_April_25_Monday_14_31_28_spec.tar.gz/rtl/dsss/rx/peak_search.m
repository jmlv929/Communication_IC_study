%% search one bit/ max 64 chip
function [max_value,max_ppm,neg_or_pos]=peak_search(match_i,match_q,sf_type,sf_gold)
%% sum normal
range=21;
bit_pos=zeros(8,range);
bit_neg=zeros(8,range);
bit8_pos=zeros(1,range);
bit8_neg=zeros(1,range);

for ppm_index=1:range
    for bit_index=1:8
        [de_sf_i,de_sf_q]=de_sf(match_i(bit_index,:),match_q(bit_index,:),64,sf_gold);
        [bit_pos(bit_index,ppm_index),bit_neg(bit_index,ppm_index)]=bit_rotate(de_sf_i,de_sf_q,ppm_index,sf_type);
    end
    
    bit8_pos(ppm_index)=sum(bit_pos(:,ppm_index));
    bit8_neg(ppm_index)=sum(bit_neg(:,ppm_index));
end
%% search max
[bit8_pos,index1]=max(bit8_pos);
[bit8_neg,index2]=max(bit8_neg);

if(bit8_pos<bit8_neg)
    max_ppm=index2;
    max_value=bit8_neg;
    neg_or_pos=1;
else
    max_ppm=index1;
    max_value=bit8_pos;
    neg_or_pos=0;
end
 
end