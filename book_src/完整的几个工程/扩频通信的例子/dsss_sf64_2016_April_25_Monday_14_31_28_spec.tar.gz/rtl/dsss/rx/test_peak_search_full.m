load bit_sf_AGC_I;
load bit_sf_AGC_Q;

load acc_pos;
load acc_neg;

%% parameter
ppm_index=1;
sf_type=2;
sf_gold=[0,1,1,1,1,0,1,0,1,0,1,1,0,0,1,1,0,1,1,1,0,1,1,0,1,0,1,0,0,1,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,1,0,1,1,1,0,1,1,1,1,1,0,0,0,1,0,1,1,1];

%%
check_sf=64;
dim_len=fix(length(bit_sf_AGC_I)/check_sf);
agc_i=reshape(bit_sf_AGC_I(1:dim_len*check_sf),check_sf,dim_len);
agc_q=reshape(bit_sf_AGC_Q(1:dim_len*check_sf),check_sf,dim_len);

%% test area.
acc_pos1=zeros(dim_len,1);
acc_neg1=zeros(dim_len,1);

for m=1:dim_len
    [de_sf_i,de_sf_q]=de_sf(agc_i(:,m),agc_q(:,m),check_sf,sf_gold);
    [acc_pos1(m),acc_neg1(m)]=bit_rotate(de_sf_i,de_sf_q,ppm_index,sf_type);
end
diff=acc_pos1-acc_pos;
pos=[acc_pos1,acc_pos,diff];

