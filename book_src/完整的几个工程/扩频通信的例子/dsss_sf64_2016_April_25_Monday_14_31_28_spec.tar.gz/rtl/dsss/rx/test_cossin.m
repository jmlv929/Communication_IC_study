for n=1:8192
%    [x(n),y(n)]=cos_sin_fix(n*10);
    [x(n),y(n)]=cos_sin_fix(rot_angle(n));
end
plot([x;y]');grid;

