use_fc=1;
ppm=17.6;
fc=ppm*920*1e6*1e-6;
fs=(200*1e3);
Ts=1/fs;

init_phase=0.5*pi; %������࣬Rad
%init_phase=rand(1)*2*pi; %������࣬Rad

snr=-12;
%Signal_Channel0=awgn(Signal_Channel0_org,snr,'measured');

sn16=0:length(sf16_cpx)-1;
fc16=exp(1j*sn16*Ts*fc*2*pi+init_phase);
sf16_cpx_awgn=awgn(sf16_cpx,snr,'measured');
sf16_cpx_fc=sf16_cpx_awgn.*fc16';

sn32=0:length(sf32_cpx)-1;
fc32=exp(1j*sn32*Ts*fc*2*pi+init_phase);
sf32_cpx_fc0=sf32_cpx.*fc32';
sf32_cpx_fc=awgn(sf32_cpx_fc0,snr,'measured');

sn64=0:length(sf64_cpx)-1;
fc64=exp(1j*sn64*Ts*fc*2*pi+init_phase);
sf64_cpx_fc0=sf64_cpx.*fc64';
sf64_cpx_fc=awgn(sf64_cpx_fc0,snr,'measured');

sn64_1=0:length(sf64_1_cpx)-1;
fc64_1=exp(1j*sn64_1*Ts*fc*2*pi+init_phase);
sf64_1_cpx_fc0=sf64_1_cpx.*fc64_1';
sf64_1_cpx_fc=awgn(sf64_1_cpx_fc0,snr,'measured');

if(use_fc)
    sf16_i=real(sf16_cpx_fc);
    sf16_q=imag(sf16_cpx_fc);
    
    sf32_i=real(sf32_cpx_fc);
    sf32_q=imag(sf32_cpx_fc);
    
    sf64_i=real(sf64_cpx_fc);
    sf64_q=imag(sf64_cpx_fc);

    sf64_1_i=real(sf64_1_cpx_fc);
    sf64_1_q=imag(sf64_1_cpx_fc);
end

%load_data;
n=sf16_i>0;
% plot(sf16_i(40:190));
% hold;plot(80*n(40:190)-40,'r');
