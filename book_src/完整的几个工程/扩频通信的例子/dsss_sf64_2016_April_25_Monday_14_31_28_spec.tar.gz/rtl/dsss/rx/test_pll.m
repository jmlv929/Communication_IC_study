clc;
clear all;
close all
global Discriminator_Out_v
global freq_fc_v
%%
load max_IQ_sync_I
load max_IQ_sync_Q
load Signal_PLL_I
load Signal_PLL_Q
load Discriminator_Out
load freq_fc
load sigma_phase_err

Discriminator_Out_v=Discriminator_Out;
freq_fc_v=freq_fc;
%freq_fc=[0;freq_fc(1:end-1)]/2^5;
freq_fc=freq_fc/2^5;

%% check verilog
omit=1;
bit_n=10;
fix_coef=2^(bit_n-1)/(pi);

rot_angle=rem(freq_fc./fix_coef*8,2*pi);
max_IQ_sync=max_IQ_sync_I+1j*max_IQ_sync_Q;
Signal_PLL_v=Signal_PLL_I+1j*Signal_PLL_Q;
Signal_PLL_m=max_IQ_sync.*exp(-1j*rot_angle);
rot_angle_true=angle(max_IQ_sync./Signal_PLL_v);
rot_angle_diff=rot_angle-rot_angle_true;
rot_angle_evm=rot_angle_diff/pi*180;
rot_angle_evm1=rot_angle_diff./rot_angle*100;
Signal_PLL_cmp=[Signal_PLL_v,Signal_PLL_m,Signal_PLL_m-Signal_PLL_v,rot_angle,rot_angle_true,rot_angle_diff,rot_angle_evm,rot_angle_evm1];

scatter(max_IQ_sync_I,max_IQ_sync_Q,'g*');grid;
figure;plot(Signal_PLL_m,'g*');grid;title('Signal_PLL_m');
figure;plot(Signal_PLL_v,'g*');grid;title('Signal_PLL_v');
figure;plot(max_IQ_sync_Q(omit:end),'b*');grid;title('max_IQ_sync_Q part');

%% use pll to caculate
len=length(max_IQ_sync_I);
max_IQ_sync=zeros(len,1);
Signal_PLL=zeros(len,1);
freq_fc_out=zeros(len,1);
sigma_phase_err_out=zeros(len,1);
diff_i=zeros(len,1);
%freq_fc_diff=zeros(len,1);

for i=1:len
    max_IQ_sync(i)=max_IQ_sync_I(i)+1j*max_IQ_sync_Q(i);
    
    [Signal_PLL(i),freq_fc_out(i),sigma_phase_err_out(i)]=pll_sub(max_IQ_sync(i));
end
%% result dispose
Discriminator_Out_ok=atan(imag(Signal_PLL)./real(Signal_PLL))*fix_coef;
Discriminator_Out_fixed=atan(max_IQ_sync_Q./max_IQ_sync_I)*fix_coef;
Discriminator_Out_fixed1=atan(Signal_PLL_Q./Signal_PLL_I)*fix_coef;
Discriminator_Out_cmp=[max_IQ_sync_I,max_IQ_sync_Q,Discriminator_Out_ok,Discriminator_Out_ok-Discriminator_Out_v,Discriminator_Out_v,Discriminator_Out_fixed1,Discriminator_Out_fixed1-Discriminator_Out_v];

sigma_phase_err_check=cumsum(Discriminator_Out_v);
sigma_phase_err_ok=sigma_phase_err_out*fix_coef;
sigma_phase_err_diff=sigma_phase_err_ok-sigma_phase_err;

sigma_phase_err_cmp=[sigma_phase_err_ok,sigma_phase_err,sigma_phase_err_check,sigma_phase_err_diff,Discriminator_Out_ok,Discriminator_Out_v];

freq_fc_check=[(sigma_phase_err_check/32)+(Discriminator_Out_v/16),(Discriminator_Out_v/16),(sigma_phase_err_check/32),sigma_phase_err_check,Discriminator_Out_v];
freq_fc_check=[zeros(1,5);freq_fc_check(1:end-1,:)];
freq_fc_out=[0;freq_fc_out(1:end-1)];
freq_fc_out_check=[(sigma_phase_err_ok/32)+(Discriminator_Out_ok/16),(Discriminator_Out_ok/16),(sigma_phase_err_ok/32),sigma_phase_err_ok,Discriminator_Out_ok];
freq_fc_out_check=[zeros(1,5);freq_fc_out_check(1:end-1,:)];

Signal_PLL_cmp1=[max_IQ_sync_I,max_IQ_sync_Q,real(Signal_PLL),imag(Signal_PLL),angle(Signal_PLL./max_IQ_sync)/pi*180,freq_fc_out*2*180,zeros(size(Signal_PLL_I)),Signal_PLL_I,Signal_PLL_Q,angle((1i*Signal_PLL_Q+Signal_PLL_I)./max_IQ_sync)/pi*180,rot_angle/pi*180,zeros(size(Signal_PLL_I))];

freq_fc_out_ok=freq_fc_out*fix_coef;
freq_fc_diff=freq_fc_out_ok-freq_fc;
freq_fc_cmp=[freq_fc_out_ok,zeros(size(freq_fc_diff)),freq_fc_out_check,zeros(size(freq_fc_diff)),freq_fc,zeros(size(freq_fc_diff)),freq_fc_check,zeros(size(freq_fc_diff)),Signal_PLL_cmp1,freq_fc_diff];

%% check pll
figure;plot(Signal_PLL_v(omit:end),'r*');grid;title('verilog pll result');
figure;plot(Signal_PLL(omit:end),'r*');grid;title('pll result');
figure;plot(imag(Signal_PLL(omit:end)),'b*');grid;title('Signal_PLL image part');
figure;plot(Signal_PLL_Q(omit:end),'b*');grid;title('verilog Signal PLL image part');

figure;plot(freq_fc_out(omit:end));grid;title('freq_fc_out result');

