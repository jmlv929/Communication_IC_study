function T = timing_types(dt)
  switch dt
    case 'double'
      T.k1           = double([]);                
      T.k2           = double([]);                
      T.control      = double([]); 
      T.RMS          = double([]); 
      T.sum_sigma_err= double([]);
    case 'single'
      T.k1           = single([]);                
      T.k2           = single([]);                
      T.control      = single([]); 
      T.RMS          = single([]); 
      T.sum_sigma_err= single([]);
    case 'fixed'
      T.k1           = fi([],true,10,9);                  
      T.k2           = fi([],true,10,9);              
      T.control      = fi([],true,10,9);  
      T.RMS          = fi([],true,10,9);  
      T.sum_sigma_err= fi([],true,10,9);  
    case 'scaled'
      T.k2           = fi([],true,10,9,'DataType','ScaledDouble');              
      T.control      = fi([],true,10,9,'DataType','ScaledDouble');  
      T.RMS          = fi([],true,10,9,'DataType','ScaledDouble');  
      T.sum_sigma_err= fi([],true,10,9,'DataType','ScaledDouble');  
  end
 
end
