%% view data
function debug_view()
figure;plot(bit_pos,'b*');grid;title('abs peak view');
hold;plot(bit_neg,'b*');grid;title('abs peak view');

figure;plot(bit_IQ_pos,'b*');grid;title('eye diagram view');
hold;plot(bit_IQ_pos,'r*');grid;title('eye diagram view');

end