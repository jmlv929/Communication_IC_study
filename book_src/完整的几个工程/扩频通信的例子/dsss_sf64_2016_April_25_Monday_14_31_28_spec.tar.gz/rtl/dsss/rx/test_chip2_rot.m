load sin_full31;
load cos_full31;
load bit_sf_AGC_I62;
load bit_sf_AGC_I63;
load bit_sf_AGC_Q62;
load bit_sf_AGC_Q63;
load chip2_Icos_add_Qsin31;
load chip2_Icos_sub_Qsin31;
load chip2_Isin_add_Qcos31;
load chip2_Isin_sub_Qcos31;


agc_I0=bit_sf_AGC_I62;
agc_I1=bit_sf_AGC_I63;
agc_Q0=bit_sf_AGC_Q62;
agc_Q1=bit_sf_AGC_Q63;
rot_sin=sin_full31;
rot_cos=cos_full31;

chip2_Icos_add_Qsin=chip2_Icos_add_Qsin31;
chip2_Icos_sub_Qsin=chip2_Icos_sub_Qsin31;
chip2_Isin_add_Qcos=chip2_Isin_add_Qcos31;
chip2_Isin_sub_Qcos=chip2_Isin_sub_Qcos31;

%% parameter
gold_sn=[1,1];
AGC_I0_gold=(1-2*gold_sn(1))*agc_I0;
AGC_I1_gold=(1-2*gold_sn(2))*agc_I1;
AGC_Q0_gold=(1-2*gold_sn(1))*agc_Q0;
AGC_Q1_gold=(1-2*gold_sn(2))*agc_Q1;

AGC_I=AGC_I0_gold+AGC_I1_gold;
AGC_Q=AGC_Q0_gold+AGC_Q1_gold;

%% caculate
Icos=rot_cos.*AGC_I;
Isin=rot_sin.*AGC_I;
Qcos=rot_cos.*AGC_Q;
Qsin=rot_sin.*AGC_Q;

Icos_add_Qsin=Icos + Qsin;
Icos_sub_Qsin=Icos - Qsin;
Isin_add_Qcos=Isin + Qcos;
Isin_sub_Qcos=Isin - Qcos;

%%
diff_Icos_add_Qsin=Icos_add_Qsin - chip2_Icos_add_Qsin;
diff_Icos_sub_Qsin=Icos_sub_Qsin - chip2_Icos_sub_Qsin;
diff_Isin_add_Qcos=Isin_add_Qcos - chip2_Isin_add_Qcos;
diff_Isin_sub_Qcos=Isin_sub_Qcos - chip2_Isin_sub_Qcos;

Icos_add_Qsin_full=[diff_Icos_add_Qsin,Icos_add_Qsin , chip2_Icos_add_Qsin];
Icos_sub_Qsin_full=[diff_Icos_sub_Qsin,Icos_sub_Qsin , chip2_Icos_sub_Qsin];
Isin_add_Qcos_full=[diff_Isin_add_Qcos,Isin_add_Qcos , chip2_Isin_add_Qcos];
Isin_sub_Qcos_full=[diff_Isin_sub_Qcos,Isin_sub_Qcos , chip2_Isin_sub_Qcos];
