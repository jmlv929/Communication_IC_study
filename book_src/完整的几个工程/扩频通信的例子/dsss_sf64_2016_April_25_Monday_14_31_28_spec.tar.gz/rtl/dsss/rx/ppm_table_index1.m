function [chip_I,chip_Q]=ppm_table_index1(index)
% set rotate angle
    sn=0:63;
    ppm=sn*index*0.25;
    fc=920*1e6*1e-6;
    fs=(200*1e3);
    Ts=1/fs;
    rad=Ts*fc;
    angle=2*pi*rad;
    cpx=exp(1j*angle*ppm);
    cos_t=real(cpx);
    sin_t=imag(cpx);
    
    base=1/32;
    
    
    
end