clear all;
close all;
clc;
%�������໷�Ĺ���ģʽ�����ز�Ϊ��1����BPSK����Ϊ��2����QPSK����Ϊ��3��
PLL_Mode = 2;
%�������ݳ���
Simulation_Length=1000;
%�����ź�
if PLL_Mode == 1
    I_Data=ones(Simulation_Length,1);%���ز�����
    Q_Data=I_Data;
else if PLL_Mode == 2   %BPSK����
        I_Data=randint(Simulation_Length,1)*2-1;
        Q_Data=zeros(Simulation_Length,1);
    else              %QPSK����
        I_Data=randint(Simulation_Length,1)*2-1;
        Q_Data=randint(Simulation_Length,1)*2-1;
    end
end
Signal_Source=I_Data + 1i*Q_Data;%�����ز��ź�
%�ز��ź�
Freq_Sample=200e3;%�����ʣ�Hz
Delta_Freq=-0.3*Freq_Sample; %Ƶƫ��Hz
%Freq_Sample=2400;%�����ʣ�Hz
%Delta_Freq=-60; %Ƶƫ��Hz

Time_Sample=1/Freq_Sample;%����
Delta_Phase=0.5*pi; %������࣬Rad
%Delta_Phase=rand(1)*2*pi; %������࣬Rad
Carrier=exp(1i*(Delta_Freq/Freq_Sample*(1:Simulation_Length)+Delta_Phase));
%���ƴ���
scale=.1;
snr=7;
Signal_Channel0_org=scale*Signal_Source.*Carrier';
Signal_Channel0=awgn(Signal_Channel0_org,snr,'measured');
plot_scale=1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%����Ϊ������λ�ô�������
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
OSR=18;
%Signal_Channel=upsample(Signal_Channel0,OSR);
Signal_Channel_scale=interp(Signal_Channel0,OSR);

ave_n=32;
Signal_Channel10=Signal_Channel_scale(1:ave_n)./Signal_Channel_scale(1:ave_n);
Signal_Channel11=Signal_Channel_scale(ave_n+1:end)./sum(abs(Signal_Channel_scale(1:ave_n)))*ave_n;
%plot(abs(Signal_Channel_scale));
Signal_Channel1=[Signal_Channel10' Signal_Channel11'];
%Signal_Channel1=Signal_Channel_scale;

I_osr=real(Signal_Channel1);
Q_osr=imag(Signal_Channel1);
figure;
plot(I_osr);
figure;
sample_delta=ones(Simulation_Length,1);
sample_sn=zeros(Simulation_Length,1);
sigma_err=zeros(Simulation_Length,1);
sum_sigma_err=zeros(Simulation_Length,1);
control=zeros(Simulation_Length,1);
delta=zeros(Simulation_Length,1);
I_err=zeros(Simulation_Length,1);
Q_err=zeros(Simulation_Length,1);
shift=zeros(Simulation_Length,1);
sample_dir=zeros(Simulation_Length,1);

sample_delta(1)=5;
sample_delta(2)=sample_delta(1)+OSR;
k1=1/8;
k2=1/8;

for i=2:Simulation_Length
    
    I_in=[I_osr(sample_delta(i-1)),I_osr(sample_delta(i-1)+OSR/2),I_osr(sample_delta(i-1)+OSR)];
    Q_in=[Q_osr(sample_delta(i-1)),Q_osr(sample_delta(i-1)+OSR/2),Q_osr(sample_delta(i-1)+OSR)];
    
    [sample_dir(i)]=sample_timing_ok(I_in,Q_in);
    
    sample_delta(i)=sample_delta(i-1)+sample_dir(i)+OSR;
    
    if(sample_delta(i)>(Simulation_Length-1)*OSR)
        break;
    end
end
%find(sum_sigma_err==0)
plot(control)
figure;
plot(sigma_err);
plot(sample_delta);
plot(1:Simulation_Length*OSR,I_osr);
hold on;
plot(sample_delta(1:i),I_osr(sample_delta(1:i)),'*');
grid on;
hold on;
Signal_Channel2=Signal_Channel1(sample_delta);
Signal_Channel2_RMS=abs(real(Signal_Channel2))+abs(imag(Signal_Channel2));
%Signal_Channel=Signal_Channel2./Signal_Channel2_RMS;
%Signal_Channel=Signal_Channel2./sum(abs(Signal_Channel2(1:16)))*16;
%Signal_Channel=Signal_Channel2./abs(Signal_Channel2);
%Signal_Channel=Signal_Channel2./scale;
Signal_Channel=Signal_Channel2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%����Ϊ���໷��������
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%��������
Signal_PLL=zeros(Simulation_Length,1);
NCO_Phase = zeros(Simulation_Length,1);
Discriminator_Out=zeros(Simulation_Length,1);
Freq_Control=zeros(Simulation_Length,1);
PLL_Phase_Part=zeros(Simulation_Length,1);
PLL_Freq_Part=zeros(Simulation_Length,1);
%��·����
% C1=0.1;%/(2*pi);
% C2=0.02;%/(2*pi);
% C1=0.022013;
% C2=0.00024722;
I_PLL=real(Signal_Channel);
Q_PLL=imag(Signal_Channel);

for i=2:Simulation_Length
    %Signal_PLL=Signal_Channel*exp(-1i*2*pi*mod(NCO_Phase,1));
    %Signal_PLL(i)=Signal_Channel(i)*exp(-1i*mod(NCO_Phase(i-1),2*pi));
    Signal_PLL(i)=Signal_Channel(i)*exp(-1i*2*pi*mod(NCO_Phase(i-1),1));
    I_PLL(i)=real(Signal_PLL(i));
    Q_PLL(i)=imag(Signal_PLL(i));
    
    [NCO_Phase(i),PLL_Freq_Part(i)]=pll_ok1(I_PLL(i),Q_PLL(i),PLL_Freq_Part(i-1),NCO_Phase(i-1));
end

%��ͼ��ʾ���
figure
subplot(2,2,1)
%plot(-PLL_Freq_Part(2:Simulation_Length)*Freq_Sample);
plot(-PLL_Freq_Part(2:Simulation_Length));
grid on;
title('PLLƵ����Ӧ����ͼ PLL_Freq_Part');
%axis([1 Simulation_Length -100 100]);
subplot(2,2,2)
%plot(PLL_Phase_Part(2:Simulation_Length)*180/pi);
plot(NCO_Phase(2:Simulation_Length));
title('PLL��λ��Ӧ����ͼ NCO_Phase');
%axis([1 Simulation_Length -3*plot_scale 3*plot_scale]);
grid on;
%�趨��ʾ��Χ
Show_D=10; %��ʼλ��
Show_U=900; %��ֹλ��
Show_Length=Show_U-Show_D;
subplot(2,2,3)
plot(Signal_Channel(Show_D:Show_U),'*');
title('����PLL����������ͼ');
%axis([-2*plot_scale 2*plot_scale -2*plot_scale 2*plot_scale]);
grid on;
hold on;
subplot(2,2,3)
plot(Signal_PLL(Show_D:Show_U),'r*');
grid on;
subplot(2,2,4)
plot(Signal_PLL(Show_D:Show_U),'r*');
title('PLL�������ȶ������������ͼ');
%axis([-2*plot_scale 2*plot_scale -2*plot_scale 2*plot_scale]);
grid on;

figure
%�趨��ʾ��Χ
Show_D=1; %��ʼλ��
Show_U=900; %��ֹλ��
Show_Length=Show_U-Show_D;
subplot(2,2,1)
plot(I_Data(Show_D:Show_U));
grid on;
title('I·��Ϣ����');
%axis([1 Show_Length -2*plot_scale 2*plot_scale]);
subplot(2,2,2)
plot(Q_Data(Show_D:Show_U));
grid on;
title('Q·��Ϣ����');
%axis([1 Show_Length -2*plot_scale 2*plot_scale]);
subplot(2,2,3)
plot(I_PLL(Show_D:Show_U));
grid on;
title('PLL���I·��Ϣ����');
%axis([1 Show_Length -2*plot_scale 2*plot_scale]);
subplot(2,2,4)
plot(Q_PLL(Show_D:Show_U));
grid on;
title('PLL���Q·��Ϣ����');
%axis([1 Show_Length -2*plot_scale 2*plot_scale]);
% figure;
% plot(NCO_Phase);
% grid on;
% title('PLL NCO');
figure;plot(sample_dir);grid;

