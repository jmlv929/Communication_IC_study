clear all;
%close all;
clc;
%�������໷�Ĺ���ģʽ�����ز�Ϊ��1����BPSK����Ϊ��2����QPSK����Ϊ��3��
PLL_Mode = 2;
%�������ݳ���
Simulation_Length=1000;
%�����ź�
if PLL_Mode == 1
    I_Data=ones(Simulation_Length,1);%���ز�����
    Q_Data=I_Data;
else if PLL_Mode == 2   %BPSK����
        I_Data=randint(Simulation_Length,1)*2-1;
        Q_Data=zeros(Simulation_Length,1);
    else              %QPSK����
        I_Data=randint(Simulation_Length,1)*2-1;
        Q_Data=randint(Simulation_Length,1)*2-1;
    end
end
Signal_Source=I_Data + 1i*Q_Data;%�����ز��ź�
%�ز��ź�
Freq_Sample=200e3;%�����ʣ�Hz
Delta_Freq=-0.3*Freq_Sample; %Ƶƫ��Hz
%Freq_Sample=2400;%�����ʣ�Hz
%Delta_Freq=-60; %Ƶƫ��Hz

Time_Sample=1/Freq_Sample;%����
Delta_Phase=0.5*pi; %������࣬Rad
%Delta_Phase=rand(1)*2*pi; %������࣬Rad
Carrier=exp(1i*(Delta_Freq/Freq_Sample*(1:Simulation_Length)+Delta_Phase));
%���ƴ���
scale=.1;
snr=7;
Signal_Channel0_org=scale*Signal_Source.*Carrier';
Signal_Channel0=awgn(Signal_Channel0_org,snr,'measured');
plot_scale=1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%����Ϊ������λ�ô�������
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
OSR=18;
%Signal_Channel=upsample(Signal_Channel0,OSR);
Signal_Channel_scale=interp(Signal_Channel0,OSR);

ave_n=32;
Signal_Channel10=Signal_Channel_scale(1:ave_n)./Signal_Channel_scale(1:ave_n);
Signal_Channel11=Signal_Channel_scale(ave_n+1:end)./sum(abs(Signal_Channel_scale(1:ave_n)))*ave_n;
%plot(abs(Signal_Channel_scale));
Signal_Channel1=[Signal_Channel10' Signal_Channel11'];
%Signal_Channel1=Signal_Channel_scale;

I_osr=real(Signal_Channel1);
Q_osr=imag(Signal_Channel1);
figure;
plot(I_osr);
figure;
sample_delta=ones(Simulation_Length,1);
sample_sn=zeros(Simulation_Length,1);
sigma_err=zeros(Simulation_Length,1);
sum_sigma_err=zeros(Simulation_Length,1);
control=zeros(Simulation_Length,1);
delta=zeros(Simulation_Length,1);
I_err=zeros(Simulation_Length,1);
Q_err=zeros(Simulation_Length,1);
shift=zeros(Simulation_Length,1);

sample_delta(1)=5;
sample_delta(2)=sample_delta(1)+OSR;
k1=1/16;
k2=1/8;
for i=2:Simulation_Length
    I_err(i)=I_osr(sample_delta(i-1)+OSR/2)*(sign(I_osr(sample_delta(i-1)+OSR))-sign(I_osr(sample_delta(i-1))));
    Q_err(i)=Q_osr(sample_delta(i-1)+OSR/2)*(sign(Q_osr(sample_delta(i-1)+OSR))-sign(Q_osr(sample_delta(i-1))));
    
    if(abs(I_osr(sample_delta(i-1)+OSR/2))>abs(Q_osr(sample_delta(i-1)+OSR/2)))
        RMS=abs(I_osr(sample_delta(i-1)+OSR/2))+abs(Q_osr(sample_delta(i-1)+OSR/2))/4;
    else
        RMS=abs(I_osr(sample_delta(i-1)+OSR/2))/4+abs(Q_osr(sample_delta(i-1)+OSR/2));
    end
    %	sigma_err(i)=sign(I_err(i))+sign(Q_err(i));
    sigma_err(i)=(I_err(i)+Q_err(i))/RMS;
    %sigma_err(i)=(I_err(i)+Q_err(i));
    sum_sigma_err(i)=sigma_err(i)+sum_sigma_err(i-1);
    control(i)=sigma_err(i)*k1+sum_sigma_err(i)*k2;
    
    if(control(i)>1)
        sample_delta(i)=sample_delta(i-1)+OSR-1;
        sum_sigma_err(i)=0;
        shift(i)=-1
    elseif(control(i)<-1)
        sample_delta(i)=sample_delta(i-1)+OSR+1;
        sum_sigma_err(i)=0;
        shift(i)= 1
    else
        sample_delta(i)=sample_delta(i-1)+OSR;
        shift(i)=0;
    end
    
    if(sample_delta(i)>(Simulation_Length-1)*OSR)
        break;
    end
end
find(sum_sigma_err==0)
plot(control)
figure;
plot(sigma_err);
plot(sample_delta);
plot(1:Simulation_Length*OSR,I_osr);
hold on;
plot(sample_delta(1:i),I_osr(sample_delta(1:i)),'*');
grid on;
hold on;
Signal_Channel2=Signal_Channel1(sample_delta);
Signal_Channel2_RMS=abs(real(Signal_Channel2))+abs(imag(Signal_Channel2));
%Signal_Channel=Signal_Channel2./Signal_Channel2_RMS;
%Signal_Channel=Signal_Channel2./sum(abs(Signal_Channel2(1:16)))*16;
%Signal_Channel=Signal_Channel2./abs(Signal_Channel2);
%Signal_Channel=Signal_Channel2./scale;
Signal_Channel=Signal_Channel2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%����Ϊ���໷��������
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%��������
Signal_PLL=zeros(Simulation_Length,1);
NCO_Phase = zeros(Simulation_Length,1);
Discriminator_Out=zeros(Simulation_Length,1);
Freq_Control=zeros(Simulation_Length,1);
PLL_Phase_Part=zeros(Simulation_Length,1);
PLL_Freq_Part=zeros(Simulation_Length,1);
%��·����
C1=0.1;%/(2*pi);
C2=0.02;%/(2*pi);
% C1=0.022013;
% C2=0.00024722;

for i=2:Simulation_Length
    %Signal_PLL(i)=Signal_Channel(i)*exp(-1i*mod(NCO_Phase(i-1),2*pi));
    Signal_PLL(i)=Signal_Channel(i)*exp(-1i*2*pi*mod(NCO_Phase(i-1),1));
    I_PLL(i)=real(Signal_PLL(i));
    Q_PLL(i)=imag(Signal_PLL(i));
    if PLL_Mode == 1
        Discriminator_Out(i)=atan2(Q_PLL(i),I_PLL(i));
    else if PLL_Mode == 2
            
            if(abs(I_PLL(i))>abs(Q_PLL(i)))
                RMS=abs(I_PLL(i))+abs(Q_PLL(i))/4;
            else
                RMS=abs(I_PLL(i))/4+abs(Q_PLL(i));
            end
            %Discriminator_Out(i)=sign(I_PLL(i))*Q_PLL(i);
            Discriminator_Out(i)=sign(I_PLL(i))*Q_PLL(i)/RMS;
            
            
            %Discriminator_Out(i)=sign(I_PLL(i))*Q_PLL(i)/abs(Signal_PLL(i));
            %Discriminator_Out(i)=sign(I_PLL(i))*Q_PLL(i);
        else
            Discriminator_Out(i)=(sign(I_PLL(i))*Q_PLL(i)-sign(Q_PLL(i))*I_PLL(i))...
                /(sqrt(2)*abs(Signal_PLL(i)));
        end
    end
    PLL_Phase_Part(i)=Discriminator_Out(i)*C1;
    Freq_Control(i)=PLL_Phase_Part(i)+PLL_Freq_Part(i-1);
    PLL_Freq_Part(i)=Discriminator_Out(i)*C2+PLL_Freq_Part(i-1);
    NCO_Phase(i)=NCO_Phase(i-1)+Freq_Control(i);
end
%��ͼ��ʾ���
figure
subplot(2,2,1)
%plot(-PLL_Freq_Part(2:Simulation_Length)*Freq_Sample);
plot(-PLL_Freq_Part(2:Simulation_Length));
grid on;
title('PLLƵ����Ӧ����ͼ PLL_Freq_Part');
%axis([1 Simulation_Length -100 100]);
subplot(2,2,2)
%plot(PLL_Phase_Part(2:Simulation_Length)*180/pi);
plot(PLL_Phase_Part(2:Simulation_Length));
title('PLL��λ��Ӧ����ͼ PLL_Phase_Part');
%axis([1 Simulation_Length -3*plot_scale 3*plot_scale]);
grid on;
%�趨��ʾ��Χ
Show_D=10; %��ʼλ��
Show_U=900; %��ֹλ��
Show_Length=Show_U-Show_D;
subplot(2,2,3)
plot(Signal_Channel(Show_D:Show_U),'*');
title('����PLL����������ͼ');
%axis([-2*plot_scale 2*plot_scale -2*plot_scale 2*plot_scale]);
grid on;
hold on;
subplot(2,2,3)
plot(Signal_PLL(Show_D:Show_U),'r*');
grid on;
subplot(2,2,4)
plot(Signal_PLL(Show_D:Show_U),'r*');
title('PLL�������ȶ������������ͼ');
%axis([-2*plot_scale 2*plot_scale -2*plot_scale 2*plot_scale]);
grid on;

figure
%�趨��ʾ��Χ
Show_D=1; %��ʼλ��
Show_U=900; %��ֹλ��
Show_Length=Show_U-Show_D;
subplot(2,2,1)
plot(I_Data(Show_D:Show_U));
grid on;
title('I·��Ϣ����');
%axis([1 Show_Length -2*plot_scale 2*plot_scale]);
subplot(2,2,2)
plot(Q_Data(Show_D:Show_U));
grid on;
title('Q·��Ϣ����');
%axis([1 Show_Length -2*plot_scale 2*plot_scale]);
subplot(2,2,3)
plot(I_PLL(Show_D:Show_U));
grid on;
title('PLL���I·��Ϣ����');
%axis([1 Show_Length -2*plot_scale 2*plot_scale]);
subplot(2,2,4)
plot(Q_PLL(Show_D:Show_U));
grid on;
title('PLL���Q·��Ϣ����');
%axis([1 Show_Length -2*plot_scale 2*plot_scale]);
% figure;
% plot(NCO_Phase);
% grid on;
% title('PLL NCO');
figure;plot(shift);grid;
total_shift=sum(shift)
