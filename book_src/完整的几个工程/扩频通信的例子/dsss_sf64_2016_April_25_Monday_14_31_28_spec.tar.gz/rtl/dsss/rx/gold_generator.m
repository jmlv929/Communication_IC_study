function bitout=gold_generator(reset_g,g_seed)
persistent lfsr1
persistent lfsr2

if isempty(lfsr1) || reset_g
    lfsr1=1;
    %lsfr1=hex2dec('1000000');
end

if isempty(lfsr2) || reset_g
    lfsr2=g_seed;
end


%gold code gen
lfsr1_bit25=bitget(lfsr1,25);
lfsr1_bit3=bitget(lfsr1,3);
lfsr1_bit0=bitxor(lfsr1_bit25,lfsr1_bit3);

lfsr1_bit=bitshift(lfsr1,1);
lfsr1_25bit=bitand(lfsr1_bit,33554431);%hex2dec('1ffffff')
lfsr1=bitxor(lfsr1_25bit,lfsr1_bit0);

lfsr2_bit25=bitget(lfsr2,25);
lfsr2_bit3=bitget(lfsr2,3);
lfsr2_bit2=bitget(lfsr2,2);
lfsr2_bit1=bitget(lfsr2,1);

lfsr2_bit3_2 =bitxor(lfsr2_bit3,lfsr2_bit2);
lfsr2_bit1_25=bitxor(lfsr2_bit1,lfsr2_bit25);
lfsr2_bit0=bitxor(lfsr2_bit3_2,lfsr2_bit1_25);

lfsr2_bit=bitshift(lfsr2,1);
lfsr2_25bit=bitand(lfsr2_bit,33554431);%hex2dec('1ffffff')=33554431
lfsr2=bitxor(lfsr2_25bit,lfsr2_bit0);

bitout=bitand(bitxor(lfsr1_bit25,lfsr2_bit25), 1);
end
