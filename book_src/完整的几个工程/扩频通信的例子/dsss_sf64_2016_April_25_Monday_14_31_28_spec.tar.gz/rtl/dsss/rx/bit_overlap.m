%% overlap more bit for precision
function bitout=bit_overlap(bitin,sf,num)
len=length(bitin);
bitout=zeros(size(bitin));
for i=1:len-sf*num
    bitout(i)=sum(bitin(i+(0:sf:(sf*num-1))));
end
end
