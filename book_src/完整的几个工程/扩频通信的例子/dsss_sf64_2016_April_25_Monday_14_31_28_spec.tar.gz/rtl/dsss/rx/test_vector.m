load_data;
sf_channel;

n=sf16_i>0;
plot(sf16_i(40:190));
hold;plot(80*n(40:190)-40,'r');
m=gold256(365);
mr=m(end:-1:1);
mr1=fliplr(m);

%sf=m(1:16);
peak_i=zeros(1,length(sf16_i));
peak_q=zeros(1,length(sf16_i));
peak=zeros(1,length(sf16_i));
peak_value=zeros(1,length(sf16_i));
%sf16=[1,0,0,1,0,0,1,0,1,1,1,1,1,1,1,1];;%best correlation
sf16=[1,0,0,1,0,0,1,0,1,1,1,1,1,1,1,1];

gate=120;
for i=1:length(sf16_i)-16
    match_i=sf16_i(i:i+15)';
    match_q=sf16_q(i:i+15)';
    peak_i(i)=dot(1-2*sf16,match_i);
    peak_q(i)=dot(1-2*sf16,match_q);
    peak_value(i)=abs(peak_i(i)+1i*peak_q(i));
    if(abs(peak_i(i))>abs(peak_q(i)))
        peak(i)=abs(peak_i(i))+abs(peak_q(i))/4;
    else
        peak(i)=abs(peak_i(i))/4+abs(peak_q(i));
    end
%     if peak(i)>gate
%         i
%         break;
%     end
end
figure;
plot(peak);grid;title('peak');
hold on;
plot(peak_value);grid;title('peak abs');

% figure;plot(index);grid

% index_abs=abs(fft(index));
% plot(index_abs);


 

