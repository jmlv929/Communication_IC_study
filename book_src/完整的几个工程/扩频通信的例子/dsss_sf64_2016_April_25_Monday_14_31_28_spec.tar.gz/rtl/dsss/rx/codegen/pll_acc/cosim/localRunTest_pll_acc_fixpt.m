function localRunTest_pll_acc_fixpt
   fxptPath = 'F:\work\dsss_mini\rtl\dsss\rx\codegen\pll_acc\fixpt';
addpath(fxptPath);
cleanupObj = onCleanup(@() rmpath(fxptPath));

   test_pll_cosim;
end

