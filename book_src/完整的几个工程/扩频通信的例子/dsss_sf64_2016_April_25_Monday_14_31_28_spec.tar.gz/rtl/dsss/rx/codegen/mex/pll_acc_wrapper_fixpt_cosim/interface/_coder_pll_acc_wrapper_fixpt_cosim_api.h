/*
 * _coder_pll_acc_wrapper_fixpt_cosim_api.h
 *
 * Code generation for function '_coder_pll_acc_wrapper_fixpt_cosim_api'
 *
 */

#ifndef ___CODER_PLL_ACC_WRAPPER_FIXPT_COSIM_API_H__
#define ___CODER_PLL_ACC_WRAPPER_FIXPT_COSIM_API_H__

/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "pll_acc_wrapper_fixpt_cosim_types.h"

/* Function Declarations */
extern void pll_acc_wrapper_fixpt_cosim_api(const mxArray * const prhs[1], const
  mxArray *plhs[2]);

#endif

/* End of code generation (_coder_pll_acc_wrapper_fixpt_cosim_api.h) */
