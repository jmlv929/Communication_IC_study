/*
 * pll_acc_fixpt_data.c
 *
 * Code generation for function 'pll_acc_fixpt_data'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "pll_acc_fixpt.h"
#include "pll_acc_fixpt_data.h"

/* Variable Definitions */
emlrtCTX emlrtRootTLSGlobal = NULL;
const volatile char_T *emlrtBreakCheckR2012bFlagVar;
const mxArray *eml_mx;
const mxArray *b_eml_mx;
const mxArray *c_eml_mx;
emlrtContext emlrtContextGlobal = { true, false, 131418U, NULL, "pll_acc_fixpt",
  NULL, false, { 2045744189U, 2170104910U, 2743257031U, 4284093946U }, NULL };

/* End of code generation (pll_acc_fixpt_data.c) */
