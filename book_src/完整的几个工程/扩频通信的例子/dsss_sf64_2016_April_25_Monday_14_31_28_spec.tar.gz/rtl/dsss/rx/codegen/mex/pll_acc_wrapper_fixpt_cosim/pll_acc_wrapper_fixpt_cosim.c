/*
 * pll_acc_wrapper_fixpt_cosim.c
 *
 * Code generation for function 'pll_acc_wrapper_fixpt_cosim'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "pll_acc_wrapper_fixpt_cosim.h"
#include "pll_acc_wrapper_fixpt_cosim_data.h"

/* Variable Definitions */
static emlrtRSInfo emlrtRSI = { 9, "pll_acc_wrapper_fixpt_cosim",
  "F:\\work\\dsss_mini\\rtl\\dsss\\rx\\codegen\\pll_acc\\cosim\\pll_acc_wrapper_fixpt_cosim.m"
};

static emlrtRSInfo b_emlrtRSI = { 21, "pll_acc_fixpt_cosim",
  "F:\\work\\dsss_mini\\rtl\\dsss\\rx\\codegen\\pll_acc\\cosim\\pll_acc_fixpt_cosim.m"
};

static emlrtMCInfo b_emlrtMCI = { 10, 19, "pll_acc_wrapper_fixpt_cosim",
  "F:\\work\\dsss_mini\\rtl\\dsss\\rx\\codegen\\pll_acc\\cosim\\pll_acc_wrapper_fixpt_cosim.m"
};

static emlrtMCInfo c_emlrtMCI = { 11, 27, "pll_acc_wrapper_fixpt_cosim",
  "F:\\work\\dsss_mini\\rtl\\dsss\\rx\\codegen\\pll_acc\\cosim\\pll_acc_wrapper_fixpt_cosim.m"
};

static emlrtMCInfo d_emlrtMCI = { 24, 1, "pll_acc_fixpt_cosim",
  "F:\\work\\dsss_mini\\rtl\\dsss\\rx\\codegen\\pll_acc\\cosim\\pll_acc_fixpt_cosim.m"
};

static emlrtMCInfo e_emlrtMCI = { 27, 1, "pll_acc_fixpt_cosim",
  "F:\\work\\dsss_mini\\rtl\\dsss\\rx\\codegen\\pll_acc\\cosim\\pll_acc_fixpt_cosim.m"
};

static emlrtMCInfo f_emlrtMCI = { 28, 1, "pll_acc_fixpt_cosim",
  "F:\\work\\dsss_mini\\rtl\\dsss\\rx\\codegen\\pll_acc\\cosim\\pll_acc_fixpt_cosim.m"
};

static emlrtRSInfo c_emlrtRSI = { 11, "pll_acc_wrapper_fixpt_cosim",
  "F:\\work\\dsss_mini\\rtl\\dsss\\rx\\codegen\\pll_acc\\cosim\\pll_acc_wrapper_fixpt_cosim.m"
};

static emlrtRSInfo d_emlrtRSI = { 10, "pll_acc_wrapper_fixpt_cosim",
  "F:\\work\\dsss_mini\\rtl\\dsss\\rx\\codegen\\pll_acc\\cosim\\pll_acc_wrapper_fixpt_cosim.m"
};

static emlrtRSInfo e_emlrtRSI = { 28, "pll_acc_fixpt_cosim",
  "F:\\work\\dsss_mini\\rtl\\dsss\\rx\\codegen\\pll_acc\\cosim\\pll_acc_fixpt_cosim.m"
};

static emlrtRSInfo f_emlrtRSI = { 27, "pll_acc_fixpt_cosim",
  "F:\\work\\dsss_mini\\rtl\\dsss\\rx\\codegen\\pll_acc\\cosim\\pll_acc_fixpt_cosim.m"
};

static emlrtRSInfo g_emlrtRSI = { 24, "pll_acc_fixpt_cosim",
  "F:\\work\\dsss_mini\\rtl\\dsss\\rx\\codegen\\pll_acc\\cosim\\pll_acc_fixpt_cosim.m"
};

/* Function Declarations */
static const mxArray *b_double(const emlrtStack *sp, const mxArray *b,
  emlrtMCInfo *location);
static void hdlverifier_assert(const emlrtStack *sp, const mxArray *b, const
  mxArray *c, const mxArray *d, emlrtMCInfo *location);
static void pll_acc_fixpt_sysobj_cosim(const emlrtStack *sp, const mxArray *b,
  emlrtMCInfo *location, const mxArray **c, const mxArray **d);

/* Function Definitions */
static const mxArray *b_double(const emlrtStack *sp, const mxArray *b,
  emlrtMCInfo *location)
{
  const mxArray *pArray;
  const mxArray *m4;
  pArray = b;
  return emlrtCallMATLABR2012b(sp, 1, &m4, 1, &pArray, "double", true, location);
}

static void hdlverifier_assert(const emlrtStack *sp, const mxArray *b, const
  mxArray *c, const mxArray *d, emlrtMCInfo *location)
{
  const mxArray *pArrays[3];
  pArrays[0] = b;
  pArrays[1] = c;
  pArrays[2] = d;
  emlrtCallMATLABR2012b(sp, 0, NULL, 3, pArrays, "hdlverifier.assert", true,
                        location);
}

static void pll_acc_fixpt_sysobj_cosim(const emlrtStack *sp, const mxArray *b,
  emlrtMCInfo *location, const mxArray **c, const mxArray **d)
{
  const mxArray *pArray;
  const mxArray *mv0[2];
  pArray = b;
  emlrtAssign(c, emlrtCallMATLABR2012b(sp, 2, &mv0[0], 1, &pArray,
    "pll_acc_fixpt_sysobj_cosim", true, location));
  emlrtAssign(d, mv0[1]);
}

void pll_acc_wrapper_fixpt_cosim(const emlrtStack *sp, real_T Discriminator_Out,
  const mxArray **freq_fc_out, const mxArray **sigma_phase_err_out)
{
  real_T d0;
  int8_T Discriminator_Out_in;
  const mxArray *sigma_phase_err_out_out = NULL;
  const mxArray *freq_fc_out_out = NULL;
  int32_T i0;
  int16_T i1;
  int32_T i2;
  int32_T i3;
  int32_T i4;
  int32_T i5;
  int16_T ref_freq_fc_out;
  int16_T ref_sigma_phase_err_out;
  const mxArray *y;
  const mxArray *b_y;
  const mxArray *m0;
  const mxArray *b_sigma_phase_err_out = NULL;
  const mxArray *b_freq_fc_out = NULL;
  const mxArray *c_y;
  const mxArray *d_y;
  static const char_T cv0[11] = { 'f', 'r', 'e', 'q', '_', 'f', 'c', '_', 'o',
    'u', 't' };

  char_T u[11];
  const mxArray *e_y;
  static const int32_T iv0[2] = { 1, 11 };

  const mxArray *f_y;
  const mxArray *g_y;
  static const char_T cv1[19] = { 's', 'i', 'g', 'm', 'a', '_', 'p', 'h', 'a',
    's', 'e', '_', 'e', 'r', 'r', '_', 'o', 'u', 't' };

  char_T b_u[19];
  const mxArray *h_y;
  static const int32_T iv1[2] = { 1, 19 };

  emlrtStack st;
  emlrtStack b_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  *sigma_phase_err_out = NULL;
  *freq_fc_out = NULL;

  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*                                                                           % */
  /*            Generated by MATLAB 8.5 and Fixed-Point Designer 5.0           % */
  /*                                                                           % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  d0 = muDoubleScalarFloor(Discriminator_Out * 64.0);
  if (muDoubleScalarIsNaN(d0) || muDoubleScalarIsInf(d0)) {
    d0 = 0.0;
  } else {
    d0 = muDoubleScalarRem(d0, 256.0);
  }

  if (d0 < 0.0) {
    Discriminator_Out_in = (int8_T)-(int8_T)(uint8_T)-d0;
  } else {
    Discriminator_Out_in = (int8_T)(uint8_T)d0;
  }

  st.site = &emlrtRSI;
  sigma_phase_err_out_out = NULL;
  freq_fc_out_out = NULL;

  /*  Auto generated function to simulate the generated HDL code using cosimulation */
  /*   */
  /*  Generated by MATLAB 8.5 and HDL Coder 3.6 */
  /*  Declare persistent variables */
  /*  Initialize persistent variables */
  /*  Call the original MATLAB function to get reference signal */
  b_st.site = &b_emlrtRSI;

  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*                                                                           % */
  /*            Generated by MATLAB 8.5 and Fixed-Point Designer 5.0           % */
  /*                                                                           % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* % use to get a pid control system for PLL */
  i0 = (sigma_phase_err << 17) + (Discriminator_Out_in << 21);
  if (i0 >= 0) {
    i1 = (int16_T)((uint32_T)i0 >> 17);
  } else {
    i1 = (int16_T)~(~(uint32_T)i0 >> 17);
  }

  if ((int16_T)(i1 & 8192) != 0) {
    sigma_phase_err = (int16_T)(i1 | -8192);
  } else {
    sigma_phase_err = (int16_T)(i1 & 8191);
  }

  i0 = sigma_phase_err << 12;
  if (i0 >= 0) {
    i2 = (int32_T)((uint32_T)i0 >> 5);
  } else {
    i2 = (int32_T)~(~(uint32_T)i0 >> 5);
  }

  i0 = (freq_fc << 15) + i2;
  i3 = Discriminator_Out_in << 18;
  if (i0 >= 0) {
    i4 = (int32_T)((uint32_T)i0 >> 1);
  } else {
    i4 = (int32_T)~(~(uint32_T)i0 >> 1);
  }

  if (i3 >= 0) {
    i5 = (int32_T)((uint32_T)i3 >> 8);
  } else {
    i5 = (int32_T)~(~(uint32_T)i3 >> 8);
  }

  i0 = i4 + i5;
  if (i0 >= 0) {
    freq_fc = (int16_T)((uint32_T)i0 >> 14);
  } else {
    freq_fc = (int16_T)~(~(uint32_T)i0 >> 14);
  }

  ref_freq_fc_out = freq_fc;
  i1 = sigma_phase_err;
  if (i1 >= 0) {
    ref_sigma_phase_err_out = (int16_T)((uint32_T)i1 >> 4);
  } else {
    ref_sigma_phase_err_out = (int16_T)~(~(uint32_T)i1 >> 4);
  }

  /*  Run cosimulation */
  y = NULL;
  b_y = NULL;
  m0 = emlrtCreateNumericMatrix(1, 1, mxINT8_CLASS, mxREAL);
  *(int8_T *)mxGetData(m0) = Discriminator_Out_in;
  emlrtAssign(&b_y, m0);
  emlrtAssign(&y, emlrtCreateFIR2013b(&st, eml_mx, b_eml_mx, "simulinkarray",
    b_y, true, false));
  b_st.site = &g_emlrtRSI;
  pll_acc_fixpt_sysobj_cosim(&b_st, y, &d_emlrtMCI, &b_freq_fc_out,
    &b_sigma_phase_err_out);
  emlrtAssign(&freq_fc_out_out, emlrtAlias(b_freq_fc_out));
  emlrtAssign(&sigma_phase_err_out_out, emlrtAlias(b_sigma_phase_err_out));

  /*  Verify the cosimulation output */
  c_y = NULL;
  d_y = NULL;
  m0 = emlrtCreateNumericMatrix(1, 1, mxINT16_CLASS, mxREAL);
  *(int16_T *)mxGetData(m0) = ref_freq_fc_out;
  emlrtAssign(&d_y, m0);
  emlrtAssign(&c_y, emlrtCreateFIR2013b(&st, eml_mx, c_eml_mx, "simulinkarray",
    d_y, true, false));
  for (i0 = 0; i0 < 11; i0++) {
    u[i0] = cv0[i0];
  }

  e_y = NULL;
  m0 = emlrtCreateCharArray(2, iv0);
  emlrtInitCharArrayR2013a(&st, 11, m0, &u[0]);
  emlrtAssign(&e_y, m0);
  b_st.site = &f_emlrtRSI;
  hdlverifier_assert(&b_st, emlrtAlias(freq_fc_out_out), c_y, e_y, &e_emlrtMCI);
  f_y = NULL;
  g_y = NULL;
  m0 = emlrtCreateNumericMatrix(1, 1, mxINT16_CLASS, mxREAL);
  *(int16_T *)mxGetData(m0) = ref_sigma_phase_err_out;
  emlrtAssign(&g_y, m0);
  emlrtAssign(&f_y, emlrtCreateFIR2013b(&st, eml_mx, c_eml_mx, "simulinkarray",
    g_y, true, false));
  for (i0 = 0; i0 < 19; i0++) {
    b_u[i0] = cv1[i0];
  }

  h_y = NULL;
  m0 = emlrtCreateCharArray(2, iv1);
  emlrtInitCharArrayR2013a(&st, 19, m0, &b_u[0]);
  emlrtAssign(&h_y, m0);
  b_st.site = &e_emlrtRSI;
  hdlverifier_assert(&b_st, emlrtAlias(sigma_phase_err_out_out), f_y, h_y,
                     &f_emlrtMCI);
  emlrtDestroyArray(&b_freq_fc_out);
  emlrtDestroyArray(&b_sigma_phase_err_out);
  st.site = &d_emlrtRSI;
  emlrtAssign(freq_fc_out, b_double(&st, emlrtAlias(freq_fc_out_out),
    &b_emlrtMCI));
  st.site = &c_emlrtRSI;
  emlrtAssign(sigma_phase_err_out, b_double(&st, emlrtAlias
    (sigma_phase_err_out_out), &c_emlrtMCI));
  emlrtDestroyArray(&freq_fc_out_out);
  emlrtDestroyArray(&sigma_phase_err_out_out);
}

/* End of code generation (pll_acc_wrapper_fixpt_cosim.c) */
