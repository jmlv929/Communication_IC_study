/*
 * pll_acc_fixpt_types.h
 *
 * Code generation for function 'pll_acc_fixpt'
 *
 */

#ifndef __PLL_ACC_FIXPT_TYPES_H__
#define __PLL_ACC_FIXPT_TYPES_H__

/* Include files */
#include "rtwtypes.h"
#endif

/* End of code generation (pll_acc_fixpt_types.h) */
