/*
 * _coder_pll_acc_wrapper_fixpt_cosim_info.h
 *
 * Code generation for function 'pll_acc_wrapper_fixpt_cosim'
 *
 */

#ifndef ___CODER_PLL_ACC_WRAPPER_FIXPT_COSIM_INFO_H__
#define ___CODER_PLL_ACC_WRAPPER_FIXPT_COSIM_INFO_H__
/* Include files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif
/* End of code generation (_coder_pll_acc_wrapper_fixpt_cosim_info.h) */
