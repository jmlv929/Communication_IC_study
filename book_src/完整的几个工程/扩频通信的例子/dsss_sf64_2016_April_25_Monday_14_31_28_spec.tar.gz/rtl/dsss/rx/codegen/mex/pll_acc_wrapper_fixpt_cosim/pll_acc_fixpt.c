/*
 * pll_acc_fixpt.c
 *
 * Code generation for function 'pll_acc_fixpt'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "pll_acc_wrapper_fixpt_cosim.h"
#include "pll_acc_fixpt.h"
#include "pll_acc_wrapper_fixpt_cosim_data.h"

/* Function Definitions */
void freq_fc_not_empty_init(void)
{
}

void pll_acc_fixpt_init(void)
{
  freq_fc = 0;
  sigma_phase_err = 0;
}

void sigma_phase_err_not_empty_init(void)
{
}

/* End of code generation (pll_acc_fixpt.c) */
