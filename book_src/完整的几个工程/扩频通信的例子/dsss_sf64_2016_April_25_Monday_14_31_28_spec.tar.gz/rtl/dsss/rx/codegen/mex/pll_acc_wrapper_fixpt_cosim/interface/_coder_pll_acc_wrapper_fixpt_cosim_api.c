/*
 * _coder_pll_acc_wrapper_fixpt_cosim_api.c
 *
 * Code generation for function '_coder_pll_acc_wrapper_fixpt_cosim_api'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "pll_acc_wrapper_fixpt_cosim.h"
#include "_coder_pll_acc_wrapper_fixpt_cosim_api.h"
#include "pll_acc_wrapper_fixpt_cosim_data.h"

/* Function Declarations */
static real_T b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId);
static real_T c_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId);
static real_T emlrt_marshallIn(const emlrtStack *sp, const mxArray
  *Discriminator_Out, const char_T *identifier);

/* Function Definitions */
static real_T b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId)
{
  real_T y;
  y = c_emlrt_marshallIn(sp, emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static real_T c_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId)
{
  real_T ret;
  emlrtCheckBuiltInR2012b(sp, msgId, src, "double", false, 0U, 0);
  ret = *(real_T *)mxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}

static real_T emlrt_marshallIn(const emlrtStack *sp, const mxArray
  *Discriminator_Out, const char_T *identifier)
{
  real_T y;
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = identifier;
  thisId.fParent = NULL;
  y = b_emlrt_marshallIn(sp, emlrtAlias(Discriminator_Out), &thisId);
  emlrtDestroyArray(&Discriminator_Out);
  return y;
}

void pll_acc_wrapper_fixpt_cosim_api(const mxArray * const prhs[1], const
  mxArray *plhs[2])
{
  real_T Discriminator_Out;
  const mxArray *sigma_phase_err_out;
  const mxArray *freq_fc_out;
  emlrtStack st = { NULL, NULL, NULL };

  st.tls = emlrtRootTLSGlobal;

  /* Marshall function inputs */
  Discriminator_Out = emlrt_marshallIn(&st, emlrtAliasP(prhs[0]),
    "Discriminator_Out");

  /* Invoke the target function */
  pll_acc_wrapper_fixpt_cosim(&st, Discriminator_Out, &freq_fc_out,
    &sigma_phase_err_out);

  /* Marshall function outputs */
  plhs[0] = freq_fc_out;
  plhs[1] = sigma_phase_err_out;
}

/* End of code generation (_coder_pll_acc_wrapper_fixpt_cosim_api.c) */
