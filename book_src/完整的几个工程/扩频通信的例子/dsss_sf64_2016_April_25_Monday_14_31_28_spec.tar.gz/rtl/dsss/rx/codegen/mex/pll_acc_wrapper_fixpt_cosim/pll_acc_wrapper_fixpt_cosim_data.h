/*
 * pll_acc_wrapper_fixpt_cosim_data.h
 *
 * Code generation for function 'pll_acc_wrapper_fixpt_cosim_data'
 *
 */

#ifndef __PLL_ACC_WRAPPER_FIXPT_COSIM_DATA_H__
#define __PLL_ACC_WRAPPER_FIXPT_COSIM_DATA_H__

/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "pll_acc_wrapper_fixpt_cosim_types.h"

/* Variable Declarations */
extern emlrtCTX emlrtRootTLSGlobal;
extern const volatile char_T *emlrtBreakCheckR2012bFlagVar;
extern int16_T freq_fc;
extern int16_T sigma_phase_err;
extern const mxArray *eml_mx;
extern const mxArray *b_eml_mx;
extern const mxArray *c_eml_mx;
extern emlrtContext emlrtContextGlobal;

#endif

/* End of code generation (pll_acc_wrapper_fixpt_cosim_data.h) */
