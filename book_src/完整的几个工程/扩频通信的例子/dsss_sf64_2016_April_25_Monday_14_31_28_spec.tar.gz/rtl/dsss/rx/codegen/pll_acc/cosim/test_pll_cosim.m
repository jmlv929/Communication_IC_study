clc;
clear all ;
close all
global Discriminator_Out_v
global freq_fc_v
%%
load max_IQ_sync_I
load max_IQ_sync_Q
load Signal_PLL_I
load Signal_PLL_Q
load Discriminator_Out
load freq_fc
load sigma_phase_err
Discriminator_Out_v = Discriminator_Out;
freq_fc_v = freq_fc;
%% check verilog
omit = 1;
bit_n = 8;
fix_coef = 2^(bit_n - 1)/(pi);
rot_angle = freq_fc ./ fix_coef;
max_IQ_sync = max_IQ_sync_I + 1j*max_IQ_sync_Q;
Signal_PLL_v = Signal_PLL_I + 1j*Signal_PLL_Q;
Signal_PLL_m = max_IQ_sync .* exp( -1j*rot_angle );
rot_angle_true = angle( max_IQ_sync ./ Signal_PLL_v );
Signal_PLL_cmp = [ Signal_PLL_v, Signal_PLL_m, Signal_PLL_m - Signal_PLL_v, rot_angle, rot_angle_true ];
scatter( max_IQ_sync_I, max_IQ_sync_Q, 'g*' );
grid;
figure;
plot( Signal_PLL_m, 'g*' );
grid;
title( 'Signal_PLL_m' );
figure;
plot( max_IQ_sync_Q( omit:end ), 'b*' );
grid;
title( 'max_IQ_sync_Q part' );
%% use pll to caculate
len = length( max_IQ_sync_I );
max_IQ_sync = zeros( len, 1 );
Signal_PLL = zeros( len, 1 );
freq_fc_out = zeros( len, 1 );
sigma_phase_err_out = zeros( len, 1 );
diff_i = zeros( len, 1 );
freq_fc_diff = zeros( len, 1 );
for i = 1:len
    max_IQ_sync( i ) = max_IQ_sync_I( i ) + 1j*max_IQ_sync_Q( i );
    [Signal_PLL( i ),freq_fc_out( i ),sigma_phase_err_out( i )] = pll_sub( max_IQ_sync( i ) );
    freq_fc_diff( i ) = freq_fc_out( i )*fix_coef - freq_fc( i );
end
%% result dispose
Discriminator_Out_ok = atan( imag( Signal_PLL ) ./ real( Signal_PLL ) )*fix_coef;
Discriminator_Out_fixed = atan( max_IQ_sync_Q ./ max_IQ_sync_I )*fix_coef;
Discriminator_Out_fixed1 = atan( Signal_PLL_Q ./ Signal_PLL_I )*fix_coef;
Discriminator_Out_cmp = [ max_IQ_sync_I, max_IQ_sync_Q, Discriminator_Out_ok, Discriminator_Out_ok - Discriminator_Out_v, Discriminator_Out_v, Discriminator_Out_fixed1, Discriminator_Out_fixed1 - Discriminator_Out_v ];
freq_fc_cmp = [ freq_fc_out*fix_coef, freq_fc, freq_fc_diff ];
sigma_phase_err_diff = sigma_phase_err_out*fix_coef - sigma_phase_err;
sigma_phase_err_cmp = [ sigma_phase_err_out*fix_coef, sigma_phase_err, sigma_phase_err_diff ];
%% check pll
figure;
plot( Signal_PLL( omit:end ), 'r*' );
grid;
title( 'pll result' );
figure;
plot( imag( Signal_PLL( omit:end ) ), 'b*' );
grid;
title( 'Signal_PLL image part' );
figure;
plot( Signal_PLL_Q( omit:end ), 'b*' );
grid;
title( 'verilog Signal PLL image part' );
figure;
plot( freq_fc_out( omit:end ) );
grid;
title( 'freq_fc_out result' );
