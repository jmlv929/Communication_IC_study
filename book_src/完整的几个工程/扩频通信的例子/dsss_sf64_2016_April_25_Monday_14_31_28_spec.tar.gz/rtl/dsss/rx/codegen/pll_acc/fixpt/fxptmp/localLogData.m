function localLogData(out_freq_fc_out, out_sigma_phase_err_out, in_Discriminator_Out)
global gEMLSimLogVal_out_freq_fc_out;
global gEMLSimLogVal_out_sigma_phase_err_out;
global gEMLSimLogVal_in_Discriminator_Out;
global gEMLSimLogRunIdx;
persistent maxIdx;

if isempty(gEMLSimLogRunIdx)
	gEMLSimLogRunIdx = 1;
	maxIdx = 1;
		gEMLSimLogVal_out_freq_fc_out = {out_freq_fc_out};
		gEMLSimLogVal_out_sigma_phase_err_out = {out_sigma_phase_err_out};
		gEMLSimLogVal_in_Discriminator_Out = {in_Discriminator_Out};
	gEMLSimLogRunIdx = gEMLSimLogRunIdx+1;
	return

end

if gEMLSimLogRunIdx > maxIdx
	maxIdx = 2 * maxIdx;
		gEMLSimLogVal_out_freq_fc_out(maxIdx, :) = {gEMLSimLogVal_out_freq_fc_out{1}};
		gEMLSimLogVal_out_sigma_phase_err_out(maxIdx, :) = {gEMLSimLogVal_out_sigma_phase_err_out{1}};
		gEMLSimLogVal_in_Discriminator_Out(maxIdx, :) = {gEMLSimLogVal_in_Discriminator_Out{1}};
end

	gEMLSimLogVal_out_freq_fc_out(gEMLSimLogRunIdx, :) = {out_freq_fc_out};
	gEMLSimLogVal_out_sigma_phase_err_out(gEMLSimLogRunIdx, :) = {out_sigma_phase_err_out};
	gEMLSimLogVal_in_Discriminator_Out(gEMLSimLogRunIdx, :) = {in_Discriminator_Out};
gEMLSimLogRunIdx = gEMLSimLogRunIdx+1;

