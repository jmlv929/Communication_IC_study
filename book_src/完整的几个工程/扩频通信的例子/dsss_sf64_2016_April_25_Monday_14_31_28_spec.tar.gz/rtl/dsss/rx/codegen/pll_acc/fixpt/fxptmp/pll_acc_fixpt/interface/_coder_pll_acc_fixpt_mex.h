/*
 * _coder_pll_acc_fixpt_mex.h
 *
 * Code generation for function '_coder_pll_acc_fixpt_mex'
 *
 */

#ifndef ___CODER_PLL_ACC_FIXPT_MEX_H__
#define ___CODER_PLL_ACC_FIXPT_MEX_H__

/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "pll_acc_fixpt_types.h"

/* Function Declarations */
extern void mexFunction(int32_T nlhs, mxArray *plhs[], int32_T nrhs, const
  mxArray *prhs[]);

#endif

/* End of code generation (_coder_pll_acc_fixpt_mex.h) */
