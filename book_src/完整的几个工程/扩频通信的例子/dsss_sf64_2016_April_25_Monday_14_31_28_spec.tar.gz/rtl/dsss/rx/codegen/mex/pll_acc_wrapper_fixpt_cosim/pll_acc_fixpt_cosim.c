/*
 * pll_acc_fixpt_cosim.c
 *
 * Code generation for function 'pll_acc_fixpt_cosim'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "pll_acc_wrapper_fixpt_cosim.h"
#include "pll_acc_fixpt_cosim.h"

/* Function Definitions */
void initialized_not_empty_init(void)
{
}

void pll_acc_fixpt_cosim_init(void)
{
}

/* End of code generation (pll_acc_fixpt_cosim.c) */
