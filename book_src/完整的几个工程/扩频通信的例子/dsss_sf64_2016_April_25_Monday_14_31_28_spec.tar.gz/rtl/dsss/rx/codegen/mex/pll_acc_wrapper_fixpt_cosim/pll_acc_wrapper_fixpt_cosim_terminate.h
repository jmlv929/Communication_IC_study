/*
 * pll_acc_wrapper_fixpt_cosim_terminate.h
 *
 * Code generation for function 'pll_acc_wrapper_fixpt_cosim_terminate'
 *
 */

#ifndef __PLL_ACC_WRAPPER_FIXPT_COSIM_TERMINATE_H__
#define __PLL_ACC_WRAPPER_FIXPT_COSIM_TERMINATE_H__

/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "pll_acc_wrapper_fixpt_cosim_types.h"

/* Function Declarations */
extern void pll_acc_wrapper_fixpt_cosim_atexit(void);
extern void pll_acc_wrapper_fixpt_cosim_terminate(void);

#endif

/* End of code generation (pll_acc_wrapper_fixpt_cosim_terminate.h) */
