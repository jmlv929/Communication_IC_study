/*
 * _coder_pll_acc_fixpt_api.c
 *
 * Code generation for function '_coder_pll_acc_fixpt_api'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "pll_acc_fixpt.h"
#include "_coder_pll_acc_fixpt_api.h"
#include "pll_acc_fixpt_data.h"

/* Function Declarations */
static int8_T b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId);
static int8_T c_emlrt_marshallIn(const mxArray *src);
static int8_T emlrt_marshallIn(const emlrtStack *sp, const mxArray
  *Discriminator_Out, const char_T *identifier);
static const mxArray *emlrt_marshallOut(const emlrtStack *sp, const int16_T u);

/* Function Definitions */
static int8_T b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId)
{
  int8_T y;
  emlrtCheckFiR2012b(sp, parentId, u, false, 0U, 0, eml_mx, b_eml_mx);
  y = c_emlrt_marshallIn(emlrtAlias(u));
  emlrtDestroyArray(&u);
  return y;
}

static int8_T c_emlrt_marshallIn(const mxArray *src)
{
  int8_T ret;
  const mxArray *mxInt;
  mxInt = emlrtImportFiIntArrayR2008b(src);
  ret = *(int8_T *)mxGetData(mxInt);
  emlrtDestroyArray(&mxInt);
  emlrtDestroyArray(&src);
  return ret;
}

static int8_T emlrt_marshallIn(const emlrtStack *sp, const mxArray
  *Discriminator_Out, const char_T *identifier)
{
  int8_T y;
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = identifier;
  thisId.fParent = NULL;
  y = b_emlrt_marshallIn(sp, emlrtAlias(Discriminator_Out), &thisId);
  emlrtDestroyArray(&Discriminator_Out);
  return y;
}

static const mxArray *emlrt_marshallOut(const emlrtStack *sp, const int16_T u)
{
  const mxArray *y;
  const mxArray *b_y;
  const mxArray *m0;
  y = NULL;
  b_y = NULL;
  m0 = emlrtCreateNumericMatrix(1, 1, mxINT16_CLASS, mxREAL);
  *(int16_T *)mxGetData(m0) = u;
  emlrtAssign(&b_y, m0);
  emlrtAssign(&y, emlrtCreateFIR2013b(sp, eml_mx, c_eml_mx, "simulinkarray", b_y,
    true, false));
  return y;
}

void pll_acc_fixpt_api(const mxArray * const prhs[1], const mxArray *plhs[2])
{
  int8_T Discriminator_Out;
  int16_T sigma_phase_err_out;
  int16_T freq_fc_out;
  emlrtStack st = { NULL, NULL, NULL };

  st.tls = emlrtRootTLSGlobal;

  /* Marshall function inputs */
  Discriminator_Out = emlrt_marshallIn(&st, emlrtAliasP(prhs[0]),
    "Discriminator_Out");

  /* Invoke the target function */
  pll_acc_fixpt(&st, Discriminator_Out, &freq_fc_out, &sigma_phase_err_out);

  /* Marshall function outputs */
  plhs[0] = emlrt_marshallOut(&st, freq_fc_out);
  plhs[1] = emlrt_marshallOut(&st, sigma_phase_err_out);
}

/* End of code generation (_coder_pll_acc_fixpt_api.c) */
