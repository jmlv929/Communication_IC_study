/*
 * pll_acc_wrapper_fixpt_cosim_types.h
 *
 * Code generation for function 'pll_acc_wrapper_fixpt_cosim'
 *
 */

#ifndef __PLL_ACC_WRAPPER_FIXPT_COSIM_TYPES_H__
#define __PLL_ACC_WRAPPER_FIXPT_COSIM_TYPES_H__

/* Include files */
#include "rtwtypes.h"
#endif

/* End of code generation (pll_acc_wrapper_fixpt_cosim_types.h) */
