% use this module to set 3bit agc
function [sf_agc_i,sf_agc_q]=sf_agc_bit3(sf_i,sf_q)
% use 32 chip for agc
len=32;
sf_agc_i=zeros(1,len);
sf_agc_q=zeros(1,len);
sum_i=sum(abs(sf_i(1:len)));
sum_q=sum(abs(sf_q(1:len)));
ave=(sum_i+sum_q)/len;
agc_ave_1dot5=ave*0.75;
agc_ave_1=ave*0.5;
agc_ave_dot5=ave*0.25;
for i=1:len
    abs_sf_i=abs(sf_i(i));
    if(abs_sf_i>agc_ave_1dot5)
        abs_sf_index=3;
    elseif(abs_sf_i>agc_ave_1)
        abs_sf_index=2;
    elseif(abs_sf_i>agc_ave_dot5)
        abs_sf_index=1;
    else
        abs_sf_index=0;
    end
    if(abs_sf_index==0)
        sf_agc_i(i)=0;
    elseif(sf_i(i)<0)
        sf_agc_i(i)=-abs_sf_index;
    else
        sf_agc_i(i)=abs_sf_index;
    end
    
    abs_sf_q=abs(sf_q(i));
    if(abs_sf_q>agc_ave_1dot5)
        abs_sf_index=3;
    elseif(abs_sf_q>agc_ave_1)
        abs_sf_index=2;
    elseif(abs_sf_q>agc_ave_dot5)
        abs_sf_index=1;
    else
        abs_sf_index=0;
    end
    if(abs_sf_index==0)
        sf_agc_q(i)=0;
    elseif(sf_q(i)<0)
        sf_agc_q(i)=-abs_sf_index;
    else
        sf_agc_q(i)=abs_sf_index;
    end
    
end

end

