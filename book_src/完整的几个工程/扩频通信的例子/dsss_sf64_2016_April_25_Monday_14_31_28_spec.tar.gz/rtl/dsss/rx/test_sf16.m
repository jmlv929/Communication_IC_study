load_data;
test_gold;
sf_channel;

gate=120;
sf=16;
len=length(sf16_i);

index=zeros(1,len);
de_sf_i=zeros(len,sf);
de_sf_q=zeros(len,sf);
summit=zeros(1,len);
max_i=zeros(1,len);
max_q=zeros(1,len);
peak=zeros(1,len);
peak_i=zeros(1,len);
peak_q=zeros(1,len);
peak_value=zeros(1,len);

for i=1:len-sf
    match_i=sf16_i(i:i+sf-1)';
    match_q=sf16_q(i:i+sf-1)';
    [de_sf_i(i,:),de_sf_q(i,:)]=de_sf(match_i,match_q,16,sf16);
    %get sf=16 chip;
    peak_i(i)=dot(1-2*sf16,match_i);
    peak_q(i)=dot(1-2*sf16,match_q);
    peak_value(i)=abs(peak_i(i)+1i*peak_q(i));

    max_i(i)=sum(de_sf_i(i,:));
    max_q(i)=sum(de_sf_q(i,:));
    summit(i)=abs(max_i(i)+1i*max_q(i));
end

for i=1:len-sf
    [peak(i),index(i)]=de_sf_fft(de_sf_i(i,:),de_sf_q(i,:));
    %     if peak(i)>gate
    %         i
    %         break;
    %     end
end

y=zeros(1,len);
y(best_pos:sf:end)=max(peak);

figure;
plot(peak);grid;title('FFT peak value');
hold;
plot(summit);grid;title('FFT peak pos');
plot(peak_value);grid;title('FFT peak pos');
stem(y);
figure;
plot(index);grid;title('FFT max index pos');

index_abs=abs(fft(index));
plot(index_abs);

%% more bit sum
num=8;
peak8=bit_overlap(peak,sf,num)/num;
peak81=bit_overlap_index(peak,index,sf,num)/num;

figure;
plot(peak8);grid;title('FFT 8bit peak value');
hold;
plot(peak81);grid;title('FFT 8bit index peak value');
stem(y);
%% get best pos 
dim_len=floor(len/sf);
index8_fold=reshape(index(1:dim_len*sf),sf,dim_len);

peak8_fold=reshape(peak8(1:dim_len*sf),sf,dim_len);
[val,best_pos]=max(peak8_fold);

%% get filter best pos
peak81_fold=reshape(peak81(1:dim_len*sf),sf,dim_len);
[val1,best_pos1]=max(peak81_fold);

%% find max
figure;
plot(best_pos);grid;title('FFT posithon peak value');
hold 
plot(best_pos1);grid;title('FFT posithon peak value');

