function [max_corx,max_index]=search_gold(sf_64,bit8_sn)
sf_len=64;
corx=zeros(1,sf_len);
sf_64_shift=sf_64;
sf_64_all=zeros(sf_len,sf_len);
for i=1:sf_len
    corx(i)=bit8_gold(sf_64_shift,bit8_sn);
    sf_64_all(i,:)=sf_64_shift;
    sf_64_shift(1)=sf_64_shift(64);
    sf_64_shift(2:64)=sf_64_shift(1:63);
end

[max_corx,max_index]=max(corx);

end