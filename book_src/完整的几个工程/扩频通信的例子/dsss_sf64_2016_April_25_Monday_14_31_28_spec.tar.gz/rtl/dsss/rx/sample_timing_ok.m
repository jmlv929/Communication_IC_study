function [sample_delta]=sample_timing_ok(I_osr,Q_osr)
%OSR=18;
% y = cast(0,'like',T.y);
% for n = 1:length(x)
%     y(:) = y + x(n);
% end

persistent sum_sigma_err
if isempty(sum_sigma_err)
    %fm = fimath('RoundingMethod', 'Floor', 'OverflowAction', 'Wrap', 'ProductMode', 'FullPrecision', 'MaxProductWordLength', 128, 'SumMode', 'FullPrecision', 'MaxSumWordLength', 128);
    %sum_sigma_err = fi(0, 1, 10, 8, fm);
    sum_sigma_err = 0;
end

k1=1/16;
k2=1/8;

I_err=I_osr(2)*(sign(I_osr(3))-sign(I_osr(1)));
Q_err=Q_osr(2)*(sign(Q_osr(3))-sign(Q_osr(1)));

if(abs(I_osr(2))>abs(Q_osr(2)))
    RMS=abs(I_osr(2))+abs(Q_osr(2))/4;
else
    RMS=abs(I_osr(2))/4+abs(Q_osr(2));
end
%	sigma_err(i)=sign(I_err(i))+sign(Q_err(i));
sigma_err=(I_err+Q_err)/RMS;
%sigma_err=(I_err+Q_err);
sum_sigma_err=sigma_err+sum_sigma_err;
control=sigma_err*k1+sum_sigma_err*k2;

if(control>1)
    %sample_delta=OSR-1;
    sample_delta=-1;
    sum_sigma_err=0;
elseif(control<-1)
    %sample_delta=OSR+1;
    sample_delta=1;
    sum_sigma_err=0;
else
    %sample_delta=OSR;
    sample_delta=0;
end

end
