%gen gold 256
use_observer=0;
use_search_gold=0;
if use_observer==1
    %% check sf16
    n16=sf16_i>0;
    figure;plot(sf16_i(40:190));title('sf 16 check');
    hold;plot(80*n16(40:190)-40,'r');
    
    sf16=int2str(n16(40+57:40+57+31));
    
    %% check sf32
    n32=sf32_i>0;
    figure;plot(sf32_i(40:190));title('sf 32 check');
    hold;plot(80*n32(40:190)-40,'r');
    
    sf32=int2str(n32(40+57:40+57+31));
    
    %% check sf64
    n64=sf64_i>0;
    figure;plot(sf64_i(40:290));title('sf 64 check');
    hold;plot(80*n64(40:290)-40,'r');
    sf64=int2str(n64(40+95:40+95+63));
    
    %% check sf64_1
    zero=40;
    base=240;
    sn=base:base+64*6-1;
    check=250;
    n64_1=sf64_1_i>0;
    figure;plot(sf64_1_i(sn));title('sf 64_1 check');grid;
    hold;plot((80*n64_1(sn)-zero)*20,'r');
    sf64_1=int2str(n64_1(check:check+64-1)); %% used for direct copy
    
else
    %%
    m=gold256(365);
    mr=m(end:-1:1);
    mr1=fliplr(m);
    %sf16=[1,0,0,1,0,0,1,0,1,1,1,1,1,1,1,1];;%best correlation
end
%% direct value!

if (use_search_gold)
    max_corx=zeros(1,100);
    max_index=zeros(1,100);
    
    for check=10:80
        sf64_1=n64_1(check:check+64-1);
        bit8_sn=n64_1(check:check+8*64-1);
        [max_corx(check),max_index(check)]=search_gold(sf64_1,bit8_sn);
    end
    [check_max_val,check_max_index]=max(max_corx);
    %get true candidate check_max_val index;
    sf64_1=n64_1(check_max_index:check_max_index+64-1);
    bit8_sn=n64_1(check_max_index:check_max_index+8*64-1);
    %get true gold sn offset
    [bit8_max_val,bit8_max_index]=search_gold(sf64_1,bit8_sn);
else
    sf16  =[1,0,0,1,0,0,1,0,1,1,1,1,1,1,1,1];
    sf32  =[1,0,0,1,0,0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,1,0,1,0,];
    sf64  =[1,0,0,1,0,0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,1,0,1,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,0,1,1,0,1,1,0,1,1,1,1,1,1];
    sf64_1=[0,1,1,1,1,0,1,0,1,0,1,1,0,0,1,1,0,1,1,1,0,1,1,0,1,0,1,0,0,1,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,1,0,1,1,1,0,1,1,1,1,1,0,0,0,1,0,1,1,1];
end
%sf_gold=sf64;
%sf_gold=sf64_1;
%sf_gold=sf64;






