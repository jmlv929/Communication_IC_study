%% PPM Table
function [cos_t,sin_t]=ppm_table_index(index)
% set rotate angle
    sn=0:63;
    ppm=sn*index*0.25;
    fc=ppm*920*1e6*1e-6;
    fs=(200*1e3);
    Ts=1/fs;
    cpx=exp(1j*Ts*fc*2*pi);
    cos_t=real(cpx);
    sin_t=imag(cpx);
end
