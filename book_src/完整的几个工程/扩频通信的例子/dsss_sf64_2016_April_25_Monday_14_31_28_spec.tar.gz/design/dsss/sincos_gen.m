len=32
bit=11
for sn=1:len;
    cos_i(sn)=cos(pi/2*sn/len);
    sin_i(sn)=sin(pi/2*sn/len);
end
    cos_d=fix(cos_i*2^(bit-1));
    sin_d=fix(sin_i*2^(bit-1));

fid=fopen('sincos_table.txt','wt');
fprintf(fid,'%d %d \n',[sin_d;cos_d]);
fclose(fid);

    plot(cos_d);
