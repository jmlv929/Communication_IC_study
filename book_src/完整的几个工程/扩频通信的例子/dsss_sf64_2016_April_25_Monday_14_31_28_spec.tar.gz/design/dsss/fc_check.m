clear;
clc;

load acc_neg
load acc_pos
load agc_I
load agc_Q
load bit256_AGC_I
load bit256_AGC_Q
load bit_Icos_add_Qsin
load bit_Icos_sub_Qsin
load bit_Isin_add_Qcos
load bit_Isin_sub_Qcos
load gold_sn
load inc_ppm
load init_ppm_cnt
load I_chip_fc_in
load Q_chip_fc_in
load resample_I
load resample_Q

sf_factor=32;
len=length(agc_I);
dim=floor(len/sf_factor);
agc_I_out = agc_I(1:dim*sf_factor);
agc_Q_out = agc_Q(1:dim*sf_factor);
agc_I_in  = resample_I(1:dim*sf_factor);
agc_Q_in  = resample_Q(1:dim*sf_factor);
agc_I_out_view = reshape(agc_I_out',sf_factor,dim);
agc_Q_out_view = reshape(agc_Q_out',sf_factor,dim);
agc_I_in_view  = reshape(agc_I_in' ,sf_factor,dim);
agc_Q_in_view  = reshape(agc_Q_in' ,sf_factor,dim);   

gold_bit =2*gold_sn(1:sf_factor)-1;
gold_bit8=repmat(gold_bit,8);

base_index=1;
search_ok=0;
while(search_ok)
  fc_I=agc_I_out(base_index:base_index*sf*8);
  fc_Q=agc_Q_out(base_index:base_index*sf*8);

  for ppm_cnt=1:40
    delta=301;
    delta_ang=ppm_cnt*(detla/2^16)*2*pi;
    
    fc_angle=delta_ang*(1:sf*8);
    
    rot_bit_acc_pos=(fc_I+fc_Q*1j).*exp(fc_angle);
    rot_bit_acc_neg=(fc_I+fc_Q*1j).*exp(-fc_angle);  
    
    rot_bit_acc_gold_pos=rot_bit_acc_pos.*gold_bit8;
    rot_bit_acc_gold_neg=rot_bit_acc_neg.*gold_bit8;
    
    for i=1:8
      peak_pos(i)=sum(rot_bit_acc_gold_pos((i-1)*sf+1:i*sf));
      peak_neg(i)=sum(rot_bit_acc_gold_neg((i-1)*sf+1:i*sf));
    end
    ture_peak_pos(ppm_cnt)=sum(abs(peak_pos));
    ture_peak_neg(ppm_cnt)=sum(abs(peak_pos));
  
    if(ture_peak_pos(ppm_cnt)>ture_peak_neg(ppm_cnt)
        if (ture_peak_pos(ppm_cnt)>max_peak)
          max_peak=ture_peak_pos(ppm_cnt);
          max_ppm_cnt=ppm_cnt;
        end
    elseif (ture_peak_neg(ppm_cnt)>max_peak)
        max_peak=ture_peak_neg(ppm_cnt);
        max_ppm_cnt=-ppm_cnt;
    end
      
  end
  
    if(max_peak>peak_gate)
      best_pos=base_index;
      pre_ppm=
    end

end 
  
%PLL 

