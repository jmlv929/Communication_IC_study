clear;
clc;
load agc_I
load agc_Q
load resample_I
load resample_Q
len=length(agc_I);
dim=floor(len/32);
agc_I_out = agc_I(1:dim*32);
agc_Q_out = agc_Q(1:dim*32);
agc_I_in  = resample_I(1:dim*32);
agc_Q_in  = resample_Q(1:dim*32);
agc_I_out = reshape(agc_I_out',32,dim);
agc_Q_out = reshape(agc_Q_out',32,dim);
agc_I_in  = reshape(agc_I_in' ,32,dim);
agc_Q_in  = reshape(agc_Q_in' ,32,dim);   

for m=1:dim
  peak(m)=sum(abs(agc_I_in(:,m)))+sum(abs(agc_Q_in(:,m)));
  peak_db(m)=(peak(m)*2.828/32);
  peak_ref(m)=peak(m)*181/32;
  new_I(:,m)=floor(agc_I_in(:,m)/peak_db(m)*2^7);
  new_Q(:,m)=floor(agc_Q_in(:,m)/peak_db(m)*2^7);
  diff_I(:,m)=agc_I_out(:,m)-new_I(:,m);
  diff_Q(:,m)=agc_Q_out(:,m)-new_Q(:,m);
  abs_diff(m)=sum(abs(diff_I(:,m)))+sum(abs(diff_Q(:,m)));
end

load I_chip_fc_in
load Q_chip_fc_in
omit=29
I_chip_fc_in=I_chip_fc_in(omit:end);
Q_chip_fc_in=Q_chip_fc_in(omit:end);
len=length(I_chip_fc_in);
diff_I1=I_chip_fc_in-agc_I(1:len);
diff_Q1=Q_chip_fc_in-agc_Q(1:len);
abs_diff1=sum(abs(diff_I1))+sum(abs(diff_Q1));

err_index=find(diff_I1)
err_index1=err_index+omit

[err_I_max,i_index]=max(abs(diff_I1))
[err_Q_max,q_index]=max(abs(diff_Q1))


