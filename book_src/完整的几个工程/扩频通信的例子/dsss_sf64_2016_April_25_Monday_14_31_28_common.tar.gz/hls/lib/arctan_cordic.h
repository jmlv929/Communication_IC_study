// #include "arctan_cordic.h"
//#pragma once
#ifndef _CORDIC_H
#define _CORDIC_H
#include "ac_int.h"
#include "ac_fixed.h"

typedef ac_fixed<10,2> ANGLE_pi_t;
typedef ac_fixed<10,2> ANGLE_t;
typedef ac_fixed<10,3> DATA_INNER_t;
typedef ac_fixed<10,1> DATA_t;
#define ANGLES_LENGTH 60

ANGLE_t arctan_cordic ( DATA_t x, DATA_t y, int n );
ANGLE_pi_t arctan_cordic_pi( DATA_t x, DATA_t y, int n );
ANGLE_pi_t arctan_cordic_pi10( DATA_t x, DATA_t y);
extern ANGLE_t angles[ANGLES_LENGTH];
extern ANGLE_pi_t angles_pi[ANGLES_LENGTH];

#endif