ANGLES = atan((1/2).^[0:59]')
ANGLES_pi = atan((1/2).^[0:59]')/(pi/2)
save -ascii ang_pi.txt ANGLES_pi

