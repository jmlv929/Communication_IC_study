#include "arctan_cordic.h"
#include <math.h> // for testing only!
#include "cordic.h"

//Print out sin(x) vs fp CORDIC sin(x)
int main(int argc, char **argv)
{
	ANGLE_t result;
	ANGLE_pi_t result_pi;
	double check1,check2,x,y;
	DATA_t x1,y1;
	int i;
	int max=200;
	for(i=-max;i<max;i++)
	{
		x = 1.0*i/max;        
		y=0.95;
		x1=x;
		y1=y;
		check1=atan(y/x);
		check2=arctan_cordic (x,y,16);
		result_pi=arctan_cordic_pi10 (x1,y1);
		
		//these values should be nearly equal *(3.1415926/2)
		printf("index %d,atan(%f)=:%f,ref=%f ref_cordic=%f\n",i,(y/x),result_pi.to_double()*(3.1415926/2),check1,check2);
	}       
}
