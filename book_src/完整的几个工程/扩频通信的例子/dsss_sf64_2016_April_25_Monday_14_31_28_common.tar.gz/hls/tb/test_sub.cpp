#include "fc_core_new.h"
#include "matlab_engine.h"

#include "gold_sn.h"
#include "dsss_tx.h"
#include "agc.h"
#include "channel.h"

//#define _DEBUG_AGC 1
//#define _DEBUG_tx 1
//#define _DEBUG_MATLAB
//#define _DEBUG_rx 1

#ifdef _DEBUG_MATLAB
Engine *ep;
#endif

//#define MAX_TX_BUFF_LEN 16*256 //(32 * 8 * 256 + 32 * 256)
//#define MAX_TX_BIT_LEN 32
int main(int argc, char *argv[])
{
	int i;
	
	#ifdef _DEBUG_MATLAB 
//	Engine *ep=MyEngineInit();
    ep=MyEngineInit();
	#endif

	int psdu_seed = 0x1FFF000; //use excel
	int shr_seed = 0x1FFF000;
	int MAX_PEAK=16*8/2;

	AGC_t *AGC_I;
	AGC_t *AGC_Q;
	bool psdu_gold_sn[256];
	bool shr_gold_sn[256];
	SF_t psdu_sf;
	SF_t shr_sf;
	bool decode_bit;
	ABS_ACC_SUM_SIN_t max_acc;
	ANGLE_t max_ppm;
	bool neg_or_pos;
	PPM_INDEX_t max_index;
	int max_len;
	int dsss_tx_len;
	bool synch_stage;
	TX_t *tx_I,*tx_Q;
	IQ_t *tx_I_out,*tx_Q_out;
	bool *tx_bit;

	int shr_len, psdu_len,chip_len;
	shr_len = 24;
	shr_sf = 0;
	psdu_len = 32 * 8;
	psdu_sf = 0;
	chip_len=shr_len*sf_len(shr_sf)+psdu_len*sf_len(psdu_sf);

	tx_bit=new bool[shr_len+psdu_len];
	tx_I=new TX_t[chip_len];
	tx_Q=new TX_t[chip_len];
	tx_I_out=new IQ_t[chip_len];
	tx_Q_out=new IQ_t[chip_len];
	AGC_I=new AGC_t[chip_len];
	AGC_Q=new AGC_t[chip_len];
	
	//srand(time(0));    //��timeΪ��������������ӣ��Ա���������ظ�
	//a=rand()%2;        //aΪ���������2ȡ�࣬��Ϊ0��1

	for(i=0;i<shr_len+psdu_len;i++)tx_bit[i]=rand()%2;
	// // test file data read
	// MyFileGet("tx_bit",tx_bit,shr_len+psdu_len);
	// // end file data read
	gold_sn(psdu_seed, psdu_gold_sn);
	gold_sn(shr_seed, shr_gold_sn);

#ifdef _DEBUG_tx 
	MyACPut(ep,"tx_bit",tx_bit,shr_len+psdu_len);
	MyACPut(ep,"shr_gold_sn",shr_gold_sn,256);
	MyACPut(ep,"psdu_gold_sn",psdu_gold_sn,256);
#endif

	//tx_core(bool tx_bit[32*8+32],int shr_len,int psdu_len,bool psdu_gold_sn[256], bool shr_gold_sn[256], SF_t psdu_sf, SF_t shr_sf,TX_t tx_I[32*8*256+32*256],TX_t tx_Q[32*8*256+32*256],int &dsss_tx_len)
	// every sf*16 to check psdu or bit
	tx_core(tx_bit, shr_len, psdu_len, psdu_gold_sn, shr_gold_sn, psdu_sf, shr_sf, tx_I, tx_Q, dsss_tx_len);
	
#ifdef _DEBUG_tx 
	MyACPut(ep,"tx_I",tx_I,chip_len);
	MyACPut(ep,"tx_Q",tx_Q,chip_len);
#endif

	channel(tx_I, tx_Q, tx_I_out, tx_Q_out, 10, 0, 0, chip_len, 1);
#ifdef _DEBUG_tx 
	MyACPut(ep,"tx_I_out",tx_I_out,chip_len);
	MyACPut(ep,"tx_Q_out",tx_Q_out,chip_len);
#endif

#ifdef _DEBUG 
	MyFilePut("tx_I_out",tx_I_out,chip_len);
	MyFilePut("tx_Q_out",tx_Q_out,chip_len);
	MyFilePut("tx_bit",tx_bit,shr_len+psdu_len);
	MyFilePut("shr_gold_sn",shr_gold_sn,256);
	MyFilePut("psdu_gold_sn",psdu_gold_sn,256);
#endif

	for(i = 0; i < chip_len / 16; i++) // every 16 chips use same agc factor
	{
		agc(&tx_I_out[i * 16], &tx_Q_out[i * 16], &AGC_I[i * 16], &AGC_Q[i * 16]);
	}
#ifdef _DEBUG 
	MyFilePut("tx_I_out",tx_I_out,chip_len);
	MyFilePut("tx_Q_out",tx_Q_out,chip_len);
	MyFilePut("tx_bit",tx_bit,shr_len+psdu_len);
	MyFilePut("shr_gold_sn",shr_gold_sn,256);
	MyFilePut("psdu_gold_sn",psdu_gold_sn,256);
	MyFilePut("AGC_I",AGC_I,chip_len);
	MyFilePut("AGC_Q",AGC_Q,chip_len);
#endif

#ifdef _DEBUG_AGC 
	MyACPut(ep,"AGC_I",AGC_I,chip_len);
	MyACPut(ep,"AGC_Q",AGC_Q,chip_len);
#endif
	//MyFileGet("AGC_I",AGC_I,chip_len);
	//MyFileGet("AGC_Q",AGC_Q,chip_len);
	//MyFileGet("psdu_gold_sn",psdu_gold_sn,256);
	//MyFileGet("shr_gold_sn",shr_gold_sn,256);

	bool psdu_or_shr=false;
	synch_stage = 0;
	double * temp_acc;
	temp_acc=new double[chip_len];
	for(i = 0; i < (chip_len-FULL_CHIP_NUM); i++)
	{
#ifdef _DEBUG
		printf("\nnow advance to chip %d\n",i);
#endif
		fc_top(psdu_or_shr,synch_stage,&AGC_I[i],&AGC_Q[i], psdu_gold_sn, shr_gold_sn, psdu_sf, shr_sf, decode_bit, max_acc, max_ppm, neg_or_pos, max_index);

		if(max_acc>MAX_PEAK)
			synch_stage=1;
		temp_acc[i]=max_acc.to_double();
	}

	delete[] tx_I;
	delete[] tx_Q;
	delete[] tx_I_out;
	delete[] tx_Q_out;
	delete[] AGC_I;
	delete[] AGC_Q;
    return 0;
}

