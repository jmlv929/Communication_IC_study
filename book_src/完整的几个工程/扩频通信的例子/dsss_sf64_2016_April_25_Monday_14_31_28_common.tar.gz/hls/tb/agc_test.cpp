#include"agc.h"
int main(int argc, char *argv[])
{
    IQ_t I_in[16] = {	0.9355, 0.9169, 0.4103, 0.8936, 0.0579, 0.3529, 0.8132,	0.0099, 0.1389, 0.2028, 0.1987, 0.6038, 0.2722, 0.1988,	0.0153, 0.7468	};
    IQ_t Q_in[16] = {	0.4451, 0.9318, 0.4660, 0.4186, 0.8462, 0.5252, 0.2026, 0.6721, 0.8381, 0.0196, 0.6813, 0.3795, 0.8318, 0.5028, 0.7095, 0.4289	};

    AGC_t I_out[16];
    AGC_t Q_out[16];

    agc(I_in, Q_in, I_out, Q_out);
    int i;
    for(i = 0; i < 16; i++)
    {
        //		cout<<"I_out[i]="<<I_out[i]<<endl;
        //		cout<<"Q_out[i]="<<Q_out[i]<<endl;
        printf("I_out[%d]=%f\n", i, I_out[i].to_double());
        printf("Q_out[%d]=%f\n", i, Q_out[i].to_double());
    }

    return 0;
}

