#include "fc_core_new.h"
#include "gold_sn.h"
#include "dsss_tx.h"
#include "agc.h"
#include "channel.h"
//#include "matlab_engine.h"

//extern "C"
//{
//#include <my++/myhead.h>
//}

int main(int argc, char *argv[])
{
    //AGC_t I_in[16] = { 0.9355, 0.9169, 0.4103, 0.8936, 0.0579, 0.3529, 0.8132, 0.0099, 0.1389, 0.2028, 0.1987, 0.6038, 0.2722, 0.1988, 0.0153, 0.7468 };
    //AGC_t Q_in[16] = { 0.4451, 0.9318, 0.4660, 0.4186, 0.8462, 0.5252, 0.2026, 0.6721, 0.8381, 0.0196, 0.6813, 0.3795, 0.8318, 0.5028, 0.7095, 0.4289 };

 //   test_matlab();
    int i;
    int psdu_seed = 0x0ffccdd;
    int shr_seed = 0x1eebbaa;
  	int MAX_PEAK=16*8/2;

    AGC_t AGC_I[FULL_CHIP_NUM];
    AGC_t AGC_Q[FULL_CHIP_NUM];
    bool psdu_gold_sn[256];
    bool shr_gold_sn[256];
    SF_t psdu_sf;
    SF_t shr_sf;
    bool decode_bit;
    ABS_ACC_SUM_SIN_t max_acc;
    ANGLE_t max_ppm;
    bool neg_or_pos;
    PPM_INDEX_t max_index;
    int max_len;
    int dsss_tx_len;
    bool synch_stage;
    TX_t tx_I[32 * 8 * 256 + 32 * 256];
    TX_t tx_Q[32 * 8 * 256 + 32 * 256];

    IQ_t tx_I_out[32 * 8 * 256 + 32 * 256];
    IQ_t tx_Q_out[32 * 8 * 256 + 32 * 256];

    bool tx_bit[32 * 8 + 32];

    int shr_len, psdu_len;
    shr_len = 24;
    shr_sf = 4;
    psdu_len = 32 * 8;
    psdu_sf = 2;

    for(i = 0; i < 32 * 8 + 32; i++)
    {
        tx_bit[i] = 0; //randominteger (0,1);
    }
    for(i = 0; i < (32 * 8 * 256 + 32 * 256); i++)
    {
        tx_I[i] = 0;
        tx_Q[i] = 0;
    }

    gold_sn(psdu_seed, psdu_gold_sn);
    gold_sn(shr_seed, shr_gold_sn);

    max_len = (32 * 8 * 256 + 32 * 256);

    //tx_core(bool tx_bit[32*8+32],int shr_len,int psdu_len,bool psdu_gold_sn[256], bool shr_gold_sn[256], SF_t psdu_sf, SF_t shr_sf,TX_t tx_I[32*8*256+32*256],TX_t tx_Q[32*8*256+32*256],int &dsss_tx_len)
    tx_core(tx_bit, shr_len, psdu_len, psdu_gold_sn, shr_gold_sn, psdu_sf, shr_sf, tx_I, tx_Q, dsss_tx_len);
	
    channel(tx_I, tx_Q, tx_I_out, tx_Q_out, 10, 0, 0, max_len, 1);

    for(i = 0; i < max_len / 16; i++) // every 16 chips use same agc factor
    {
        agc(&tx_I_out[i * 16], &tx_Q_out[i * 16], &AGC_I[i * 16], &AGC_Q[i * 16]);
    }

    synch_stage = 0;
    for(i = 0; i < max_len; i++)
    {
        fc_top(synch_stage,&AGC_I[i],&AGC_Q[i], psdu_gold_sn, shr_gold_sn, psdu_sf, shr_sf, decode_bit, max_acc, max_ppm, neg_or_pos, max_index);
    		if(max_acc>MAX_PEAK)
    			synch_stage=1;
    }

    return 0;
}

