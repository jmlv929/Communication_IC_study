#ifndef _MATLAB_ENGINE_
#define _MATLAB_ENGINE_

#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

//#define _DEBUG_MATLAB 1 // internal variable will dump in matlab
//#undef  _DEBUG_MATLAB
#define _DEBUG_FILE 1 // internal variable will dump in text file
//#undef  _DEBUG_FILE  

#ifdef _DEBUG_MATLAB

#include"engine.h"
#pragma comment(lib, "libeng.lib")
#pragma comment(lib, "libmx.lib")
#pragma comment(lib, "libmat.lib")

extern Engine *ep;

Engine * MyEngineInit();
void MyEngClose(Engine *ep);

void MyEngPut(Engine *ep,char* Name,double *var,int len,int base_addr=0);
void MyEngGet(Engine *ep,char* Name,double *var,int len);

template<typename T>
void MyACPut(Engine *ep,char *Name,T *var,int len,int base_addr=0){
	int i;
	int size=len;
	double *ptr=new double[size];
	for (i=0;i<size;i++)
	{
		ptr[i]=var[i].to_double();
	}
	MyEngPut(ep, Name, ptr,len,base_addr);

#ifdef _DEBUG_FILE
	MyFilePut(Name,var,len,base_addr);
#endif

	delete [] ptr;
}

template<typename T>
void MyACGet(Engine *ep,char *Name,T *var,int len){
	int i;
	int size=len;
	double *ptr;
	MyEngGet(ep, Name, ptr,len);
	for (i=0;i<size;i++)
	{
		var[i]=ptr[i];
	}
}

template<> void MyACGet(Engine *ep,char *Name,bool *var,int len);
template<> void MyACGet(Engine *ep,char *Name,int *var,int len);
template<>void MyACPut(Engine *ep,char *Name,bool *var,int len,int base_addr);
template<>void MyACPut(Engine *ep,char *Name,int *var,int len,int base_add);

void test_matlab();
#endif

#ifdef _DEBUG_FILE
void MyFileGet(char *Name,double *var,int len);
//template<typename T> void MyACPut(Engine *ep,char *Name,T *var,int len);
//template<typename T> void MyACGet(Engine *ep,char *Name,T *var,int len);
// should combine with h
// otherwise will generate 2019 link error!

template<typename T>
void MyFilePut(char *Name,T *var,int len,int base_addr=0)
{
	int i;
	FILE *fp;
	fp=fopen(Name,"a+");
	if(fp==NULL){printf("error in open debug file: %s",Name);return;}

	for(i=0;i<len;i++)
	fprintf(fp,"%s [%d] \t =\t %f\n",Name,base_addr+i,(var[i]).to_double());
	fclose(fp);

	char NewName[80];
	sprintf_s(NewName,"fixed_%s",Name);
	fp=fopen(NewName,"a+");
	if(fp==NULL){printf("error in open fixed debug file: %s",NewName);return;}

	for(i=0;i<len;i++)
		fprintf(fp,"%s [%d] \t =\t %d\n",Name,base_addr+i,(var[i].slc<T::width>(0)));
	fclose(fp);

	sprintf_s(NewName,"%s.dat",Name);
	fp=fopen(NewName,"a+");
	if(fp==NULL){printf("error in open verilog debug file: %s",NewName);return;}

	for(i=0;i<len;i++)
		fprintf(fp,"%d\n",(var[i].slc<T::width>(0)));
	fclose(fp);
}

// template<typename T>
// void MyFilePut(char *Name,T *var,int len)
// {
// 	FILE *fp;
// 	fp=fopen(Name,"a+");
// 	if(fp==NULL){printf("error in open debug file: %s",Name);return;}
// 	int i;
// 	for(i=0;i<len;i++)
// 	fprintf(fp,"%s [%d] \t =\t %d\n",Name,i,(var[i]).to_double());
// 	fclose(fp);
// }
// template<>void MyFilePut(char *Name,double *var,int len);
// template<>void MyFilePut(char *Name,int *var,int len);
// template<>void MyFilePut(char *Name,bool *var,int len);

template<>void MyFilePut(char *Name,double *var,int len,int base_addr);
template<>void MyFilePut(char *Name,int *var,int len,int base_addr);
template<>void MyFilePut(char *Name,bool *var,int len,int base_addr);
// special instance for bool & double

template<typename T>
void MyFileGet(char *Name,T *var,int len)
{
	int i,n;
	char *p,*pName,*a,*b,*c;
	double rdData;
	int buf_len=256;

	FILE *fp;
	fp=fopen(Name,"r");
	if(fp==NULL){printf("error in open debug file: %s",Name);return;}

	p=new char[buf_len];
	pName=new char[buf_len];
	a=new char[buf_len];
	b=new char[buf_len];
	c=new char[buf_len];
	//rdData=new double[len];
	for(i=0;i<len;i++){ // tx_bit [28] 	 =	 0.000000 // \\s+[[1-9]*\\]\\s+=\\s+
		if(fgets(p,buf_len,fp)==NULL)break;
		sscanf(p,"%s%s%s%s",pName,a,b,c);
		rdData=atof(c);

		var[i]=rdData;
	}
	delete []p;
	delete []pName;
	delete []a;
	delete []b;
	delete []c;

	fclose(fp);
}
//template<>void MyACPut(Engine *ep,char *Name,bool *var,int len);
//template<>void MyACPut(Engine *ep,char *Name,int *var,int len);






#endif

#endif
