#pragma once 
#ifndef _MATLAB_TEMPLATE_
#define _MATLAB_TEMPLATE_

#include"matlab_engine.h"

//template<typename T> void MyACPut(Engine *ep,char *Name,T *var,int len);
//template<typename T> void MyACGet(Engine *ep,char *Name,T *var,int len);

// should combine with h
// otherwise will generate 2019 link error!

template<typename T>
void MyACPut(Engine *ep,char *Name,T *var,int len,int base_addr=0){
	int i;
	int size=len;
	double *ptr=new double[size];
	for (i=0;i<size;i++)
	{
		ptr[i]=var[i].to_double();
	}
	#ifdef _DEBUG_MATLAB
	MyEngPut(ep, Name, ptr,len,base_addr);
	#endif

	#ifdef _DEBUG_FILE
	MyFilePut(Name,var,len,base_addr);
	#endif

	delete [] ptr;
}

template<typename T>
void MyACGet(Engine *ep,char *Name,T *var,int len){
	int i;
	int size=len;
	double *ptr;
	MyEngGet(ep, Name, ptr,len);
	for (i=0;i<size;i++)
	{
		var[i]=ptr[i];
	}
}

template<typename T>
void MyFilePut(char *Name,T *var,int len,int base_addr)
{
	FILE *fp;
	fp=fopen(Name,"a+");
	if(fp==NULL){printf("error in open debug file: %s",Name);return;}
	int i;
	for(i=0;i<len;i++)
	fprintf(fp,"%s [%d] \t =\t %d\n",Name,base_addr+i,(var[i]).to_double());
	fclose(fp);
}

//template<typename T>
//void MyFilePut(char *Name,T *var,int len)
//{
//	FILE *fp;
//	fp=fopen(Name,"a+");
//	if(fp==NULL){printf("error in open debug file: %s",Name);return;}
//	int i;
//	for(i=0;i<len;i++)
//	fprintf(fp,"%s [%d] \t =\t %d\n",Name,i,(var[i]).to_double());
//	fclose(fp);
//}

template<typename T>
void MyFileGet(char *Name,T *var,int len)
{
	int i,n;
	char *p,*pName,*a,*b,*c;
	double rdData;
	int buf_len=256;

	FILE *fp;
	fp=fopen(Name,"r");
	if(fp==NULL){printf("error in open debug file: %s",Name);return;}

	p=new char[buf_len];
	pName=new char[buf_len];
	a=new char[buf_len];
	b=new char[buf_len];
	c=new char[buf_len];
	//rdData=new double[len];
	for(i=0;i<len;i++){ // tx_bit [28] 	 =	 0.000000 // \\s+[[1-9]*\\]\\s+=\\s+
		fgets(p,buf_len,fp);
		sscanf(p,"%s%s%s%s",pName,a,b,c);
		rdData=atof(c);

		var[i]=rdData;
	}
	delete []p;
	delete []pName;
	delete []a;
    delete []b;
    delete []c;

	fclose(fp);
}
// special instance for bool & double
template<> void MyACGet(Engine *ep,char *Name,bool *var,int len);
template<> void MyACGet(Engine *ep,char *Name,int *var,int len);

template<>void MyFilePut(char *Name,double *var,int len,int base_addr);
template<>void MyFilePut(char *Name,int *var,int len,int base_addr);
template<>void MyFilePut(char *Name,bool *var,int len,int base_addr);
template<>void MyACPut(Engine *ep,char *Name,bool *var,int len,int base_addr);
template<>void MyACPut(Engine *ep,char *Name,int *var,int len,int base_add);

//template<>void MyFilePut(char *Name,double *var,int len);
//template<>void MyFilePut(char *Name,int *var,int len);
//template<>void MyFilePut(char *Name,bool *var,int len);
//template<>void MyACPut(Engine *ep,char *Name,bool *var,int len);
//template<>void MyACPut(Engine *ep,char *Name,int *var,int len);

#endif
