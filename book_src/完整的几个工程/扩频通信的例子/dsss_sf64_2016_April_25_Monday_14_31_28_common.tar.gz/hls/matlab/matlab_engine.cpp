#include "matlab_engine.h"

#ifdef _DEBUG_MATLAB

const int BUFFER_SIZE = 1024;
char buffer[BUFFER_SIZE+1];

Engine * MyEngineInit()
{
	Engine *ep;
	buffer[BUFFER_SIZE] = '\0'; //last byte is always NULL
	if ((ep = engOpen("")) == NULL)
	{
		printf("Engine Fail");
		exit(-1);
	}
	int nStatus=engOutputBuffer(ep, buffer, BUFFER_SIZE);
	printf("Matlab engine Init Success!\n");
	nStatus = engSetVisible(ep, true);
	if(nStatus != 0)
	{
		printf(" MATLAB������ʾ����ʧ��!\n");
		exit(-2);
	}
	return ep;
}

void MyEngClose(Engine *ep)
{
	engClose(ep);
}

void MyEngPut(Engine *ep,char *Name,double *var,int len,int base_addr)
{
	mxArray *Mat_var = NULL;
	Mat_var = mxCreateDoubleMatrix(1, len, mxREAL);
	memcpy((void *)mxGetPr(Mat_var), (void *)var, len*sizeof(var));

#if _DEBUG  
	int Input_num = mxGetNumberOfElements(Mat_var);
	if (Input_num != len){
		printf("Argument number must reach the array elements!");
		exit(-1);
	}
#endif
	int nStatus=engPutVariable(ep, Name, Mat_var);
	// ? here is something need check
	mxDestroyArray(Mat_var);
}

void MyEngGet(Engine *ep,char *Name,double *var,int len)
{
	mxArray  *d = NULL;
	double *Dreal, *Dimag;
	int mrows,ncols;

	d = engGetVariable(ep, Name);

	if (d == NULL) {
		printf("Can't get the array elements!");
		exit(-2);
	}
	else {		
		Dreal = mxGetPr(d);
		Dimag = mxGetPi(d); // image part      		
		mrows = mxGetM(d);  
		ncols = mxGetN(d);

#if _DEBUG  

		if (Dimag)
			sprintf_s(buffer,"First Complex Data is : %g+%gi",Dreal[0],Dimag[0]);
		else
			sprintf_s(buffer,"First Double Data is: %g\n",Dreal[0]);
		printf ("%s",buffer);

		if(len!=(mrows*ncols)){
			printf("output array elements number is not equal with len!");
			exit(-3);
		}

#endif
		int m,n;
		for(m=0;m<mrows;m++){
			for(n=0;n<ncols;n++){
				var[m*ncols+n]=Dreal[n*mrows+m];
#ifdef _DEBUG
				printf("%4.3f\n  ",Dreal[n*mrows+m]);
#endif
			}
		}
	} 
}	


template<>
void MyACPut(Engine *ep,char *Name,bool *var,int len,int base_addr=0){
	int i;
	int size=len;
	double *ptr=new double[size];
	for (i=0;i<size;i++)
	{
		ptr[i]=var[i];
	}
#ifdef _DEBUG_MATLAB
	MyEngPut(ep, Name, ptr,len,base_addr);
#endif

#ifdef _DEBUG_FILE
	MyFilePut(Name,var,len,base_addr);
#endif

	delete [] ptr;
}

template<>
void MyACGet(Engine *ep,char *Name,bool *var,int len){
	int i;
	int size=len;
	double *ptr;
	MyEngGet(ep, Name, ptr,len);
	for (i=0;i<size;i++)
	{
		if(ptr[i]>-1e-30&&ptr[i]<1e-30)
			var[i]=false;
		else
			var[i]=true;
	}

}

template<>
void MyACPut(Engine *ep,char *Name,int *var,int len,int base_addr=0){
	int i;
	int size=len;
	double *ptr=new double[size];
	for (i=0;i<size;i++)
	{
		ptr[i]=var[i];
	}

#ifdef _DEBUG_MATLAB
	MyEngPut(ep, Name, ptr,len,base_addr);
#endif

#ifdef _DEBUG_FILE
	MyFilePut(Name,var,len,base_addr);
#endif

	delete [] ptr;
}

template<>
void MyACGet(Engine *ep,char *Name,int *var,int len){
	int i;
	int size=len;
	double *ptr;
	MyEngGet(ep, Name, ptr,len);
	for (i=0;i<size;i++)
	{
		var[i]=int(ptr[i]);
	}
}

void test_matlab()
{
	Engine *ep=MyEngineInit();

	double x[5] = { 1.0, 2.5, 3.7, 4.4, 5.1 };
	double y[5] = { 3.3, 4.7, 9.6, 15.6, 21.3 };

	MyEngPut(ep, "x", x,5);
	MyEngPut(ep, "y", y,5);

	double d[5];
	engEvalString(ep, "plot(x,y)");
	engEvalString(ep, "d=x.*y");
	MyEngGet(ep, "d", d,5);

	MyEngClose(ep);
}
#endif

#ifdef _DEBUG_FILE

template<>
void MyFilePut(char *Name,double *var,int len,int base_addr=0)
{
	int i;
	FILE *fp;

	fp=fopen(Name,"a+");
	if(fp==NULL){printf("error in open debug file: %s",Name);return;}

	for(i=0;i<len;i++)
		fprintf(fp,"%s [%d] \t =\t %f\n",Name,i+base_addr,var[i]);
	fclose(fp);
	
	char NewName[80];
	sprintf_s(NewName,"fixed_%s",Name);
	fp=fopen(NewName,"a+");
	if(fp==NULL){printf("error in open fixed debug file: %s",NewName);return;}
 
	for(i=0;i<len;i++)
		fprintf(fp,"%s [%d] \t =\t %d\n",Name,i+base_addr,int(var[i]));
	fclose(fp);

	sprintf_s(NewName,"%s.dat",Name);
	fp=fopen(NewName,"a+");
	if(fp==NULL){printf("error in open verilog debug file: %s",NewName);return;}

	for(i=0;i<len;i++)
		fprintf(fp,"%d\n",int(var[i]));
	fclose(fp);

}

template<>
void MyFilePut(char *Name,int *var,int len,int base_addr=0)
{
	FILE *fp;
	fp=fopen(Name,"a+");
	if(fp==NULL){printf("error in open debug file: %s",Name);return;}
	int i;
	for(i=0;i<len;i++)
		fprintf(fp,"%s [%d] \t =\t %d\n",Name,i+base_addr,var[i]);
	fclose(fp);

	char NewName[80];
	sprintf_s(NewName,"%s.dat",Name);
	fp=fopen(NewName,"a+");
	if(fp==NULL){printf("error in open verilog debug file: %s",NewName);return;}

	for(i=0;i<len;i++)
		fprintf(fp,"%d\n",var[i]);
	fclose(fp);


}

template<>
void MyFilePut(char *Name,bool *var,int len,int base_addr=0)
{
	FILE *fp;
	fp=fopen(Name,"a+");
	if(fp==NULL){printf("error in open debug file: %s",Name);return;}
	int i;
	for(i=0;i<len;i++)
		fprintf(fp,"%s [%d] \t =\t %d\n",Name,i+base_addr,var[i]);
	fclose(fp);

	char NewName[80];
	sprintf_s(NewName,"%s.dat",Name);
	fp=fopen(NewName,"a+");
	if(fp==NULL){printf("error in open verilog debug file: %s",NewName);return;}

	for(i=0;i<len;i++)
		fprintf(fp,"%d\n",var[i]);
	fclose(fp);

}

#endif

#if 0
void main(void){
	test_matlab();
}
#endif

