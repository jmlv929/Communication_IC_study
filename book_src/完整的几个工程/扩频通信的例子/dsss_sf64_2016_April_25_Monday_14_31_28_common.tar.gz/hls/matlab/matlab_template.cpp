#include "matlab_engine.h"
#include "matlab_template.h"
// should combine with h
// otherwise will generate 2019 link error!

template<>
void MyACPut(Engine *ep,char *Name,bool *var,int len,int base_addr=0){
	int i;
	int size=len;
	double *ptr=new double[size];
	for (i=0;i<size;i++)
	{
		ptr[i]=var[i];
	}
	#ifdef _DEBUG_MATLAB
	MyEngPut(ep, Name, ptr,len,base_addr);
	#endif

	#ifdef _DEBUG_FILE
	MyFilePut(Name,var,len,base_addr);
	#endif
	
	delete [] ptr;
}

template<>
void MyACGet(Engine *ep,char *Name,bool *var,int len){
	int i;
	int size=len;
	double *ptr;
	MyEngGet(ep, Name, ptr,len);
	for (i=0;i<size;i++)
	{
		if(ptr[i]>-1e-30&&ptr[i]<1e-30)
			var[i]=false;
		else
			var[i]=true;
	}

}

template<>
void MyACPut(Engine *ep,char *Name,int *var,int len,int base_addr=0){
	int i;
	int size=len;
	double *ptr=new double[size];
	for (i=0;i<size;i++)
	{
		ptr[i]=var[i];
	}

	#ifdef _DEBUG_MATLAB
	MyEngPut(ep, Name, ptr,len,base_addr);
	#endif

	#ifdef _DEBUG_FILE
	MyFilePut(Name,var,len,base_addr);
	#endif

	delete [] ptr;
}

template<>
void MyACGet(Engine *ep,char *Name,int *var,int len){
	int i;
	int size=len;
	double *ptr;
	MyEngGet(ep, Name, ptr,len);
	for (i=0;i<size;i++)
	{
		var[i]=int(ptr[i]);
	}
}

template<>
void MyFilePut(char *Name,double *var,int len,int base_addr=0)
{
	FILE *fp;
	fp=fopen(Name,"a+");
	if(fp==NULL){printf("error in open debug file: %s",Name);return;}
	int i;
	for(i=0;i<len;i++)
	fprintf(fp,"%s [%d] \t =\t %f\n",Name,i+base_addr,var[i]);
	fclose(fp);
}

template<>
void MyFilePut(char *Name,int *var,int len,int base_addr=0)
{
	FILE *fp;
	fp=fopen(Name,"a+");
	if(fp==NULL){printf("error in open debug file: %s",Name);return;}
	int i;
	for(i=0;i<len;i++)
	fprintf(fp,"%s [%d] \t =\t %d\n",Name,i+base_addr,var[i]);
	fclose(fp);
}

template<>
void MyFilePut(char *Name,bool *var,int len,int base_addr=0)
{
	FILE *fp;
	fp=fopen(Name,"a+");
	if(fp==NULL){printf("error in open debug file: %s",Name);return;}
	int i;
	for(i=0;i<len;i++)
	fprintf(fp,"%s [%d] \t =\t %d\n",Name,i+base_addr,var[i]);
	fclose(fp);
}
