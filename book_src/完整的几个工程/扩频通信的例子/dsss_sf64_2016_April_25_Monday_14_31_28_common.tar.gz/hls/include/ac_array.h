////////////////////////////////////////////////////////////////////////////////
// Catapult Synthesis
//
// Copyright (c) 2003-2011 Calypto Design Systems, Inc.
//       All Rights Reserved
// 
////////////////////////////////////////////////////////////////////////////////

#ifndef AC_ARRAY_H
#define AC_ARRAY_H

#include <ac_assert.h>

////////////////////////////////////////////////////////////////////////////////
//  Type:         ac_array
//  Description:  Container class for multi-dimensional arrays, simplifies copy
////////////////////////////////////////////////////////////////////////////////

template <typename T, unsigned D>
class ac_array_b
{
public:
    T d[D]; // data

public:

    typedef T ElemType;

    ac_array_b() {}
    ~ac_array_b() {}

    T &operator [] (unsigned i) {
        assert(i < D);
        return d[i];
    }
    const T &operator [] (unsigned i) const {
        assert(i < D);
        return d[i];
    }

    unsigned size() const { return D; }

    template <typename Te>
    void set(const Te &ival) {
        for ( unsigned i = 0; i < D; ++i )
            set(i, ival);
    }

    void clear(bool dc=false) {
        for ( unsigned i = 0; i < D; ++i )
            clear(i, dc);
    }

    template <typename Te>
    void set(unsigned idx, const Te &ival) {
        d[idx].set(ival);
    }
    void clear(unsigned idx, bool dc=false) {
        d[idx].clear(dc);
    }

};


template <typename T, unsigned D1, unsigned D2=0, unsigned D3=0>
class ac_array : public ac_array_b< ac_array<T,D2,D3>, D1>
{
public:
    ac_array() {}
    ac_array(const T &ival) { set(ival); }
    ~ac_array() {}
};

template <typename T, unsigned D1>
class ac_array<T,D1,0,0> : public ac_array_b<T,D1>
{
    typedef ac_array_b<T,D1> Base;
public:
    ac_array() {}
    ac_array(const T &ival) { set(ival); }
    ~ac_array() {}

    template <typename Te>
    void set(unsigned idx, const Te &ival) {
        Base::d[idx] = ival;
    }
    void clear(unsigned idx, bool dc=false) {
        Base::d[idx] = 0; // dc;
    }
};

#endif // AC_ARRAY_H
