# convert .hex file to .mif format
my $hex_name = $ARGV[0];
my $mif_name = $ARGV[1];

#$hex_name = "./test.hex";
#$mif_name = "./test.mif";
$hex_tmp_name = "./tmp.hex";

open(HEX_FILE,"$hex_name") or die "Can not open file $hex_name";
open(HEX_TMP_FILE,">$hex_tmp_name") or die "Can not open file $hex_tmp_name";
open(MIF_FILE,">$mif_name") or die "Can not open file $mif_name";

# step 1 initial FF to memory
for ($i=0;$i<1000;$i++) {
print MIF_FILE "FF\n";}

# step 2 delete the ":" in the hex file
while (<HEX_FILE>) {
    if (/^:/) { ($line_data)=/:(.*)\n/;
               @data= split(//,"$line_data"); 
               $number=@data;
               print HEX_TMP_FILE "$data[0]$data[1] $data[2]$data[3]$data[4]$data[5] ";
               
               for ($i=6;$i<$number;$i=$i+2) {
               print HEX_TMP_FILE "$data[$i]$data[$i+1] ";} }
               print HEX_TMP_FILE "\n";
}

close(MIF_FILE);
close(HEX_TMP_FILE);
open(HEX_TMP_FILE,"$hex_tmp_name") or die "Can not open file $hex_tmp_name";

while (<HEX_TMP_FILE>) {
open(MIF_FILE_IN,"$mif_name") or die "Can not open file $mif_name";
      @byte_data=split(/\s/,"$_");
      @ff_data=<MIF_FILE_IN>;
      $addr_number = hex("0x$byte_data[1]");
      $data_number = hex("0x$byte_data[0]");
      if($byte_data[2]=="00"){
#      print "$addr_number; $data_number @byte_data\n";
open(MIF_FILE_OUT,">$mif_name") or die "Can not open file $mif_name";
      for($i=0;$i<$addr_number;$i++){print MIF_FILE_OUT "$ff_data[$i]";}
      for($i=0;$i<$data_number;$i++){print MIF_FILE_OUT "$byte_data[$i+3]\n";}
      for($i=$addr_number+$data_number;$i<1000;$i++){print MIF_FILE_OUT "$ff_data[$i]";}
     # print MIF_FILE_OUT "$byte_data[1]\n";
close(MIF_FILE_OUT);}
close(MIF_FILE_IN);
#exit;
}

close(HEX_FILE);


