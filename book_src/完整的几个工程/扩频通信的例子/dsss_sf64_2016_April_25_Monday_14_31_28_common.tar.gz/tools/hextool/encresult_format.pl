#!/usr/bin/perl -w
use 5.010;
use strict;

my $in  = $ARGV[0];
my $out = $ARGV[1];

unless(defined $in){
	die "Usage: $0 filename";
}

unless(open IN,"<","$in"){
	die "Can't open $in: $!";
}

my $count = 0;
while(<IN>){
	chomp;
	my $idx = $count / 384;
	if($count % 384 == 0){
		if(!open OUT,">","$out$idx.txt"){
			die "Can't open $out$count.txt: $!";
		}
	}
	print OUT "$_"."000"."\n";
	$count++;
}
