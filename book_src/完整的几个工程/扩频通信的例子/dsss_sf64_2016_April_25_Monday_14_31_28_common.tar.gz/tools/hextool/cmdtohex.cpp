// *********************************************************************/ 
// Copyright 2003 Actel Corporation.  All rights reserved.
// IP Solutions Group
//
// ANY USE OR REDISTRIBUTION IN PART OR IN WHOLE MUST BE HANDLED IN 
// ACCORDANCE WITH THE ACTEL LICENSE AGREEMENT AND MUST BE APPROVED 
// IN ADVANCE IN WRITING.  
//  
// File:  cmdtohex.exe
//     
// Description: 1553B BC Evaluation PCB Support
//              Converts Text command file to Intel Hex
//
// Rev: 1.0 01Feb03 IPB  : Initial Code  
// Rev: 1.5 23Jun03 IPB  : Production Code for 1553BBC Eval Card  
//
// This program is supplied for support use only.
// 
// Notes:
//
// *********************************************************************/ 

//

#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream.h>
#include <fstream.h>
#include <malloc.h>
#include <ctype.h>
#include <assert.h>
#include <time.h>
#include <stddef.h>
#include <stdarg.h>
#include <new.h>
#include <math.h>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <stack>
#include <queue>
#include <utility>
#include <algorithm>
using namespace std;
#pragma warning (disable:4786)

/********************************************************************************/
/* Global variables */

 FILE *finp; 
 FILE *fout; 
 char filename_in[32];
 char filename_out[32];
 char filebase[32];

 int debug;
 int REGOFFSET   = 131072;
 int RTREGOFFSET = 8192*2;
 
 int current_addrH;
 
/*********************************************************************************/
/* Input Line Parsing Etc */

int getline(char *line, int *pos)
  {int length;
   char iline[1024];
   int lc,i;

   length=1024; 
   for( i=0;i<strlen(line);i++) line[i]=0;
   if (fgets(iline, length, finp) == NULL )
       return 0;
   else
     lc = strlen(iline)-1;
      while ( lc>=0 && 
           ((iline[lc]==' ') || (iline[lc]==13) || (iline[lc]==10) || (iline[lc]==9) ))
      { iline[lc]=0;
        lc = lc-1;
      } 
     lc=lc+1;
     iline[lc]=' ';
     iline[lc+1]=0;

	 // Remove the comments
	 i = 0;
		 while ( i<=lc ) 
		 {
			 if (iline[i]=='!')
			 {
				 iline[i]=' ';
				 iline[i+1]=0;
				 lc = i;
			 }
			 i++;
		 }
       
     strcpy(line,iline);
       
     //See if a comment Line, or blank line if so ignore it
     *pos = 0;
     while ((line[*pos]==' ') || (line[*pos]==9)) *pos = *pos + 1;
     if (line[*pos]==0) getline(line,pos);
     if ((line[*pos]=='/') && (line[*pos+1]=='/')) getline(line,pos);
     if (line[*pos]==';')  getline(line,pos);
     if (line[*pos]=='!')  getline(line,pos);
     return (strlen(line));
  }

char to_upper(char c)
 {
  if ((c>='a') && (c<='z'))
    return(c-97+65);
  else
    return(c);
 }

void nextcharacter(char *line, int *pos)
 {
   
   if (line[*pos]!=0) *pos = *pos + 1;
 
 }

void whitespace(char *line,int *pos)
{
  while ((line[*pos]==' ') || (line[*pos]==9))
   { 
     nextcharacter(line,pos);
   }
 }


int terminator(char c, int escaped)
 {
  if (escaped==1) 
   {  if (c==' ')return(1);
      else return(0);
   }
  else
   { if (    (c==0) || ( c=='=') || (c==':') || (c<=' ') || (c==',')
         || (c=='(') || (c==')') || (c==34) || (c==';') || (c=='{') || (c=='}')  
        ) return(1);            // 34 = "
     else return(0);
   }
 }


int getfield(char *line, char *field, int *pos)
 { int i;
   int escaped,fescaped,quoted;
   
   i = 0;
   quoted=0;
   fescaped=0;
   if (line[*pos]==92) 
     { fescaped=1;
       nextcharacter(line,pos);
     }
   if (line[*pos]==34) 
     { quoted=1;
       nextcharacter(line,pos);
     }

   escaped = fescaped;
   if (quoted==1)
    {  while ( line[*pos]!=34 )
        { field[i] = line [*pos];
          i++;
          nextcharacter(line,pos);
        }
    }
   else
    {  while  ( terminator( line[*pos],escaped) == 0 )  
        { if ((line[*pos]==92) && (fescaped==0))
            { escaped = 1;
              nextcharacter(line,pos);
            }
          else
            { escaped = fescaped;
              field[i] = line[*pos];
              i++;
              nextcharacter(line,pos);
            }
        }
     }
   field[i] = 0;
   return i;
 }


/*************************************************************************************/

int getvalue( char *line) 

{
int i,x;    
int ERR;    
int BASE;   
char c;      
int GOTV;   
int CW;     
int CWVAL;  
int CWI;
int foundend; 
int pos;   


 i   = 0;
 ERR = 0;
 foundend = 0;
 x    = 0;
 GOTV = 0;
 BASE = 10;
 CW   = 0;
 CWI  = 0;
 pos = 0;
 while ( foundend==0 &&  ERR==0 ) 
 {
      whitespace(line,&pos); 
	  c = line[pos];
      c = to_upper(c); 
	  if ( c>='0' && c<='9') 
		{
           x =x * BASE + c - '0';
           GOTV = 1;
		}
	  else if ( c>='A' && c<='F')
		{
		   BASE = 16;
           x =x * BASE + 10 + c - 'A';
           GOTV = 1;
		}
      else if ( c=='#' )
		{ 
           BASE = 16;
		}
      else if ( c=='.')
	  { 
		       CW = 1;                            
			   switch (CWI) {
			   case 0 : if (x>=0 && x<=31)
                           CWVAL = x * 2048;
						else 
						{
                           ERR = 0;
                           printf("Error, RT No out of range:%d: %s",x,line); 
						}
						break;
               case 1  :if (x>=0 && x<=1) 
                           CWVAL = CWVAL + x * 1024;
                        else
						{ 
					  	   ERR = 0;
						   printf("Error, TX/RX of range:%d: %s",x,line); 
						}
						break;
               case 2:  if (x>=0 && x<=31) 
                            CWVAL = CWVAL + x * 32;
                        else
						{
                            ERR = 0;
                            printf("Error, SA out of range:%d: %s",x,line); 
						}
						break;
               case 3 : if (x>=0 && x<32) 
                            CWVAL = CWVAL + x;
				        else if (x==32)
						 	CWVAL = CWVAL + 0;
                        else
						{
                            ERR = 0;
                            printf("Error, WC out of range:%d: %s",x,line); 
						} 
						break;
               case 4 : ERR = 0;
                        printf("Error, too many dots: %s",line);
						break;
               }
               CWI = CWI + 1;
               x = 0;
               BASE = 10;
		}
        nextcharacter(line,&pos);
		c = line[pos];
		if (c==' ' || c==',' || c==';' || c==NULL ) foundend=1;
	}  // end of main loop
    if (CW==1) 
	{
     if (CWI==3) 
	 {
       CWI = CWI + 1;
       if (x>=0 && x<32) 
         CWVAL = CWVAL +  x;
       else if ( x==32)
		 CWVAL = CWVAL + 0;
	   else
	   { ERR = 1;
         printf("Error, WC out of range:%d: %s",x,line);
	   }
	 }
     if (CWI!=4) 
     {   ERR = 1;
         printf("Error, Not enough dots %d %s",x,line); 
	 }
	   x = CWVAL;
	}
  if (debug==2) printf("VALUE = %04x  (%s)\n",x,line);
  return(x);
}

/*------------------------------------------------------------------------------*/
/*  */

int csumword( int a)
{
  int MSB;
  int LSB;

  MSB = a/256;
  LSB = a - MSB*256;
  return(MSB+LSB);
}

void printhex( int addr, int n, int *data)
{
 int length;
 int addrH;
 int addrL;
 int i;
// int tmp1,tmp2;

 length = n*2; 
 addrH = addr / 65536;
 addrL = addr - addrH*65536;

 printf("Count %d: Address %06x : ",n,addr);
 for( i=0;i<n;i++) printf("%04x ",data[i]);
 printf("\n");
 
}


void writeihex( int addr, int n, int *data)
{
 int length;
 int csum;
 int addrH;
 int addrL;
 int dataH;
 int dataL;
 int i;
// int tmp1,tmp2;

 length = n*2; 
 addrH = addr / 65536;
 addrL = addr - addrH*65536;


 if ( current_addrH != addrH )  // If Upper Address has changed add record
 {
   csum = csumword(addrH)+ 02 + 04;
   csum = csum  - 256*(csum/256);
   csum = 256 -csum;
   fprintf(fout,":02000004%04X%02X\n",addrH,csum);
   current_addrH = addrH; 
 }
 csum = length + csumword(addrL)+ 00;

 fprintf(fout,":%02X%04X00",length,addrL);
 for( i=0;i<n;i++)
 {
     dataH = data[i] / 256;
     dataL = data[i] - dataH*256;
	 fprintf(fout,"%02X%02X",dataL,dataH);
	 csum = csum + csumword(data[i]);
 }
 
 csum = csum  - 256*(csum/256);
 csum = 256 -csum;
 if ( csum == 256) csum =0 ;

 fprintf(fout,"%02X\n",csum);

 if (debug==1) 
 { printf("OP: %06x : ",addr);
   for( i=0;i<n;i++) printf("%04x ",data[i]);
   printf("\n");
 }
}

void writeihexbig( int addr, int n, int *data)
{
 int addrX;
 int nX;
 int i;
 int dataX[64];
 int done;

 done = 0;
 addrX = addr;

 while (done<n )
 {  nX =  16;
    if (done+nX>n) nX=n-done;
	for (i=0; i<nX; i++ ) dataX[i] = data[i+done];
	writeihex(addrX,nX,dataX);
	done = done + nX;
	addrX = addrX + nX *2;
 }
}

/*------------------------------------------------------------------------------*/
/* RT Controls */
 
void processRTcmd( int reg, int datax)
{
  int n;
  int data[100];
  int address;
    
  if (debug==2) printf("CMD:%d:%d\n",reg,datax);
  n = 1;
  address = 2 * reg + RTREGOFFSET;  // PCI memory is byte addressed !
  data[0] = datax;
  writeihex(address,n,data);
 
}


void processRTREG(char *line, int *pos )
{
  int n;
  int data[100];
  char field[80];
  int address;
  char c;
    
  if (debug==2) printf("RTREG:%s\n",line);
    n = 0;
    nextcharacter(line,pos);
  	whitespace(line,pos);
    getfield(line,field,pos);
	address = getvalue(field);
	address = 2 * address + RTREGOFFSET;  // PCI memory is byte addressed !
	nextcharacter(line,pos);
	whitespace(line,pos);
	c=line[*pos];
	while ( c!=';' && c!=0 )
	{
		getfield(line,field,pos);
		data[n] = getvalue(field);
		n++;	    
	    nextcharacter(line,pos);
	    whitespace(line,pos);
	    c=line[*pos];
    }
    writeihex(address,n,data);
}


void processRTREGSET(char *line, int *pos, int reg )
{
  int n;
  int data[100];
  char field[80];
  int address;
  char c;
    
  if (debug==2) printf("RTREGSET:%s %d\n",line,reg);
 	address = 2 * reg + RTREGOFFSET;  // PCI memory is byte addressed !
	nextcharacter(line,pos);
	whitespace(line,pos);
	c=line[*pos];
    n = 1;
    getfield(line,field,pos);
	data[0] = getvalue(field); 
    writeihex(address,n,data);
}


void processRTSA(char *line, int *pos)
{
  int n;
  int data[32];
  char field[80];
  int address;
  int inc;
  int i;
    
    if (debug==2) printf("RTSA:%s\n",line);
    n = 32;
    nextcharacter(line,pos);
  	whitespace(line,pos);
    getfield(line,field,pos);
	address = getvalue(field) * 32 + 0x400;
	
	nextcharacter(line,pos);
	whitespace(line,pos);
    getfield(line,field,pos);
	data[0] = getvalue(field);

	nextcharacter(line,pos);
	whitespace(line,pos);
    getfield(line,field,pos);
	inc = getvalue(field);

	for (i=1;i<n;i++)  data[i] = data[i-1] + inc;
	address = address * 2;
    writeihexbig(address,n,data);
}

void processRTSAINIT()
{
  int n;
  int data[32];
  int address;
  int inc;
  int i,sa;
    
    if (debug==2) printf("RTSAINIT:\n");
    n = 32;
	for (sa=1; sa<=30; sa ++ )
	{
	   address = sa * 32 + 0x400;	   
	   data[0] = sa*256;
	   inc = 1;
   	   for (i=1;i<n;i++)  data[i] = data[i-1] + inc;
	   address = address * 2;
       writeihexbig(address,n,data);
	}
 	for (i=0;i<n;i++)  data[i] = 0;
	for (sa=0; sa<=33; sa=sa+31 )
	{
	   address = sa * 32 + 0x400;	   
	   address = address * 2;
       writeihexbig(address,n,data);
	}
	for (sa=0; sa<=31; sa ++ )
	{
	   address = sa * 32 + 0;	   
	   address = address * 2;
       writeihexbig(address,n,data);
	}
}

void processRTN(char *line, int *pos)
{
  int n;
  int data[32];
  char field[80];
  int address;
  int rt;
  int rtpar;
  int x;
    
    if (debug==2) printf("RTN:%s\n",line);
    n = 32;
    nextcharacter(line,pos);
  	whitespace(line,pos);
    getfield(line,field,pos);
	rt = getvalue(field);
	if (rt>30) printf("RT number > 30\n");
	x = 0;
	x = x + ( rt >> 0) & 1;
	x = x + ( rt >> 1) & 1;
	x = x + ( rt >> 2) & 1;
	x = x + ( rt >> 3) & 1;
	x = x + ( rt >> 4) & 1;
	rtpar = 0;
	if ( (x==0) || (x==2) || (x==4)) rtpar = 32;
    n = 1;
	data[0] = 0x600 + 64 + rtpar + rt;
	if (debug==2) printf(" RT %d PAR %d REG %04x\n",rt,rtpar,data[0]);
    address = RTREGOFFSET;
    writeihex(address,n,data);
}

void processRTRESET()
{
  processRTcmd(0,0x0600);
  processRTcmd(1,0x0002);
  processRTcmd(2,0x0000);
  processRTcmd(3,0x0000);
  processRTcmd(4,0x1234);
  processRTcmd(5,0x0000);
  processRTcmd(6,0xffff);
  processRTcmd(7,0xffff);
  processRTcmd(8,0xffff);
  processRTcmd(9,0xffff);
}

/*------------------------------------------------------------------------------*/
/* Read the text File */
 
void processcmd( int reg, int datax)
{
  int n;
  int data[100];
  int address;
    
  if (debug==2) printf("CMD:%d:%d\n",reg,datax);
  n = 1;
  address = 4 * reg + REGOFFSET;  // PCI memory is byte addressed !
  data[0] = datax;
  writeihex(address,n,data);
 
}

void processreg(char *line, int *pos, int reg)
{
  int n;
  int data[100];
  char field[80];
  int address;
  char c;
    
  if (debug==2) printf("REG:%d:%s\n",reg,line);
    n = 0;
	address = 4 * reg + REGOFFSET;  // PCI memory is byte addressed !
	nextcharacter(line,pos);
	whitespace(line,pos);
	c=line[*pos];
	while ( c!=';' && c!=0 )
	{
		getfield(line,field,pos);
		data[n] = getvalue(field);
		n++;	    
	    nextcharacter(line,pos);
	    whitespace(line,pos);
	    c=line[*pos];
    }
    writeihex(address,n,data);
}

const MAXFILL = 16384;

void processfill(char *line, int *pos)
{
  int n;
  int data[MAXFILL];
  char field[80];
  int address;
  int inc;
  int i;
    
  if (debug==2) printf("FILL:%s\n",line);
    n = 0;
    nextcharacter(line,pos);
   	whitespace(line,pos);
    getfield(line,field,pos);
	address = getvalue(field);
	
	nextcharacter(line,pos);
	whitespace(line,pos);
    getfield(line,field,pos);
	data[0] = getvalue(field);

	nextcharacter(line,pos);
	whitespace(line,pos);
    getfield(line,field,pos);
	n = getvalue(field);

	if ( n>MAXFILL ) 
	{ printf("Error max fill length is %d Words\n",MAXFILL);
	  n = MAXFILL;
	}
	nextcharacter(line,pos);
	whitespace(line,pos);
    getfield(line,field,pos);
	inc = getvalue(field);

	for (i=1;i<n;i++)  data[i] = data[i-1] + inc;
	address = address * 2;
    writeihexbig(address,n,data);
}


void processmem(char *line, int *pos, int reg)
{
  int n;
  int data[100];
  char field[80];
  int address;
  char c;

    
  if (debug==2) printf("MEM:%s\n",line);
    n = 0;
    nextcharacter(line,pos);
    whitespace(line,pos);
    getfield(line,field,pos);
	address = getvalue(field);
	if ( reg==1) address = 4 * address + REGOFFSET;  // PCI memory is byte addressed !
	 else address = address * 2;
	nextcharacter(line,pos);
	whitespace(line,pos);
	c=line[*pos];
	while ( c!=';' && c!=0 )
	{
		getfield(line,field,pos);
		data[n] = getvalue(field);
		n++;	    
	    nextcharacter(line,pos);
	    whitespace(line,pos);
	    c=line[*pos];
    }
    writeihex(address,n,data);
}

char QUOTE = '"';

void processtext(char *line, int *pos)
{
  int n,i;
  int dataw[50];
  int datab[100];
  char field[80];
  int address;
  char c;

    
    if (debug==2) printf("TEXT:%s\n",line);
    n = 0;
    nextcharacter(line,pos);
    whitespace(line,pos);
    getfield(line,field,pos);
	address = getvalue(field);
	address = address * 2;
	c=line[*pos];
	while ( c!=QUOTE && c!=0 )
	{
	   nextcharacter(line,pos);
       c=line[*pos];
	}
    if (c!=QUOTE) printf("Error in input string, no start quote\n");
	nextcharacter(line,pos);
    c=line[*pos];
	
	while ( c!=0 && c!=QUOTE) 
	{
	   datab[n] = c;
	   n++;
       nextcharacter(line,pos);
       c=line[*pos];
	}
    if (c==0) printf("Error in input string, no end quote\n");

	if (c==QUOTE)
	{ // Got the text string, convert bytes to words
	  if ( (n/2)*2 != n)  // Make an even number, fill with a space
	  { datab[n] = ' ';
	    n++;
	  }
	  for (i=0;i<=100;i=i+2) dataw[i/2] = datab[i]*256 + datab[i+1];
      n = n /2;

      writeihex(address,n,dataw);
	}
}

void processMARQUE(char *line, int *pos, int rt)
{
  int n,i;
  int dataw[50];
  int datah[20];
  int datab[100];
  char field[80];
  int address;
  char c;
  int bcaddr;

    
    if (debug==2) printf("TEXT:%s\n",line);
    n = 0;
    nextcharacter(line,pos);
    whitespace(line,pos);
    getfield(line,field,pos);
	address = getvalue(field);

	bcaddr  = address+32;
	address = address * 2;


	c=line[*pos];
	while ( c!=QUOTE && c!=0 )
	{
	   nextcharacter(line,pos);
       c=line[*pos];
	}
    if (c!=QUOTE) printf("Error in input string, no start quote\n");
	nextcharacter(line,pos);
    c=line[*pos];
	
	while ( c!=0 && c!=QUOTE) 
	{
	   datab[n] = c;
	   n++;
       nextcharacter(line,pos);
       c=line[*pos];
	}
    if (c==0) printf("Error in input string, no end quote\n"); 

	if (c==QUOTE)
	{ // Got the text string, convert bytes to words
	  if ( (n/2)*2 != n)  // Make an even number, fill with a space
	  { datab[n] = ' ';
	    n++;
	  }
	  for (i=0;i<=99;i=i+2) dataw[i/2] = datab[i]*256 + datab[i+1];
      n = n /2;

      datah[0] = 0x0050;                   // BC-RT ! retry per bus
	  datah[1] = rt* 2048 + 27*32 + n+ 5;  // CW
	  datah[2] = 0;
	  datah[3] = bcaddr;
	  datah[4] = 0;
	  datah[5] = 0;
	  datah[6] = 0;
	  datah[7] = 0;
      writeihex(address,8,datah);      // Write the BC Message Block
	  datah[0] = 0x0407;
	  datah[1] = 0x3030;
	  datah[2] = 0x300a;
	  datah[3] = 0x3031;
      writeihex(address+64,4,datah);     // Write the MARQUE  Header
      writeihex(address+64+8,n,dataw);   // Write the Text
	  datah[0] = 0x1200;
      writeihex(address+64+8+n*2,1,datah);

	}
}

void processcomment(char *line, int *pos)
{
  if (debug==2) printf("COMMENT:%s\n",line);
}

/*------------------------------------------------------------------------------*/
/* Read the text File */


int processfile(char * filename_in)
{
 char line[1024];
 char cmd[128];
 int pos,ok;
 int i;
 int foundend;

 if ((finp=fopen(filename_in,"r"))==NULL) 
  { printf("ERROR: No Input Text File\n");
    return(0); 
  }
 else
  {
   foundend = 0;
   pos = 0;
   i = 0;

   while ( foundend == 0)
   {   
	  ok=getline(line,&pos); 
	  if (debug==1) printf("IP: %s\n",line);
      if (ok==0)
	  {
		 foundend = 1;
	  }
	  else
	  {   whitespace(line,&pos);
	      getfield(line,cmd,&pos);
	     	   if ((strncmp(cmd,"#",1))==0)   processcomment(line,&pos) ;
 	      else if ((strncmp(cmd,"!",1))==0)   processcomment(line,&pos) ;
          else if ((strncmp(cmd,"MEM",3))==0) processmem(line,&pos,0);
          else if ((strncmp(cmd,"REG",3))==0) processmem(line,&pos,1);
	      else if ((strncmp(cmd,"TEXT",4))==0)        processtext(line,&pos);
	      else if ((strncmp(cmd,"FILL",4))==0)        processfill(line,&pos);
	      else if ((strncmp(cmd,"CONTROL"  ,7))==0)   processreg(line,&pos,0);
	      else if ((strncmp(cmd,"SETUP"    ,5))==0)   processreg(line,&pos,1);
	      else if ((strncmp(cmd,"LISTPTR"  ,7))==0)   processreg(line,&pos,2);
	      else if ((strncmp(cmd,"MSGPTR"   ,6))==0)   processreg(line,&pos,3);
	      else if ((strncmp(cmd,"CLOCK"    ,5))==0)   processreg(line,&pos,4);
	      else if ((strncmp(cmd,"ASYNCPTR" ,8))==0)   processreg(line,&pos,5);
	      else if ((strncmp(cmd,"STACKPTR" ,8))==0)   processreg(line,&pos,6);
	      else if ((strncmp(cmd,"INTERRUPT",8))==0)   processreg(line,&pos,7);
	      else if ((strncmp(cmd,"START"    ,5))==0)   processcmd(0,1);
	      else if ((strncmp(cmd,"STOP"     ,4))==0)   processcmd(0,2);
	      else if ((strncmp(cmd,"ABORT"    ,5))==0)   processcmd(0,4);
	      else if ((strncmp(cmd,"ASYNC"    ,5))==0)   processcmd(0,8);
	      else if ((strncmp(cmd,"RTRESET"  ,6))==0)   processRTRESET();
	      else if ((strncmp(cmd,"RTSAINIT" ,7))==0)   processRTSAINIT();
	 	  else if ((strncmp(cmd,"RTSA"     ,4))==0)   processRTSA(line,&pos);
	 	  else if ((strncmp(cmd,"RTREG"    ,5))==0)   processRTREG(line,&pos);
	 	  else if ((strncmp(cmd,"RTVWORD"  ,6))==0)   processRTREGSET(line,&pos,4);
	 	  else if ((strncmp(cmd,"MARQUE"   ,6))==0)   processMARQUE(line,&pos,2);
  	 	  else if ((strncmp(cmd,"RT"       ,2))==0)   processRTN(line,&pos);
          else if ((strncmp(cmd,"[",1))==0)   ;
	      else if ((strncmp(cmd,"]",1))==0)   ;
	  else printf("Error: Unknown Line %s\n",line);
	  }
   }
   
  }
 return(1);
}

/*********************************************************************************/
/* The Main Routine plus help and switch extraction */


void  printhelp()
 {
   printf("Program converts command file to Intel hex \n");
   printf("cmdtohex  -in infile.txt -out outfile.ihx [-debug]\n");
   printf("cmdtohex  -txt infile  [-debug]\n");
   printf("BC Support\n");
   printf("  MEM  ADDR DATA [DATA] ... [DATA]\n");
   printf("  FILL ADDR DATA N INC\n");
   printf("  TEXT ADDR \"ASCII STRING\"\n");
   printf("  REG  N DATA\n");
   printf("  CONTROL   DATA\n");
   printf("  SETUP     DATA\n");
   printf("  LISTPTR   DATA\n");
   printf("  MSGPTR    DATA\n");
   printf("  CLOCK     DATA\n");
   printf("  ASYNCPTR  DATA\n");
   printf("  STACKPTR  DATA\n");
   printf("  INTERRUPT DATA\n");
   printf("  START\n");
   printf("  STOP\n");
   printf("  ABORT\n");
   printf("  ASYNC\n");
   printf("RT Support (Assumes CMODE=0)\n");
   printf("  RTRESET    ... resets the RT \n");
   printf("  RTSAINIT   ... initilalises all RT TX and clears RX sub addresses\n"); 
   printf("  RT N       ... sets the RT to RT N\n");
   printf("  RTVWORD DATA  Sets the RT Vector Word \n");
   printf("  RTREG N DATA  N=DWORD Register address 0=4000 1=4002 etc\n");
   printf("  RTSA SA DATA INC \n");
   printf("DATA Values\n");
   printf("  1234  Decimal\n");
   printf("  A123  Hex, auto\n");
   printf("  #1A34 Hex\n");
   printf("  1.1.5.23  1553B command word\n");
   printf("  \n");
}

int switchs(int argc, char **argv)
{
 int i;
 char base[80];
 
 if (argc==1) return(0);
 for (i=1; i<argc; i++)
  { 
    if (strncmp(argv[i],"-h",2)==0)
      { printhelp();
      }
    else if (strncmp(argv[i],"-in",3)==0)
      { strcpy(filename_in,argv[i+1]);
        i++;
	}
    else if (strncmp(argv[i],"-out",4)==0)
      { strcpy(filename_out,argv[i+1]);
        i++;
	}
    else if (strncmp(argv[i],"-txt",4)==0)
      { strcpy(base,argv[i+1]);
	    sprintf(filename_in,"%s.txt",base);
	    sprintf(filename_out,"%s.hex",base);
        i++;
	}
    else if (strncmp(argv[i],"-help",5)==0)
    {  
		printhelp();
	}
    else if (strncmp(argv[i],"-debug",6)==0)
    {  
        debug = 1;
	}
    else if (strncmp(argv[i],"-xdebug",7)==0)
    {  
        debug = 2;
	}
  else return(0);
  }
 return(1);
}

/*********************************************************************************/
/* The Main Routine plus help and switch extraction */



int main(int argc, char* argv[])
{

 strcpy(filename_in ,"bcsetup.txt");
 strcpy(filename_out,"test.hex");

 debug=0;
 current_addrH = -1;

 printf("1553B Bus Controller CMD to HEX file v2.00 21 August 03 \n");

 if (switchs(argc,argv)==0) printf("cmdtohex -txt | -in file -out file | -help | -debug\n");

    {
	  fout=fopen(filename_out,"w");
	  printf(" Input %s   output %s\n",filename_in, filename_out);
      processfile(filename_in);
	  fprintf(fout,":00000001FF\n");
      fclose(fout);

   }

    
return 0;
}

