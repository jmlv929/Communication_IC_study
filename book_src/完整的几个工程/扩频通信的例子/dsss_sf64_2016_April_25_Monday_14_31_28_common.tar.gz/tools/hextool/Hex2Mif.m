function Hex2Mif(srcFileName, dstFilePath, deepth)

%% Init CODE MEMORY
for i = 1 : deepth
    MEMORY(i, :) = '00000000';
end

%% Update MEMORY

fid_Hex = fopen(srcFileName, 'r');
if (fid_Hex < 0)
    error(['can not open ' srcFileName] );
    return;
end


while(~feof(fid_Hex))
    records = fgetl(fid_Hex);
    if (records(1) ~= ':')
        error('records format is not Intel Hex Format' );
        return;
    end
    recordsLen = records(2 : 3);
    loadAddr = records(4 : 7);
    recordsType = records(8 : 9);
    recordsData = records(10 : end - 2);
    recordsChck = records(end-1 : end);
    
    %������У��
    
    if recordsType == '00'
       ByteLen = hex2dec(recordsLen);
       StartAddr = hex2dec(loadAddr);
       for i = 1 : ByteLen/4
           MEMORY(StartAddr/4 + i, :) = recordsData((i - 1) * 8 + 1 : i * 8);
       end
    end
    
end

fclose(fid_Hex);

%% Gen Mif File
width = 8;
depth = deepth;

for i = 0 : 3
    fid_out = fopen([dstFilePath '\' 'codec' num2str(i) '.mif'], 'w');
    
    fprintf(fid_out, 'WIDTH = %d ;\n', width);
    fprintf(fid_out, 'DEPTH = %d ;\n', depth);
    fprintf(fid_out, 'ADDRESS_RADIX=UNS;\n');
    fprintf(fid_out, 'DATA_RADIX=HEX;\n');
    fprintf(fid_out, 'CONTENT BEGIN\n');
    
    for j = 0 : depth - 1
        
        fprintf(fid_out, '%5d    : ', j);
        fprintf(fid_out, '%s',  MEMORY(j+1, 2 * i + 1 : 2 * i + 2));
        fprintf(fid_out, ';\n');
        
    end
    
    fprintf(fid_out, 'END;\n');
    fclose(fid_out);
end

