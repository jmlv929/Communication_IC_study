#!/usr/bin/perl -w
use 5.010;
use strict;

my $in  = $ARGV[0];
$_ = $in;
s/\x2e.*//;

my $out0 = $_."0.init";
my $out1 = $_."1.init";
my $out2 = $_."2.init";
my $out3 = $_."3.init";

unless(defined $in){
	die "Usage: Not enough arguments";
}

(open IN,"<",$in) or die "# Can't open '$in'";
(open OUT0,">",$out0) or die "# Can't open '$out0'";
(open OUT1,">",$out1) or die "# Can't open '$out1'";
(open OUT2,">",$out2) or die "# Can't open '$out2'";
(open OUT3,">",$out3) or die "# Can't open '$out3'";


$_ = <IN>;
while(<IN>){
	chomp($_);
	print OUT0 $_."\n";
	chomp($_ = <IN>);
	print OUT1 $_."\n";
	chomp($_ = <IN>);
	print OUT2 $_."\n";
	chomp($_ = <IN>);
	print OUT3 $_."\n";
}
