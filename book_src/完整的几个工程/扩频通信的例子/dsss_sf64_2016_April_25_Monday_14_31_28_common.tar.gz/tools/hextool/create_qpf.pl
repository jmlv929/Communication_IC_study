#!/usr/bin/perl -w
use 5.010;
use strict;

my $filename = shift @ARGV;
unless(defined $filename){
	die "# Not enough arguments";
}

open FILE,">>",$filename or die "# Can't open file '$filename'";

my ($second,$minute,$hour,$day, $month, $year) = (localtime)[0,1,2,3,4,5];

$month = $month + 1;
$year = $year + 1900;

my $monthname;
if($month == 1){
	$monthname = "January";
}elsif($month == 2){
	$monthname = "February";
}elsif($month == 3){
	$monthname = "March";
}elsif($month == 4){
	$monthname = "April";
}elsif($month == 5){
	$monthname = "May";
}elsif($month == 6){
	$monthname = "June";
}elsif($month == 7){
	$monthname = "July";
}elsif($month == 8){
	$monthname = "August";
}elsif($month == 9){
	$monthname = "September";
}elsif($month == 10){
	$monthname = "October";
}elsif($month == 11){
	$monthname = "November";
}elsif($month == 12){
	$monthname = "December";
}

my $tmp = sprintf "DATE = \"%02d:%02d:%02d  %s %d, %d\"",$hour,$minute,$second,$monthname,$day,$year;
print FILE "\n$tmp\n";

foreach my $arg (@ARGV){
	print FILE "$arg\n";
}
exit;