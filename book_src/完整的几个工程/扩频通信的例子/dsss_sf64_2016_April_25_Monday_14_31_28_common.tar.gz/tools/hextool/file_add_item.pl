#!/usr/bin/perl -w
use 5.010;
use strict;

#my $file = $ARGV[0];
#my $item = $ARGV[1];
#unless(defined $file){
#	die "# Usage: Not enough arguments";
#}
#(open FILE,">>",$file) or die "# Can't open $file";
#
#print FILE "\nset_global_assignment -name".$item."\n";
#close(FILE);
#
#exit;

unless(@ARGV >= 2){
	die "# Usage: Not enough arguments";
}

my $file   = shift @ARGV; #��һ�������Ǵ��޸ĵ��ļ�
my $header = shift @ARGV; #�ڶ���������ÿ��Ҫ���ӵ�ͷ

open FILE,">>",$file or die "# Can't open $file";

print FILE "\n";
foreach(@ARGV){
	chomp($_);
	print FILE $header.$_."\n";
}
close(FILE);

exit;
