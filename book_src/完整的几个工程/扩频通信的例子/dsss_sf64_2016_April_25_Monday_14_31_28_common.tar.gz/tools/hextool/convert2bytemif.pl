#!/usr/bin/perl -w
use 5.010;
use strict;

my $in  = $ARGV[0];
$_ = $in;
s/\x2e.*//;

my $out0 = $_."0.mif";
my $out1 = $_."1.mif";
my $out2 = $_."2.mif";
my $out3 = $_."3.mif";

my $head = "\
 DEPTH = 8192;                 -- The size of data in bits
 WIDTH = 8;                    -- The size of memory in words, this means memory bit width,should match with ram width
 ADDRESS_RADIX = HEX;          -- The radix for address values
 DATA_RADIX = HEX;             -- The radix for data values
 CONTENT                       -- start of (address : data pairs)
 BEGIN
";

unless(defined $in){
	die "Usage: Not enough arguments";
}

(open IN,"<",$in) or die "# Can't open '$in'";
(open OUT0,">",$out0) or die "# Can't open '$out0'";
(open OUT1,">",$out1) or die "# Can't open '$out1'";
(open OUT2,">",$out2) or die "# Can't open '$out2'";
(open OUT3,">",$out3) or die "# Can't open '$out3'";

print OUT0 $head."\n\t";
print OUT1 $head."\n\t";
print OUT2 $head."\n\t";
print OUT3 $head."\n\t";

my $addr=0;

$_ = <IN>;
while(<IN>){
  my $addr_rec = sprintf("%.4X : ", $addr);

	chomp($_);
	print OUT0 $addr_rec."\t";
	print OUT0 $_.";\n\t";

	chomp($_ = <IN>);
	print OUT1 $addr_rec."\t";
	print OUT1 $_.";\n\t";

	chomp($_ = <IN>);
	print OUT2 $addr_rec."\t";
	print OUT2 $_.";\n\t";

	chomp($_ = <IN>);
	print OUT3 $addr_rec."\t";
	print OUT3 $_.";\n\t";
	
	$addr=$addr+1;
}

print OUT0 "\nEND;\n";
print OUT1 "\nEND;\n";
print OUT2 "\nEND;\n";
print OUT3 "\nEND;\n";


# DEPTH = 32;                   -- The size of data in bits
# WIDTH = 8;                    -- The size of memory in words
# ADDRESS_RADIX = HEX;          -- The radix for address values
# DATA_RADIX = BIN;             -- The radix for data values
# CONTENT                       -- start of (address : data pairs)
# BEGIN
# 
# 00 : 00000000;                -- memory address : data
# 01 : 00000001;
# 02 : 00000010;
# 03 : 00000011;
# 04 : 00000100;
# 05 : 00000101;
# 06 : 00000110;
# 07 : 00000111;
# 08 : 00001000;
# 09 : 00001001;
# 0A : 00001010;
# 0B : 00001011;
# 0C : 00001100;
# 
# END;
