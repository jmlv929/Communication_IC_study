#!/usr/bin/perl -w
use 5.010;
use strict;

my $in = $ARGV[0];
my $out = $ARGV[1];

unless(defined $in && defined $out){
	die "# Usage: Not enough arguments";
}
(open IN,"<",$in) or die "# Can't open $in";
(open OUT,">>",$out) or die "# Can't open $out";

print OUT "\n";
while(<IN>){
	chomp();
	print OUT $_."\n";
}