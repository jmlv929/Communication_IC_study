################################################################################
# The confidential and proprietary information contained in this file may
# only be used by a person authorised under and to the extent permitted
# by a subsisting licensing agreement from ARM Limited.
#
#            (C) COPYRIGHT 2007-2008 ARM Limited.
#                ALL RIGHTS RESERVED
#
# This entire notice must be reproduced on all copies of this file
# and copies of this file may only be made by a person if such person is
# permitted to do so under the terms of a subsisting license agreement
# from ARM Limited.
#
#      SVN Information
#
#      Checked In          : $Date: 2007-07-19 01:08:07 +0100 (Thu, 19 Jul 2007) $
#
#      Revision            : $Revision: 61335 $
#
#      Release Information : ARM Cortex-M1 FPGA Development Kit Version 1.1
#
################################################################################
#
# Purpose:
#
# Convert an Intel Hex file into a Hex file suitable for Quartus II memory
# initialization.
#
# Quartus II requires Intel Hex files to be formatted as follows:
#   - The number of bytes in a data record must be the data width of the
#     memory, rounded up to the nearest byte if necessary
#   - '03' and '05' record types are not supported (32-bit format)
#   - The order of bytes in a data record is most-significant first
#   - Field offsets and addresses refer to the word size, not bytes
#
# This utility can also create Intel Hex files containing data from a
# subsection of the input file, optionally re-based to a different address.
# This is useful for flash memory initialization in Quartus II.
#
################################################################################

###################
# Option Variables
###################

# File options
my $inhex;    # Input Hex file
my $outhex;   # Output Hex file

# Options affecting the interpretation of the input file
my $start_addr = 0;        # Lowest address of input file data to emit in output file
my $end_addr = 0xFFFFFFFF; # Highest address of input file data to emit in output file

# Options affecting the output hex file
my $data_width  = 4; # Number of bytes per record in output hex, default 4
my $output_addr = 0; # Byte address to rebase output hex data to
my $zero_pad    = 0; # 1 if output files are to be zero-padded to fill address space
my $has_target  = 0; # Set to 1 if there is a specific target end address
my $single_section  = 0; # Set to 1 if conversion should end at the next section
my $opt_nosizelimit = 0; # Set to 1 if there is no size restriction on zero-padded areas


###################
# Global variables
###################

my $base_addr = 0;      # Current base address (for 16- and 32-bit input files)
my $addr16    = 0;      # 1 if file uses 16-bit address format
my $addr32    = 0;      # 1 if file uses 32-bit address format

my @data_recs  = ();    # Storage of converted data records
my @data_addrs;         # Individual byte addresses for each data record
my $next_addr;          # Next address to be read from input hex file


###############
# Constants
###############

my $SIZE_LIMIT_MB = 5;  # Size limit (in MB) of zero-padded area


###############
# Error values
###############

my $ERR_ARGS    = 1;    # Error parsing arguments
my $ERR_INHEX   = 2;    # Error opening input file
my $ERR_OUTHEX  = 3;    # Error writing output file
my $ERR_CHKSUM  = 4;    # Checksum error
my $ERR_MEMSIZE = 5;    # Input data range not a multiple of memory size
my $ERR_ADDR    = 6;    # Address cannot be specified in output file
my $ERR_OSIZE   = 7;    # Output hex file is too large

###############################################################################
#
# SUBROUTINE: Get Checksum
# Given a string representation of a Hex file record, return the checksum as a
# 2-character string.  Due to the way the Intel Hex checksums work it does not
# matter if the input string has the checksum field missing or includes an
# empty '00' checksum field.  The function can also be used to verify the
# checksum of a record - if it returns "00" then the checksum is valid.
#
###############################################################################

sub get_chksum ($)
{
  my $record = $_[0];
  my $chksum = 0;

  # Iterate over the string, skipping the initial record mark ':'.
  for (my $i = 1; $i < length($record); $i += 2)
  {
    $chksum += hex(substr($record,$i,2));
  }

  # Checksum is the 2's complement of the sum of byte additions.  Discard all
  # carries resulting from the addition.  The sum of the byte additions plus
  # checksum will be zero.
  $chksum = 0xFF & (0x100 - ($chksum & 0xFF));

  # Return as ASCII string
  return sprintf("%.2X", $chksum);
}


################################################################################
#
# SUBROUTINE: Create data record
# Convenience function to return a data record string given a load offset and
# an array of data bytes.  The data bytes must be stored as pairs of ASCII
# hexadecimal digits.
#
################################################################################

sub create_data_record ($@)
{
  my $offset = shift;
  return "" if ($offset >> 16) != 0;
  return "" if ($#_ == -1);

  my $record = sprintf(":%.2X%.4X00%s", $#_ + 1, $offset, join('', @_));
  return $record . &get_chksum($record) . "\n";
}


################################################################################
#
# SUBROUTINE: Create an address record for 32-bit Intel Hexadecimal files
# A convenience funtion to write out a new address record given an address.
# The subroutine returns a string containing a Start Linear Address Record
# (type 05) specifying the start address of the record, and an Extended Linear
# Address Record (type 04) to specify the top 16 bits of the address.
#
################################################################################

sub create_32bit_addr_record ($)
{
  my $addr = shift;
  return "" if !defined($addr);

  my $slar = sprintf(":04000005%.8X", $addr);
  $slar .= &get_chksum($slar);
  my $elar = sprintf(":02000004%.4X", ($addr >> 16));
  $elar .= &get_chksum($elar);

  return "$slar\n$elar\n";
}


################################################################################
#
# SUBROUTINE: Read Hex file
# Read the input Intel Hex file and store the contents in the internal data
# structures.  Only the address regions specified by the global options are
# read.
#
################################################################################

sub read_hex
{
  # Read the input file
  open(INHEX, "<$inhex")
    or print "Error: Unable to open input Hex file $inhex for reading\n"
      and exit($ERR_INHEX);

  # Keep track of the current byte's address.  Used to zero-pad the input when
  # there is a discontinuity and zero-padding is enabled.
  my $curr_addr = $start_addr;

  # Iterate over the input file.  When data falls inside the specified address
  # range it will be added to the global output data array for writing.
  foreach my $i_line (<INHEX>)
  {
    chomp $i_line;
    $i_line =~ tr/\r//d;    # Strip remnants of Windows line endings

    next if $i_line !~ /^:/;

    my $i_chksum = substr($i_line, -2, 2);
    my $i_len    = substr($i_line,  1, 2);
    my $i_offset = substr($i_line,  3, 4);
    my $i_type   = substr($i_line,  7, 2);
    my $i_data   = substr($i_line,  9, hex($i_len)*2);

    # Verify the checksum
    print "Error: Invalid checksum in input Hex file $inhex\n" and exit($ERR_CHKSUM)
      if (&get_chksum($i_line) ne "00");

    # EOF record type (01)
    if ($i_type eq "01")
    {
      last;
    }

    # Extended Segment Address Record (02); or
    # Extended Linear Address Record (04)
    elsif ($i_type eq "02" or $i_type eq "04")
    {
      ($addr16,$addr32) = ($i_type eq "02", $i_type eq "04");
      $base_addr = hex($i_data) << (2 ** int($i_type)); # 02: bits 4-19, 04: top 16 bits
      $next_addr = $base_addr;

      # Stop reading additional data if the single-section option is used.
      last if ($single_section && (($base_addr > $start_addr) || @data_addrs));
    }

    # Data Record (00)
    # Push individual data bytes onto the data array if it is within the
    # specified address range.
    elsif ($i_type eq "00")
    {
      my $byte_num = 0;     # Byte number within record

      while (my $data_byte = substr($i_data, 0, 2, ''))
      {
        # When 16-bit format hex files are read the segment addresses 'wrap'
        # around a 64K (16-bits) segment.
        my $byte_addr = $addr16 ?
          $base_addr + ((hex($i_offset) + $byte_num) & 0xFFFF) :
          $base_addr + hex($i_offset) + $byte_num;

        if ($byte_addr >= $start_addr && $byte_addr <= $end_addr)
        {
          # If there's a discontinuity, and zero-padding is enabled, push zeroes
          # onto the data array to fill the space before pushing on the data for
          # the new record
          if (($curr_addr < $byte_addr) && $zero_pad)
          {
            print "Error: Zero-padded section is too large. Override with --no-size-limit.\n"
              and exit($ERR_OSIZE) if (!$opt_nosizelimit && ($byte_addr - $curr_addr > $SIZE_LIMIT_MB*1024*1024));
            push(@data_recs, ("00")x($byte_addr - $curr_addr));
            push(@data_addrs, ($curr_addr .. $byte_addr-1));
            $curr_addr = $byte_addr;
          }

          push(@data_recs, $data_byte);
          push(@data_addrs, $byte_addr);
          $byte_num++;
          $curr_addr = $byte_addr + 1;
        } # if
      } # while
    } # if

    # 03 and 05 records are ignored. The output files are used for memory
    # initialisation only and do not populate microprocessor registers.

  } # foreach

  # If zero-padding is enabled and the input data did not reach the target end
  # address then pad with zeroes
  my $target_eaddr = $has_target ? $end_addr : $data_addrs[-1];
  if (defined($target_eaddr) && ($curr_addr < $end_addr) && $zero_pad)
  {
    print "Error: Zero-padded section is too large. Override with --no-size-limit.\n"
      and exit($ERR_OSIZE) if (!$opt_nosizelimit && ($target_eaddr - $curr_addr > $SIZE_LIMIT_MB*1024*1024));
    push(@data_recs, ("00")x($target_eaddr - $curr_addr + 1));
    push(@data_addrs, ($curr_addr .. $target_eaddr));
  }

  print "Warning: Input section contains no data.\n" if ($#data_recs == -1);

  close INHEX or warn "Error when closing input Hex file $inhex";
}

################################################################################
#
# SUBROUTINE: Write Intel Hex
# Write a standard 32-bit Intel Hexadecimal file from the input Intel
# Hexadecimal file.  The output file can contain a subset of the input file's
# contents and will contain a single section.
# The read_hex subroutine must be called prior to this one.
#
################################################################################

sub write_intel_hex
{
  # Open output hex file for writing
  open(OUTHEX, ">$outhex")
    or print "Error: Unable to open output Hex file $outhex for writing\n"
      and exit($ERR_OUTHEX);

  # Loop over the input data record and keep a buffer of data bytes that will be
  # printed in 16-byte lines in the output file.
  my @record_bytes  = ();            # Data buffer
  my $record_base   = $output_addr;  # Address of first datum
  my $prev_addr     = $output_addr;  # Address of previous datum
  my $base_addr     = $output_addr;  # Current address record base address

  while (@data_recs)
  {
    my $data_byte   = shift(@data_recs);
    my $data_addr   = shift(@data_addrs) - $start_addr + $output_addr; # Re-base

    # Update address for load offset when starting a new record
    $record_base = $data_addr if ($#record_bytes == -1);

    # NON-CONSECUTIVE ADDRESS: Must flush the current data buffer contents,
    # print a new address record, and start a new data record from the new
    # address.  This case triggers for the first datum in the image so at least
    # one record will be printed.
    if ($data_addr != $prev_addr+1)
    {
      # Catch the case where a new section started on a 16-byte boundary
      my $offset = ($record_base-$output_addr) & 0xFFFF;
      print OUTHEX &create_data_record($offset, @record_bytes)
        unless ($#record_bytes == -1);

      print OUTHEX &create_32bit_addr_record($data_addr);

      $record_base  = $data_addr;
      $base_addr    = $data_addr;
      $prev_addr    = $data_addr;
      @record_bytes = ($data_byte);
    }

    # CONSECUTIVE ADDRESS: Push the new byte onto the data record buffer.  If
    # a new data record has started and the load offset overflows 16 bits, then
    # a new address record must be printed.  The data record is printed when the
    # buffer reaches 16 bytes.
    else
    {
      # Print a new section address record if necessary, i.e. when the data
      # load offset field overflows 16 bits
      if ($#record_bytes == -1 && (($record_base - $base_addr) & 0xFFFF0000))
      {
        $base_addr   = $data_addr;
        $record_base = $data_addr;
        print OUTHEX &create_32bit_addr_record($base_addr);
      }

      # Add to the record
      push(@record_bytes, $data_byte);

      # Print the record when it reaches 16 bytes
      if ($#record_bytes == 15)
      {
        my $offset = ($record_base-$output_addr) & 0xFFFF;

        print OUTHEX &create_data_record($offset, @record_bytes);
        @record_bytes = ();
      }

      $prev_addr = $data_addr;
    } # else
  } # while

  # Print any remaining data in the buffer
  my $offset = ($record_base-$output_addr) & 0xFFFF;
  print OUTHEX &create_data_record($offset, @record_bytes);

  # Write the EOF record and close file
  print OUTHEX ":00000001FF\n";
  close(OUTHEX) or print "Error when writing output Hex file $outhex\n"
    and exit($ERR_OUTHEX);
}


################################################################################
#
# SUBROUTINE: Write Hex
# Write a Quartus II compatible Hex file using the contents read from the input
# Hex file.  Assumes that the read_hex subroutine has been called first.
#
################################################################################

sub write_hex
{
  # Open output hex file for writing
  open(OUTHEX, ">$outhex")
    or print "Error: Unable to open output Hex file $outhex for writing\n"
      and exit($ERR_OUTHEX);

  # Convert absolute start address and output addresses to word addresses for
  # use in offset calculations
  my $in_base  = $start_addr / $data_width;
  my $out_base = $output_addr / $data_width;

  # The address only specifies upper bits 19:4.  The bottom 4 bits are a
  # residue used in the address offset calculations.
  my $out_ubase = $out_base >> 4;
  my $out_lbase = $out_base & 0xF;

  # The USBA field of the Extended Segment Address Record must be specified in
  # 16 bits.
  print "Error: Base address of the output data is too large\n"
    and exit($ERR_ADDR) if ($out_ubase >> 16);

  # Write the Segment Address Record first with bits 19:4 of the base address
  # of the image.  This is a Word Address in Altera Hex.
  my $addr_rec = sprintf(":02000002%.4X", $out_ubase);
  $addr_rec = $addr_rec . &get_chksum($addr_rec) . "\n";
  print OUTHEX $addr_rec;

  # The output Hex file is formed one word per line in an 8-bit addressing format,
  # with the addresses referring to words rather than bytes.
  while ($#data_recs > -1)
  {
    # Extract bytes for a word, and addresses of bytes in that word.
    my @word_bytes = splice(@data_recs, 0, $data_width);
    my @word_addrs = splice(@data_addrs, 0, $data_width);

    # The size of the input data must be a a multiple of the memory word size
    # otherwise a valid Quartus II Hex file cannot be produced.
    print "Error: Size of input data is not a multiple of the memory width\n"
      and exit($ERR_MEMSIZE) if ($#word_bytes+1 < $data_width); 

    # The load offset is the word offset from the base address, plus the lower
    # bits of the segment address.  It is an error if the offset cannot be
    # expressed in 16 bits.
    my $data_offset = ($word_addrs[0] / $data_width) - $in_base + $out_lbase;
    print STDERR "Error: Data region is too large to convert\n"
      and exit($ERR_ADDR) if ($data_offset >> 16);

    # Form the data record preamble.  The data is byte reversed to comply with
    # the Quartus II Hex format
    print OUTHEX &create_data_record($data_offset, reverse(@word_bytes));
  }

  # Write the EOF record and close file
  print OUTHEX ":00000001FF\n";
  close(OUTHEX) or print "Error when writing output Hex file $outhex\n"
    and exit($ERR_OUTHEX);
}

################################################################################
#
# SUBROUTINE: Write DAT
# Write a DAT-format memory initialisation file for simulation using a Verilog
# readmemh model, using contents that have been read from the input hex file.
# Assumes that the read_hex subroutine has been called first.
#
################################################################################

sub write_dat
{
  # Open the output file for writing
  open(OUTHEX, ">$outhex")
    or print "Error: Unable to open output DAT file $outhex for writing\n"
      and exit($ERR_OUTHEX);

  # Addresses are implicit in DAT files, so need to track address of each word.
  # Keep track of previous address to detect discontinuities in input data.
  # Initialise previous address to something that will trigger the printing of
  # an address line in the first iteration of the loop.
  my $curr_addr = 0;
  my $prev_addr = 1;

  # The base address of the output image is defined as the user choice of
  # output address, if supplied, defaulting to the lowest address read from
  # the input image.  Converted to word addresses.
  my $in_base  = $data_addrs[0] / $data_width;
  my $out_base = defined($output_addr) ? $output_addr / $data_width :
                                         $in_base;

  # The image starts with the base address specification

  # The output DAT file is formed one word per line with implied incrementing
  # addresses.  An interruption in the addresses requires a new address line
  # to be printed.
  while ($#data_recs > -1)
  {
    # Extract bytes for a word, and addresses of bytes in that word.
    my @word_bytes = splice(@data_recs, 0, $data_width);
    my @word_addrs = splice(@data_addrs, 0, $data_width);

    # The size of the input data must be a a multiple of the memory word size
    # otherwise a valid Quartus II Hex file cannot be produced.
    print "Error: Size of input data is not a multiple of the memory width\n"
      and exit($ERR_MEMSIZE) if ($#word_bytes+1 < $data_width); 

    # Update address of current word, and if there's a discontinuity from the
    # address of the previous word print a new address line.
    $curr_addr = ($word_addrs[0] / $data_width) - $in_base + $out_base;
    print OUTHEX sprintf("@%.8X\n", $curr_addr) if $curr_addr != $prev_addr+1;

    # The data records are byte-reversed
    print OUTHEX sprintf("%s\n", join('', reverse(@word_bytes)));
    $prev_addr = $curr_addr;
  }

  # Close file
  close(OUTHEX) or print "Error when writing output Hex file $outhex\n"
    and exit($ERR_OUTHEX);
}

################################################################################
#
# SUBROUTINE: Display usage
# Prints a help message for the hex conversion program.
#
################################################################################

sub show_help
{
  print <<EOM
Convert Intel Hexadecimal files into files of different formats that can be used
by memory initialization tools.

By default the input data will be re-based to an address of 0x00000000 making it
suitable for initialising RAM/ROM blocks.  The output files may contain all of
the input data or just a subset of it.

$0 --infile=<input-file> --outfile=<output-file> [options]

Where:
  --infile=<input-file>
    Specifies the input Intel Hexadecimal file to convert.

  --outfile=<output-file>
    Specifies the output file which will contain the converted memory image.

Additional options:
  --oformat=<format>
    Specifies the format to use for the output file.  Legal values for
    <format> are:
      ihex: Output in the Intel Hexadecimal format
      hex:  Output in the Quartus II Hex format for memory block initialisation
      dat:  Output in the DAT format for Verilog readmemh initialisation
    The default output format is hex if none is specified

  --width=<num>
    Specifies the data width in bytes of the memory to be initialised.  This
    option affects the formatting of hex and dat output files.  It does not
    affect ihex output files, which are byte addressed.  Default 4.

  --saddr=<addr>
    Start address: Specifies that only data starting from byte address <addr>
    should be extracted from the input Hex file and written to the converted
    file.  Default 0x00000000.

  --eaddr=<addr>
    End address: Specifies that only data from byte address <addr> and below
    should be extracted from the input Hex file and written to the converted
    file.  Can not be used with --osize.  Defaults to the end address of the
    input data.

  --oaddr=<addr>
    Output address: Specifies that the converted memory image file should be
    rebased to byte address <addr>.  By default the output image is rebased to
    address 0x00000000.

  --osize=<size>|section
    Specifies that the output image should be of size <size>, starting from the
    input start address.  This cannot be used with the --eaddr option. <size> is
    a size specification matching <number>[M|K], where M signifies megabytes and
    K signifies kilobytes.  For example, '1024' and '1K' both signify 1024 bytes.

    If the input file does not contain data for the entire input section, the
    output file will not contain data in these sections.  Use the --padding
    option to pad empty spaces with zeroes, forcing an output file to contain
    exactly <size> data bytes.

    Instead of a size specification, use 'section' to create a hex file that
    takes data from the start address of the input file until it reaches the end
    of the input section.

  --padding
    Where the input file contains empty address regions in the target address
    range, pad the empty regions with zeroes in the output file.

    To prevent the accidental use of this option on input images containing
    distant sections, which would result in images with very large zero-padded
    regions, there is a size limit of ${SIZE_LIMIT_MB}MB on zero-padded sections.
    To disable this, use the --no-size-limit option.

  --no-size-limit
    Disables the size limit on zero-padded sections.  When this option is used,
    care should be taken that the input image does not contain a large, empty
    address region that is to be zero-padded in the output image.  Memory and
    disk space requirements might otherwise be excessive.
EOM
}

################################################################################
#
# Main Program
#
################################################################################

my $hex_output  = 1;   # 1 if hex-format output, default
my $ihex_output = 0;   # 1 if Intel hex-format output
my $dat_output  = 0;   # 1 if dat-format output

my $opt_osize_str = "";  # Output size string
my $opt_osize;           # Output size option, converted to bytes
my $opt_eaddr     = 0;   # Set to 1 if the eaddr option is used

&show_help and exit(0) if $#ARGV < 0;

##################################################
# Argument parsing.
# All arguments are in the form --option[=value].
##################################################

foreach (@ARGV)
{
  print "Argument \"$_\" is not recognized. Use --help for help.\n"
    and exit($ERR_ARGS) if $_ !~ /^--([a-z-]+)(=(\S+))*/i;

  # Options and values extracted from regexp test.  The value is not compulsory,
  # so assign it to the empty string if not given to prevent warnings.
  my $option = $1;
  my $value  = defined($3) ? $3 : "";

  if (lc($option) eq "infile")
  {
    $inhex = $value;

    print "Error: Input hex file \"$inhex\" does not exist\n"
      and exit($ERR_ARGS) unless -r $inhex;
  }
  elsif (lc($option) eq "outfile")
  {
    $outhex = $value;
  }
  elsif (lc($option) eq "width")
  {
    print "Error: Data width argument must be numeric\n" and exit($ERR_ARGS)
      unless $value =~ /^\d+$/;

    $data_width = $value;
  }
  elsif (lc($option) eq "saddr")
  {
    # A valid start address is a hex string or decimal number
    print "Error: Invalid address specification\n" and exit($ERR_ARGS)
      unless ($value =~ /^0[xX][0-9a-fA-F]{1,8}$/ || $value =~ /^\d+$/);

    $start_addr = hex($value);
  }
  elsif (lc($option) eq "eaddr")
  {
    # A valid end address is a hex string or decimal number
    print "Error: Invalid address specification\n" and exit($ERR_ARGS)
      unless ($value =~ /^0[xX][0-9a-fA-F]{1,8}$/ || $value =~ /^\d+$/);

    $end_addr   = hex($value);
    $opt_eaddr  = 1;
    $has_target = 1;
  }
  elsif (lc($option) eq "oaddr")
  {
    # A valid start address is a hex string or decimal number
    print "Error: Invalid address specification\n" and exit($ERR_ARGS)
      unless ($value =~ /^0[xX][0-9a-fA-F]{1,8}$/ || $value =~ /^\d+$/);

    $output_addr = hex($value);
  }
  elsif (lc($option) eq "osize")
  {
    $opt_osize_str = $value;

    if (lc($value) eq "section")
    {
      $single_section = 1;
    }
    else
    {
      print "Error: Output size $value is not valid\n" and exit($ERR_ARGS)
        unless ($value =~ /^(\d+(\.?\d+)?)([MK]?)$/);

      $opt_osize = $1;
      $opt_osize *= 1024 if $3;
      $opt_osize *= 1024 if ($3 eq "M");

      if (int($opt_osize) ne $opt_osize)
      {
        $opt_osize = int($opt_osize);
        print "Warning: Output size is not an integer number of bytes.  Using $opt_osize.\n";
      }

      $end_addr = $start_addr + $opt_osize - 1;
      $has_target = 1;
    }
  }
  elsif (lc($option) eq "oformat")
  {
    $hex_output  = ($value eq "hex");
    $ihex_output = ($value eq "ihex");
    $dat_output  = ($value eq "dat");

    print "Error: The output format must be \"hex\", \"ihex\" or \"dat\"\n" and exit($ERR_ARGS)
      unless ($hex_output || $ihex_output || $dat_output);
  }
  elsif (lc($option) eq "help")
  {
    &show_help and exit(0);
  }
  elsif (lc($option) eq "no-size-limit")
  {
    $opt_nosizelimit = 1;
  }
  elsif (lc($option) eq "padding")
  {
    $zero_pad = 1;
  }
  else
  {
    print "Option $option is not recognized. Use --help for help.\n"
      and exit($ERR_ARGS);
  }
}

# Consistency checking of program options
print "Error: You must specify an input Intel Hexadecimal file using --infile.\n"
  and exit($ERR_ARGS) if (!defined($inhex) || !$inhex);
print "Error: You must specify an output file using --outfile.\n"
  and exit($ERR_ARGS) if (!defined($outhex) || !$outhex);
print "Error: Only one of --osize and --eaddr may be used.\n"
  and exit($ERR_ARGS) if ($opt_osize_str && $opt_eaddr);


#########################
# Program starting point
#########################

# Start the main work of the application: read the input Hex file and output
# either a Quartus II compatible Hex file or a Verilog readmemh DAT file
&read_hex();
if ($hex_output)     { &write_hex();       }
elsif ($ihex_output) { &write_intel_hex(); }
elsif ($dat_output)  { &write_dat();       }

# Indicate successful exit
exit(0);
