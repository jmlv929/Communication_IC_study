#!/usr/bin/perl -w
use 5.010;
use strict;

my $in  = $ARGV[0];
my $out = $ARGV[1];

unless(defined $in && defined $out){
	die "Usage: Not enough arguments";
}

(open IN,"<",$in) or die "# Can't open '$in'";
(open OUT,">>",$out) or die "# Can't open '$out'";

while(<IN>){
	chomp();
	unless($_ eq ""){
		print OUT "set_global_assignment -name VERILOG_FILE ".$_."\n";
	}
}

