#!/usr/bin/perl -w
use 5.010;
use strict;

my $bin = $ARGV[0];
my $ver = $ARGV[1];
my $opt = $ARGV[2];

print "usage: bin2readmemh.pl 1.bin 1.v 32 \n";

my $memory_address;
my $buf;
my $tmp;

(open IN,"<",$bin) or die "# Can't open '$bin'";
(open OUT,">",$ver) or die "# Can't open '$ver'";

my $head = "
// ***************************************** //
// ****** Design by Mr liqinghua
// ****** v1.0 2013.3.13
// ***************************************** //
// 
module sprom
#(
parameter DATA_WIDTH=8, 
parameter ADDR_WIDTH=8,
parameter MEMFILE=\"bootrom.bin\"
)
(
	input [(ADDR_WIDTH-1):0] addr,
	input clk, 
	input en,
	output reg [(DATA_WIDTH-1):0] q
);

	// Declare the ROM variable
	reg [DATA_WIDTH-1:0] rom[2**ADDR_WIDTH-1:0]/*synthesis ram_init_file=\"bootrom.hex\" syn_ramstyle=\"no_rw_check\"*/;

	always @ (posedge clk)
	begin
		if(en)
			case(addr)
";

my $tail = "
				default: q<=0;
			endcase
	end

endmodule
";

print OUT $head."\n";

my $addrwidth=12;
my $addr_rec;

$memory_address = 0;

if( $opt == 32 ) {
  while ( read( IN, $buf, 4 ) ) {
    $tmp = unpack( "H8", $buf);
    
#    if( $opt_x ) {
#	    print "$tmp\n";	    
#	  } else {
#	    printf( "\@%08x\n", $memory_address );
#	    print "$tmp\n\n";
#	  }
    $addr_rec = sprintf("\t\t\t\t%2d'h%X  ", $addrwidth,$memory_address);

	  print OUT $addr_rec.":\t";
	  print OUT "q <= ".$opt."'h".$tmp.";\n";

    $memory_address++;
  }
} elsif( $opt == 16 ) {
  while ( read( IN, $buf, 2 ) ) {
    $tmp = unpack( "H4", $buf);
    
#    if( $opt_x ) {
#	    print "$tmp\n";	    
#	  } else {
#	    printf( "\@%08x\n", $memory_address );
#	    print "$tmp\n\n";
#	  }
#    $addr_rec = sprintf("\t\t\t%2d'h%.4X  ", $addrwidth,$memory_address);
    $addr_rec = sprintf("\t\t\t\t%2d'h%X  ", $addrwidth,$memory_address);

	  print OUT $addr_rec.":\t";
	  print OUT "q <= ".$opt."'h".$tmp.";\n";

    $memory_address++;
  }
} elsif( $opt == 8 ) {
  while ( read( IN, $buf, 1 ) ) {
    $tmp = unpack( "H2", $buf);
    
#    if( $opt_x ) {
#	    print "$tmp\n";	    
#	  } else {
#	    printf( "\@%08x\n", $memory_address );
#	    print "$tmp\n\n";
#	  }
    $addr_rec = sprintf("\t\t\t\t%2d'h%X  ", $addrwidth,$memory_address);

	  print OUT $addr_rec.":\t";
	  print OUT "q <= ".$opt."'h".$tmp.";\n";

    $memory_address++;
  }
} else {
    print "ERROR! $opt is invalad option \n";
}

print OUT $tail."\n";

close(OUT);
close(IN);

